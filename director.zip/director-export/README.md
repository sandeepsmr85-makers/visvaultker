# Director — AI Browser Automation

A full clone of director.ai for internal tools, built on Stagehand v3.4.0.

## Structure

```
director-export/
├── backend/          ← Express + Stagehand v3 server
│   ├── server.js     ← Main server (all features)
│   ├── storage.js    ← Schedule & result persistence (JSON)
│   ├── package.json  ← Dependencies (pinned)
│   ├── .env.example  ← Config template
│   └── README.md     ← Backend docs
└── frontend/
    └── director-ai.jsx  ← React UI (paste into Claude artifact or your app)
```

## Quick start

```bash
# 1. Backend
cd backend
npm install
npx playwright install chromium
cp .env.example .env      # fill in your values
npm start                 # → http://localhost:3001

# 2. Frontend
# Open director-ai.jsx in Claude.ai as a React artifact, or drop into your app.
```

## Execution modes

| Mode     | How it works |
|----------|--------------|
| ⚡ Scripted | Plan → pre-flight observe → act (with alternatives + vision fallback) → validate |
| 🤖 Agent   | Stagehand agent() — autonomous, handles unexpected page states |
| 👁️ Vision  | Pure screenshot loop — no DOM. Works on canvas, iframes, shadow DOM |

## Features

- OAuth token refresh (auto, deduplicated, retries on 401)
- Custom LLM gateway via AISdkClient + tokenAwareFetch
- Vision fallback: when DOM fails → screenshot → pixel coordinates → click
- Step validation: checks for errors + confirms expected outcome
- Smart retry: tries alternative phrasings before vision fallback
- Loop/pagination steps
- Shadow DOM support (pierce/ prefix)
- Session injection (cookies, localStorage, sessionStorage)
- Multi-tab handling
- Scheduler (node-cron) with history
- Export to Playwright script with stable locators
