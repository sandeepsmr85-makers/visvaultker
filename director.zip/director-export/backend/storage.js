import { readFileSync, writeFileSync, existsSync } from 'fs';
import { randomUUID } from 'crypto';

const FILE = './schedules.json';
const MAX_HISTORY = 10; // keep last N run results per schedule

// ─── Helpers ──────────────────────────────────────────────────────────────────

function load() {
  if (!existsSync(FILE)) return { schedules: [], results: [] };
  try { return JSON.parse(readFileSync(FILE, 'utf8')); }
  catch { return { schedules: [], results: [] }; }
}

function save(data) {
  writeFileSync(FILE, JSON.stringify(data, null, 2));
}

// ─── Schedules ────────────────────────────────────────────────────────────────

export function listSchedules() {
  const { schedules, results } = load();
  // Attach last run result to each schedule
  return schedules.map(s => ({
    ...s,
    history: results
      .filter(r => r.scheduleId === s.id)
      .sort((a, b) => new Date(b.runAt) - new Date(a.runAt))
      .slice(0, MAX_HISTORY),
  }));
}

export function getSchedule(id) {
  const { schedules } = load();
  return schedules.find(s => s.id === id) ?? null;
}

export function createSchedule({ prompt, mode = 'scripted', cronExpression, humanReadable, schemaType = 'auto' }) {
  const data     = load();
  const schedule = {
    id:             randomUUID(),
    prompt,
    mode,
    cronExpression,
    humanReadable,
    schemaType,
    enabled:        true,
    lastRun:        null,
    lastStatus:     null,
    createdAt:      new Date().toISOString(),
  };
  data.schedules.push(schedule);
  save(data);
  return schedule;
}

export function updateSchedule(id, patch) {
  const data = load();
  const idx  = data.schedules.findIndex(s => s.id === id);
  if (idx === -1) return null;
  data.schedules[idx] = { ...data.schedules[idx], ...patch };
  save(data);
  return data.schedules[idx];
}

export function deleteSchedule(id) {
  const data     = load();
  data.schedules = data.schedules.filter(s => s.id !== id);
  data.results   = data.results.filter(r => r.scheduleId !== id);
  save(data);
  return true;
}

// ─── Run results ──────────────────────────────────────────────────────────────

export function saveResult({ scheduleId, status, extracted, goal, error }) {
  const data = load();

  data.results.push({
    id:         randomUUID(),
    scheduleId,
    status,      // 'success' | 'error'
    extracted:   extracted ?? null,
    goal:        goal ?? null,
    error:       error ?? null,
    runAt:       new Date().toISOString(),
  });

  // Trim history
  const ids = data.results
    .filter(r => r.scheduleId === scheduleId)
    .sort((a, b) => new Date(b.runAt) - new Date(a.runAt))
    .slice(MAX_HISTORY)
    .map(r => r.id);

  data.results = data.results.filter(r => !ids.includes(r.id));

  // Update last run info on schedule
  const idx = data.schedules.findIndex(s => s.id === scheduleId);
  if (idx !== -1) {
    data.schedules[idx].lastRun    = new Date().toISOString();
    data.schedules[idx].lastStatus = status;
  }

  save(data);
}
