# Director Backend

Express server that powers the Director.ai clone using **Stagehand v3** (LOCAL env) + **Claude**.

## Stack

| Layer | Technology |
|---|---|
| HTTP server | Express |
| Browser automation | Stagehand v3 (`@browserbasehq/stagehand`) |
| Browser engine | Chromium via CDP (Stagehand v3 is Playwright-free) |
| AI / planning | Anthropic Claude (`claude-sonnet-4-20250514`) |
| Streaming | Server-Sent Events (SSE) |
| Runtime | Node.js ≥ 18 |

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Install Playwright browsers (needed for LOCAL env)
npx playwright install chromium

# 3. Configure environment
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY

# 4. Start the server
npm start        # production
npm run dev      # development (auto-restart on file changes)
```

## API

### `POST /automate`
Start an automation. Returns a `sessionId` immediately.

```json
// Request
{ "prompt": "Go to http://localhost:8080 and extract all pending orders" }

// Response
{ "sessionId": "uuid-here" }
```

### `GET /stream/:sessionId`
SSE stream for real-time automation progress.

**Events emitted:**

| Event | Payload | Description |
|---|---|---|
| `connected` | `{}` | SSE connection established |
| `status` | `{ text }` | Status message |
| `plan` | `{ goal, totalSteps, startUrl }` | Automation plan ready |
| `browser_ready` | `{ text }` | Browser initialized |
| `step_start` | `{ index, total, description, type }` | Step beginning |
| `step_done` | `{ index, description, url, screenshot, extracted }` | Step complete with screenshot |
| `step_error` | `{ index, description, error }` | Step failed (non-fatal) |
| `done` | `{ url, screenshot, extracted, goal }` | All steps complete |
| `error` | `{ message }` | Fatal error |
| `close` | `{}` | Stream ending |

### `GET /health`
Health check. Returns `{ ok: true }`.

## How it works

```
User prompt
    │
    ▼
Claude generates a step-by-step plan (navigate → act → extract)
    │
    ▼
Stagehand v3 initializes a LOCAL headless Chromium browser via CDP
    │
    ▼
For each step:
  ┌─ navigate → page.goto(url)
  ├─ act      → stagehand.act("instruction")
  │              internally runs observe() to find element, then executes
  └─ extract  → stagehand.extract({ instruction, schema })
    │
    ▼
Screenshot captured after every step → streamed to frontend via SSE
    │
    ▼
Browser closed, SSE stream ends
```

## Tips for internal sites

- Set `headless: false` in server.js to watch the browser live on your screen
- The AI planner works best when you're specific: *"Go to http://localhost:3000/dashboard and click the Export button in the top right"*
- Use `variables` in act() to avoid sending credentials to the LLM:
  ```js
  await stagehand.act("type %password% into the password field", {
    variables: { password: process.env.INTERNAL_PASS }
  });
  ```
