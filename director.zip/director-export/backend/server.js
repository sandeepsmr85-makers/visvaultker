process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

import 'dotenv/config';
import express          from 'express';
import cors             from 'cors';
import { randomUUID }   from 'crypto';
import cron             from 'node-cron';
import { Stagehand, AISdkClient } from '@browserbasehq/stagehand';
import { createOpenAI } from '@ai-sdk/openai';
import { z }            from 'zod';
import {
  listSchedules, getSchedule, createSchedule,
  updateSchedule, deleteSchedule, saveResult,
} from './storage.js';

// ─── Config ───────────────────────────────────────────────────────────────────

const PORT           = process.env.PORT            || 3001;
const OAUTH_URL      = process.env.OAUTH_URL;
const CLIENT_ID      = process.env.CLIENT_ID;
const CLIENT_SECRET  = process.env.CLIENT_SECRET;
const OAUTH_SCOPE    = process.env.OAUTH_SCOPE     || 'read';
const LLM_BASE_URL   = process.env.LLM_BASE_URL;
const LLM_MODEL      = process.env.LLM_MODEL       || 'gpt-4.1-2025-04-14-eastus-dz';
// Vision model — must be multimodal. Falls back to LLM_MODEL if gateway supports vision.
const VISION_MODEL   = process.env.VISION_MODEL    || LLM_MODEL;
const TOKEN_REFRESH_BUFFER_MS = 60_000;
// Max iterations for loop steps (pagination guard)
const MAX_LOOP_ITERATIONS = 50;

for (const [k, v] of Object.entries({ OAUTH_URL, CLIENT_ID, CLIENT_SECRET, LLM_BASE_URL })) {
  if (!v) { console.error(`❌  ${k} missing in .env`); process.exit(1); }
}

// ─── TokenManager ─────────────────────────────────────────────────────────────

class TokenManager {
  #token = null; #expiresAt = 0; #refreshing = null;

  async getToken() {
    if (this.#isValid()) return this.#token;
    if (!this.#refreshing) {
      this.#refreshing = this.#refresh().finally(() => { this.#refreshing = null; });
    }
    await this.#refreshing;
    return this.#token;
  }

  async forceRefresh() { this.#expiresAt = 0; return this.getToken(); }
  #isValid() { return this.#token && Date.now() < this.#expiresAt - TOKEN_REFRESH_BUFFER_MS; }

  async #refresh() {
    console.log('🔐  Refreshing token…');
    const res = await fetch(OAUTH_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'client_credentials', client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET, scope: OAUTH_SCOPE,
      }),
    });
    if (!res.ok) throw new Error(`OAuth failed: ${res.status}`);
    const data = await res.json();
    if (!data.access_token) throw new Error('No access_token');
    this.#token     = data.access_token;
    const expiresIn = data.expires_in ?? 3600;
    this.#expiresAt = Date.now() + expiresIn * 1_000;
    console.log(`✓ Token valid ${expiresIn}s`);
  }
}

const tokenManager = new TokenManager();

// ─── Token-aware fetch ────────────────────────────────────────────────────────

async function tokenAwareFetch(url, init) {
  const token   = await tokenManager.getToken();
  const headers = new Headers(init?.headers ?? {});
  headers.set('Authorization', `Bearer ${token}`);
  const res = await globalThis.fetch(url, { ...init, headers });
  if (res.status === 401) {
    headers.set('Authorization', `Bearer ${await tokenManager.forceRefresh()}`);
    return globalThis.fetch(url, { ...init, headers });
  }
  return res;
}

// ─── LLM gateway helper ───────────────────────────────────────────────────────
// Central function for all direct LLM calls (planner, vision, validation).
// Supports both text and multimodal (vision) messages.

async function llmCall({ model = LLM_MODEL, messages, maxTokens = 800, json = false }) {
  let token = await tokenManager.getToken();

  const body = JSON.stringify({
    model,
    max_tokens: maxTokens,
    messages,
    ...(json ? { response_format: { type: 'json_object' } } : {}),
  });

  const makeRequest = async (t) =>
    globalThis.fetch(`${LLM_BASE_URL}/chat/completions`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` },
      body,
    });

  let res = await makeRequest(token);
  if (res.status === 401) {
    token = await tokenManager.forceRefresh();
    res   = await makeRequest(token);
  }
  if (!res.ok) throw new Error(`LLM call failed: ${res.status} ${res.statusText}`);

  const data    = await res.json();
  const content = data.choices?.[0]?.message?.content ?? '';
  return content;
}

// ─── Stagehand factory ────────────────────────────────────────────────────────

function createStagehand() {
  const rbcOpenAI = createOpenAI({
    apiKey: 'managed', baseURL: LLM_BASE_URL, fetch: tokenAwareFetch,
  });
  return new Stagehand({
    env: 'LOCAL',
    llmClient: new AISdkClient({ model: rbcOpenAI.chat(LLM_MODEL) }),
    headless: true, verbose: 0,
  });
}

// ─── Extract schemas ──────────────────────────────────────────────────────────

const SCHEMAS = {
  table: z.object({
    headers:   z.array(z.string()),
    rows:      z.array(z.record(z.string())),
    totalRows: z.number().optional(),
  }),
  keyValue: z.object({
    fields: z.record(z.string()),
  }),
  list: z.object({
    items: z.array(z.string()),
    total: z.number().optional(),
    hasNextPage: z.boolean().optional().describe('true if there are more pages'),
  }),
  text: z.object({
    data: z.string(),
    hasNextPage: z.boolean().optional().describe('true if pagination exists and there are more pages'),
  }),
};

function inferSchemaType(instruction) {
  const l = instruction.toLowerCase();
  if (/table|rows|grid|column|spreadsheet/.test(l)) return 'table';
  if (/detail|info|field|form|summary|profile/.test(l)) return 'keyValue';
  if (/list|items|all|each|every|results/.test(l))      return 'list';
  return 'text';
}

// ─── Planner v2 ───────────────────────────────────────────────────────────────
// Now supports: navigate, act, extract, wait, loop, upload, download
// Includes alternatives (retry phrasings), expectedOutcome (validation),
// and confidence scores per step.

const PLAN_SYSTEM_V2 = `You are an expert web automation planner for internal tools.
Return ONLY valid JSON — no markdown, no code fences.

Schema:
{
  "goal": "one sentence",
  "startUrl": "full URL",
  "sessionRequired": false,
  "steps": [
    {
      "type": "navigate",
      "url": "https://...",
      "description": "...",
      "waitFor": "optional: selector or text to wait for after navigation"
    },
    {
      "type": "act",
      "instruction": "primary action instruction",
      "alternatives": ["alt phrasing 1", "alt phrasing 2"],
      "description": "...",
      "expectedOutcome": "what should be true after this step",
      "confidence": "high|medium|low"
    },
    {
      "type": "extract",
      "instruction": "what to extract",
      "description": "...",
      "paginate": false
    },
    {
      "type": "loop",
      "description": "Paginate through all results",
      "condition": "Next button is visible and enabled",
      "maxIterations": 10,
      "steps": [
        { "type": "extract", "instruction": "extract current page rows", "description": "..." },
        { "type": "act", "instruction": "click the Next page button", "description": "...", "alternatives": [] }
      ]
    },
    {
      "type": "wait",
      "description": "Wait for results to load",
      "for": "selector or text to wait for",
      "timeout": 5000
    },
    {
      "type": "upload",
      "description": "Upload a file",
      "selector": "CSS selector for file input",
      "filePath": "path to file"
    }
  ]
}

Rules:
- Max 8 top-level steps.
- Always start with navigate.
- For tables/lists that might span multiple pages, use a loop step.
- act instructions must be single atomic actions.
- alternatives should be 2 different phrasings of the same action.
- expectedOutcome helps validate the step worked.
- Set confidence: low if the element might be hard to find.`;

async function generatePlan(prompt) {
  const text = await llmCall({
    messages: [
      { role: 'system', content: PLAN_SYSTEM_V2 },
      { role: 'user',   content: prompt },
    ],
  });
  try { return JSON.parse(text.replace(/```json|```/g, '').trim()); }
  catch { throw new Error('Failed to parse plan from LLM'); }
}

// ─── getBestLocator ───────────────────────────────────────────────────────────

function isAutoGenerated(id) {
  return /^(ember|react|vue|ng|mat|v-|css-|uid-)[\w-]*\d+/i.test(id)
    || /^:[a-z]\d+:?$/.test(id) || /\d{5,}/.test(id);
}
function isDynamicClass(c) {
  return ['active','selected','open','closed','visible','hidden','disabled',
          'enabled','focus','hover','checked','loading','error','success','expanded']
    .includes(c.toLowerCase());
}

async function getBestLocator(page, rawSelector, description) {
  try {
    const xpath = rawSelector.startsWith('xpath=') ? rawSelector.slice(6) : rawSelector;
    const a = await page.evaluate((xp) => {
      const el = document.evaluate(xp, document, null,
        XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (!el) return null;
      // Also check if element is inside a shadow root
      let inShadow = false;
      let parent   = el.parentNode;
      while (parent) {
        if (parent instanceof ShadowRoot) { inShadow = true; break; }
        parent = parent.parentNode;
      }
      return {
        testId: el.getAttribute('data-testid'), dataCy: el.getAttribute('data-cy'),
        dataQa: el.getAttribute('data-qa'), role: el.getAttribute('role'),
        ariaLabel: el.getAttribute('aria-label'), id: el.getAttribute('id'),
        name: el.getAttribute('name'), placeholder: el.getAttribute('placeholder'),
        tagName: el.tagName.toLowerCase(), className: el.className || '',
        innerText: el.innerText?.trim().slice(0, 80) ?? '', inShadow,
      };
    }, xpath);

    if (!a) return { selector: rawSelector, stability: 'low', note: 'Not in DOM' };

    // Shadow DOM: use pierce/ prefix (Playwright-compatible)
    const prefix = a.inShadow ? 'pierce/' : '';

    if (a.testId)  return { selector: `${prefix}[data-testid="${a.testId}"]`,           stability: 'high', inShadow: a.inShadow };
    if (a.dataCy)  return { selector: `${prefix}[data-cy="${a.dataCy}"]`,               stability: 'high', inShadow: a.inShadow };
    if (a.dataQa)  return { selector: `${prefix}[data-qa="${a.dataQa}"]`,               stability: 'high', inShadow: a.inShadow };
    if (a.role && a.ariaLabel) {
      return { selector: `${prefix}[role="${a.role}"][aria-label="${a.ariaLabel}"]`,     stability: 'high', inShadow: a.inShadow };
    }
    if (a.id && !isAutoGenerated(a.id)) return { selector: `${prefix}#${a.id}`,        stability: 'medium', inShadow: a.inShadow };
    if (a.name && ['input','select','textarea'].includes(a.tagName)) {
      return { selector: `${prefix}${a.tagName}[name="${a.name}"]`,                     stability: 'medium', inShadow: a.inShadow };
    }
    if (a.placeholder) return { selector: `${prefix}[placeholder="${a.placeholder}"]`, stability: 'medium', inShadow: a.inShadow };
    const stable = a.className.trim().split(/\s+/)
      .filter(c => c && !isDynamicClass(c) && !isAutoGenerated(c));
    if (stable.length >= 2) {
      return { selector: `${prefix}${stable.slice(0,3).map(c=>`.${c}`).join('')}`,      stability: 'low-medium', inShadow: a.inShadow };
    }
    if (a.innerText && ['button','a'].includes(a.tagName)) {
      return { selector: `${prefix}${a.tagName}:has-text("${a.innerText}")`,            stability: 'medium', inShadow: a.inShadow };
    }
    return { selector: rawSelector, stability: 'low', note: 'XPath fallback — add data-testid', inShadow: a.inShadow };
  } catch (e) {
    return { selector: rawSelector, stability: 'low', note: e.message };
  }
}

// ─── Vision fallback ──────────────────────────────────────────────────────────
// When DOM-based act() fails, this takes a screenshot, sends it to the vision
// model, and asks for the element's pixel coordinates. Then clicks at those coords.
// Handles: canvas elements, shadow DOM, cross-origin iframes, broken locators.

async function visionLocate(page, description) {
  const buf    = await page.screenshot({ type: 'jpeg', quality: 85, fullPage: false });
  const base64 = buf.toString('base64');

  const raw = await llmCall({
    model: VISION_MODEL,
    maxTokens: 150,
    messages: [{
      role: 'user',
      content: [
        {
          type: 'image_url',
          image_url: { url: `data:image/jpeg;base64,${base64}`, detail: 'high' },
        },
        {
          type: 'text',
          text: `You are looking at a browser screenshot.
Find the element matching: "${description}"

Return ONLY valid JSON (no markdown):
{"found": true/false, "x": <pixel_x_center>, "y": <pixel_y_center>, "confidence": "high|medium|low", "note": "brief description of what you found"}

If not found: {"found": false, "x": 0, "y": 0, "confidence": "low", "note": "why not found"}`,
        },
      ],
    }],
  });

  try {
    return JSON.parse(raw.replace(/```json|```/g, '').trim());
  } catch {
    return { found: false, x: 0, y: 0, confidence: 'low', note: 'Vision response parse failed' };
  }
}

// Click at pixel coordinates using elementFromPoint + CDP fallback
async function clickAtCoordinates(page, x, y) {
  // Try elementFromPoint first (works even in shadow DOM context)
  const clicked = await page.evaluate(({ cx, cy }) => {
    const el = document.elementFromPoint(cx, cy);
    if (!el) return false;
    el.focus?.();
    el.click();
    return true;
  }, { cx: x, cy: y });

  if (!clicked) {
    // CDP fallback for elements not reachable via elementFromPoint
    try {
      await page._client?.send('Input.dispatchMouseEvent', {
        type: 'mousePressed', x, y, button: 'left', clickCount: 1,
      });
      await page._client?.send('Input.dispatchMouseEvent', {
        type: 'mouseReleased', x, y, button: 'left', clickCount: 1,
      });
    } catch {
      // Best-effort — not all page implementations expose _client
    }
  }
}

// ─── Step validator ───────────────────────────────────────────────────────────
// After each act(), checks: error messages, unexpected dialogs, page crashes.
// Returns { ok, warning } — never throws (validation failure is non-fatal).

async function validateStepResult(stagehand, expectedOutcome) {
  if (!expectedOutcome) return { ok: true };
  try {
    const result = await stagehand.extract(
      `Check the current page state: is there any error message, alert, or warning visible?
       Also: did the page change as expected — "${expectedOutcome}"?`,
      z.object({
        hasError:    z.boolean(),
        errorText:   z.string().optional(),
        outcomemet:  z.boolean().describe('true if the expected outcome appears to have been met'),
      }),
      { ignoreSelectors: ['nav', 'footer', '.ad'] },
    );
    return {
      ok:      !result.hasError,
      warning: result.hasError ? result.errorText : null,
      met:     result.outcomemet,
    };
  } catch {
    return { ok: true }; // validation is best-effort
  }
}

// ─── Master step executor ─────────────────────────────────────────────────────
// Execution strategy per act() step:
//   1. observe() pre-flight — confirm element exists
//   2. act() with primary instruction
//   3. If fails → try alternative instructions (planner-provided)
//   4. If all alternatives fail → vision fallback (screenshot → coordinates → click)
//   5. validate() — check for errors / confirm outcome

async function executeActStep(stagehand, page, step, emit, sessionId, index) {
  // 1. Pre-flight observe
  let preflightFound = false;
  try {
    const candidates = await stagehand.observe(step.instruction);
    preflightFound   = (candidates?.length > 0);
    emit(sessionId, 'preflight', {
      index, found: preflightFound,
      selector: candidates?.[0]?.selector,
    });
  } catch { /* non-fatal */ }

  // 2. Try primary instruction
  const instructions = [step.instruction, ...(step.alternatives ?? [])];
  let lastError;

  for (let attempt = 0; attempt < instructions.length; attempt++) {
    try {
      const result = await stagehand.act(instructions[attempt]);
      if (result.success) {
        if (attempt > 0) emit(sessionId, 'retry', { index, attempt, usedAlternative: true });
        break; // success
      }
      lastError = new Error(result.message || 'act() returned failure');
    } catch (e) {
      lastError = e;
    }
    if (attempt < instructions.length - 1) {
      emit(sessionId, 'retry', { index, attempt: attempt + 1, reason: lastError.message });
      await sleep(300);
    }
  }

  // 3. Vision fallback if all DOM attempts failed
  if (lastError) {
    emit(sessionId, 'vision_fallback', { index, reason: lastError.message });
    try {
      const loc = await visionLocate(page, step.description || step.instruction);
      emit(sessionId, 'vision_result', {
        index, found: loc.found, confidence: loc.confidence, note: loc.note, x: loc.x, y: loc.y,
      });

      if (loc.found && loc.confidence !== 'low') {
        await clickAtCoordinates(page, loc.x, loc.y);
        await sleep(500); // let page react
        lastError = null; // vision click succeeded
      } else {
        throw new Error(`Vision fallback: ${loc.note}`);
      }
    } catch (visionErr) {
      throw visionErr;
    }
  }

  // 4. Validate
  if (step.expectedOutcome) {
    const validation = await validateStepResult(stagehand, step.expectedOutcome);
    if (!validation.ok || validation.warning) {
      emit(sessionId, 'step_warning', { index, warning: validation.warning });
    }
    emit(sessionId, 'step_validated', { index, met: validation.met });
  }
}

// ─── Loop step executor ───────────────────────────────────────────────────────
// Runs inner steps in a loop while condition is met (pagination, polling, etc.)
// Collects all extracted data across iterations.

async function executeLoopStep(stagehand, state, loopStep, emit, sessionId, outerIndex) {
  const allExtracted = [];
  let   iteration    = 0;

  emit(sessionId, 'loop_start', {
    index: outerIndex, description: loopStep.description,
    max: loopStep.maxIterations || MAX_LOOP_ITERATIONS,
  });

  while (iteration < (loopStep.maxIterations || MAX_LOOP_ITERATIONS)) {
    // Check condition — is there a "next" to go to?
    let conditionMet = false;
    try {
      const check = await stagehand.extract(
        `Is this condition currently true on the page? "${loopStep.condition}"`,
        z.object({ met: z.boolean() }),
      );
      conditionMet = check.met;
    } catch {
      conditionMet = false;
    }

    if (!conditionMet) {
      emit(sessionId, 'loop_end', { index: outerIndex, iterations: iteration, reason: 'condition false' });
      break;
    }

    emit(sessionId, 'loop_iteration', { index: outerIndex, iteration });

    // Execute inner steps
    for (const innerStep of loopStep.steps) {
      try {
        if (innerStep.type === 'act') {
          await executeActStep(stagehand, state.activePage, innerStep, emit, sessionId, outerIndex);
        } else if (innerStep.type === 'extract') {
          const schemaType = inferSchemaType(innerStep.instruction);
          const result     = await stagehand.extract(
            innerStep.instruction, SCHEMAS[schemaType] ?? SCHEMAS.text,
            { ignoreSelectors: ['nav', 'footer', '.ad', '.cookie-banner'] },
          );
          allExtracted.push({ iteration, schemaType, data: result });
          emit(sessionId, 'extracted', { index: outerIndex, iteration, schemaType, data: result });
        } else if (innerStep.type === 'wait') {
          await sleep(innerStep.timeout || 1000);
        }
      } catch (e) {
        emit(sessionId, 'loop_step_error', { index: outerIndex, iteration, error: e.message });
      }
      await sleep(200);
    }

    iteration++;
    await sleep(500); // brief pause between pages
  }

  if (iteration >= MAX_LOOP_ITERATIONS) {
    emit(sessionId, 'loop_end', { index: outerIndex, iterations: iteration, reason: 'max iterations reached' });
  }

  return allExtracted;
}

// ─── Session injector ─────────────────────────────────────────────────────────
// Pre-injects auth cookies and localStorage before automation starts.
// Accepts: { cookies: [{name,value,domain,path}], localStorage: {key:value}, sessionStorage: {key:value} }

async function injectSession(context, session) {
  if (!session) return;

  // Inject cookies
  if (session.cookies?.length) {
    await context.addCookies(session.cookies);
    console.log(`🍪  Injected ${session.cookies.length} cookie(s)`);
  }

  // Inject localStorage / sessionStorage via page evaluate
  if (session.localStorage || session.sessionStorage) {
    const page = context.pages()[0];
    await page.evaluate(({ ls, ss }) => {
      if (ls) Object.entries(ls).forEach(([k, v]) => localStorage.setItem(k, v));
      if (ss) Object.entries(ss).forEach(([k, v]) => sessionStorage.setItem(k, v));
    }, { ls: session.localStorage, ss: session.sessionStorage });
    console.log('💾  Injected localStorage/sessionStorage');
  }
}

// ─── Multi-tab handler ────────────────────────────────────────────────────────

function attachMultiTabHandler(context, emit, sessionId, state) {
  context.on('page', async (newPage) => {
    try {
      await newPage.waitForLoadState('domcontentloaded');
      state.activePage = newPage;
      emit(sessionId, 'new_tab', {
        url: newPage.url(), title: await newPage.title(), total: context.pages().length,
      });
    } catch {}
  });
}

// ─── Vision Agent ─────────────────────────────────────────────────────────────
// Fully vision-driven automation — no DOM at all.
// Takes screenshot → asks LLM what to do → executes → repeat.
// Works on: canvas, iframes, shadow DOM, WebGL, anything visible.

async function runVisionAgent(page, task, emit, sessionId) {
  const history  = [];
  const maxSteps = 20;

  // Poll for live screenshots while thinking
  let frame = 0;
  const poll = setInterval(async () => {
    try {
      const buf = await page.screenshot({ type: 'jpeg', quality: 45 });
      emit(sessionId, 'agent_frame', {
        screenshot: `data:image/jpeg;base64,${buf.toString('base64')}`,
        url: page.url(), frame: ++frame,
      });
    } catch {}
  }, 1500);

  try {
    for (let step = 0; step < maxSteps; step++) {
      const buf    = await page.screenshot({ type: 'jpeg', quality: 80, fullPage: false });
      const base64 = buf.toString('base64');

      const historyStr = history.slice(-5).map((h, i) =>
        `${i+1}. ${h.action.type}: ${h.action.description}`
      ).join('\n');

      const raw = await llmCall({
        model:     VISION_MODEL,
        maxTokens: 200,
        messages: [{
          role: 'user',
          content: [
            { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${base64}`, detail: 'high' } },
            {
              type: 'text',
              text: `You are a browser automation agent completing this task: "${task}"
Current URL: ${page.url()}
Steps taken so far:
${historyStr || '(none yet)'}

Look at the screenshot and decide the SINGLE best next action.
Return ONLY valid JSON:
{
  "type": "click|type|scroll|done|navigate",
  "x": <pixel_x if click>,
  "y": <pixel_y if click>,
  "text": "<text to type if type action>",
  "scrollY": <pixels if scroll, positive=down>,
  "url": "<url if navigate>",
  "description": "what you are doing and why",
  "done": false,
  "result": "<final result summary if done>"
}`,
            },
          ],
        }],
      });

      let action;
      try { action = JSON.parse(raw.replace(/```json|```/g, '').trim()); }
      catch { action = { type: 'done', done: true, result: 'Could not parse action' }; }

      emit(sessionId, 'vision_action', { step, action, url: page.url() });
      history.push({ action, url: page.url() });

      if (action.done || action.type === 'done') {
        clearInterval(poll);
        const finalBuf = await page.screenshot({ type: 'jpeg', quality: 75 });
        return {
          success:    true,
          message:    action.result || 'Task complete',
          screenshot: `data:image/jpeg;base64,${finalBuf.toString('base64')}`,
          url:        page.url(),
          steps:      step + 1,
        };
      }

      // Execute the action
      if (action.type === 'click' && action.x && action.y) {
        await clickAtCoordinates(page, action.x, action.y);
        await sleep(800);
        await page.waitForLoadState('domcontentloaded').catch(() => {});

      } else if (action.type === 'type' && action.text) {
        await page.evaluate((text) => {
          const el = document.activeElement;
          if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) {
            el.value = text;
            el.dispatchEvent(new Event('input',  { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }, action.text);

      } else if (action.type === 'scroll') {
        await page.evaluate((dy) => window.scrollBy(0, dy), action.scrollY || 300);
        await sleep(400);

      } else if (action.type === 'navigate' && action.url) {
        await page.goto(action.url, { waitUntil: 'domcontentloaded', timeout: 15_000 });
      }
    }

    // Ran out of steps
    clearInterval(poll);
    const finalBuf = await page.screenshot({ type: 'jpeg', quality: 75 });
    return {
      success: false, message: `Hit ${maxSteps}-step limit`,
      screenshot: `data:image/jpeg;base64,${finalBuf.toString('base64')}`,
      url: page.url(), steps: maxSteps,
    };
  } catch (e) {
    clearInterval(poll);
    throw e;
  }
}

// ─── Scripted runner ──────────────────────────────────────────────────────────

async function runScriptedMode(stagehand, context, plan, session, sessionId) {
  // Inject auth session before any navigation
  if (session) await injectSession(context, session);

  const state = { activePage: context.pages()[0] };
  attachMultiTabHandler(context, emit, sessionId, state);

  let lastExtracted  = null;
  let allExtracted   = [];

  for (let i = 0; i < plan.steps.length; i++) {
    const step = plan.steps[i];

    emit(sessionId, 'step_start', {
      index: i, total: plan.steps.length,
      description: step.description, type: step.type,
    });

    try {
      if (step.type === 'navigate') {
        await state.activePage.goto(step.url, { waitUntil: 'domcontentloaded', timeout: 20_000 });
        if (step.waitFor) {
          await state.activePage.waitForSelector?.(step.waitFor, { timeout: 8_000 }).catch(() => {});
        }

      } else if (step.type === 'act') {
        // Full fallback chain: DOM → alternatives → vision
        await executeActStep(stagehand, state.activePage, step, emit, sessionId, i);

      } else if (step.type === 'extract') {
        const schemaType = inferSchemaType(step.instruction);
        const result     = await stagehand.extract(
          step.instruction, SCHEMAS[schemaType] ?? SCHEMAS.text,
          { ignoreSelectors: ['nav', 'footer', '.ad', '.cookie-banner', '[role="dialog"]'] },
        );
        lastExtracted = result;
        allExtracted.push({ schemaType, data: result });
        emit(sessionId, 'extracted', { index: i, schemaType, data: result });

      } else if (step.type === 'loop') {
        const loopResults = await executeLoopStep(stagehand, state, step, emit, sessionId, i);
        allExtracted      = [...allExtracted, ...loopResults];
        lastExtracted     = loopResults;

      } else if (step.type === 'wait') {
        await sleep(step.timeout || 2000);

      } else if (step.type === 'upload') {
        // File upload via CDP — setInputFiles equivalent
        try {
          await state.activePage.evaluate((sel) => {
            const input = document.querySelector(sel);
            if (input) input.focus();
          }, step.selector);
          // Note: actual file bytes must be provided; here we signal the intent
          emit(sessionId, 'step_warning', { index: i, warning: 'File upload requires filePath on server filesystem' });
        } catch {}
      }

      // Screenshot after every step
      const buf = await state.activePage.screenshot({ type: 'jpeg', quality: 65 });
      emit(sessionId, 'step_done', {
        index: i, description: step.description, type: step.type, status: 'done',
        url:        state.activePage.url(),
        screenshot: `data:image/jpeg;base64,${buf.toString('base64')}`,
        extracted:  step.type === 'extract' ? lastExtracted : null,
      });

    } catch (stepErr) {
      emit(sessionId, 'step_error', { index: i, description: step.description, error: stepErr.message });
    }

    await sleep(250);
  }

  const finalBuf = await state.activePage.screenshot({ type: 'jpeg', quality: 75 });
  return {
    url:        state.activePage.url(),
    screenshot: `data:image/jpeg;base64,${finalBuf.toString('base64')}`,
    extracted:  allExtracted.length > 0 ? allExtracted : lastExtracted,
  };
}

// ─── Agent runner ─────────────────────────────────────────────────────────────

async function runAgentMode(stagehand, context, prompt, sessionId) {
  const page  = context.pages()[0];
  const state = { activePage: page };
  attachMultiTabHandler(context, emit, sessionId, state);

  emit(sessionId, 'status', { text: '🤖  Agent starting…' });

  let frame = 0;
  const poll = setInterval(async () => {
    try {
      const buf = await state.activePage.screenshot({ type: 'jpeg', quality: 45 });
      emit(sessionId, 'agent_frame', {
        screenshot: `data:image/jpeg;base64,${buf.toString('base64')}`,
        url: state.activePage.url(), frame: ++frame,
      });
    } catch {}
  }, 1500);

  try {
    const agent  = stagehand.agent();
    const result = await agent.execute({ instruction: prompt, maxSteps: 15 });
    clearInterval(poll);

    const actions = result.actions ?? [];
    for (let i = 0; i < actions.length; i++) {
      emit(sessionId, 'step_done', {
        index: i, total: actions.length, status: 'done',
        description: actions[i].description || actions[i].type || 'Agent action', type: 'act',
        url: state.activePage.url(),
      });
    }

    const finalBuf = await state.activePage.screenshot({ type: 'jpeg', quality: 75 });
    return {
      url:        state.activePage.url(),
      screenshot: `data:image/jpeg;base64,${finalBuf.toString('base64')}`,
      extracted:  null,
    };
  } finally {
    clearInterval(poll);
  }
}

// ─── Core entry ───────────────────────────────────────────────────────────────

async function runAutomation(prompt, sessionId, mode = 'scripted', session = null) {
  let stagehand;
  try {
    emit(sessionId, 'status', { text: '🔐  Checking token…' });
    await tokenManager.getToken();

    let plan = null;
    if (mode === 'scripted') {
      emit(sessionId, 'status', { text: '🧠  Planning…' });
      plan = await generatePlan(prompt);
      emit(sessionId, 'plan', { goal: plan.goal, totalSteps: plan.steps.length, startUrl: plan.startUrl });
    } else if (mode === 'vision') {
      emit(sessionId, 'plan', { goal: prompt, totalSteps: '?', startUrl: '' });
    } else {
      emit(sessionId, 'plan', { goal: prompt, totalSteps: '?', startUrl: '' });
    }

    emit(sessionId, 'status', { text: '🌐  Starting browser…' });
    stagehand = createStagehand();
    const { context } = await stagehand.init();
    const page        = context.pages()[0];

    // Inject session before anything touches the browser
    if (session && mode !== 'vision') await injectSession(context, session);

    emit(sessionId, 'browser_ready', { text: 'Browser ready ✓' });

    let result;
    if (mode === 'vision') {
      result = await runVisionAgent(page, prompt, emit, sessionId);
    } else if (mode === 'agent') {
      result = await runAgentMode(stagehand, context, prompt, sessionId);
    } else {
      result = await runScriptedMode(stagehand, context, plan, null, sessionId);
    }

    emit(sessionId, 'done', {
      url:        result.url,
      screenshot: result.screenshot,
      extracted:  result.extracted ?? null,
      goal:       plan?.goal ?? prompt,
      mode,
    });

    return { success: true, extracted: result.extracted, goal: plan?.goal ?? prompt };

  } catch (err) {
    console.error(`[${sessionId}] Fatal:`, err.message);
    emit(sessionId, 'error', { message: err.message });
    return { success: false, error: err.message };
  } finally {
    try { await stagehand?.close(); } catch {}
    const client = sseClients.get(sessionId);
    if (client) {
      client.write('event: close\ndata: {}\n\n');
      client.end();
      sseClients.delete(sessionId);
    }
  }
}

// ─── Playwright export ────────────────────────────────────────────────────────

function buildPlaywrightScript(prompt, goal, resolvedSteps) {
  const stepCode = resolvedSteps.map((s, i) => {
    const lines = [`    // Step ${i+1}: ${s.description}`];
    if (s.type === 'navigate') {
      lines.push(`    await page.goto('${s.url}', { waitUntil: 'domcontentloaded' });`);
    } else if (s.type === 'act') {
      if (s.stability === 'low') lines.push(`    // ⚠️  ${s.note || 'Fragile — add data-testid'}`);
      if (s.inShadow) lines.push(`    // 🌑  Shadow DOM element — pierce/ prefix used`);
      const m = s.method || 'click';
      if (m === 'fill' || m === 'type') lines.push(`    await page.locator('${s.selector}').fill('YOUR_VALUE');`);
      else lines.push(`    await page.locator('${s.selector}').${m}();`);
    } else if (s.type === 'wait') {
      lines.push(`    await page.waitForTimeout(${s.timeout || 2000});`);
    } else if (s.type === 'extract') {
      lines.push(`    const data${i+1} = await page.evaluate(() => document.body.innerText);`);
      lines.push(`    console.log('Step ${i+1}:', data${i+1}.slice(0, 500));`);
    } else if (s.type === 'loop') {
      lines.push(`    // Loop: ${s.description}`);
      lines.push(`    // Add pagination loop logic here`);
    }
    return lines.join('\n');
  }).join('\n\n');

  return `// Auto-generated by Director  |  ${new Date().toISOString()}
// Task: ${prompt}
// Goal: ${goal}
// Run:  node automation.js  (requires: npm install playwright && npx playwright install chromium)

const { chromium } = require('playwright');

async function run() {
  const browser = await chromium.launch({ headless: false });
  const page    = await (await browser.newContext()).newPage();
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

  try {
${stepCode}
    console.log('✅ Done');
  } catch (e) {
    console.error('❌', e.message);
    await page.screenshot({ path: 'error.png' });
    throw e;
  } finally {
    await browser.close();
  }
}

run().catch(console.error);
`;
}

// ─── Express ──────────────────────────────────────────────────────────────────

const app        = express();
const sseClients = new Map();

app.use(cors());
app.use(express.json({ limit: '2mb' })); // allow session payloads

app.get('/stream/:sessionId', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
  res.write('event: connected\ndata: {}\n\n');
  sseClients.set(req.params.sessionId, res);
  req.on('close', () => sseClients.delete(req.params.sessionId));
});

function emit(sessionId, event, data) {
  sseClients.get(sessionId)?.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

// Run automation — mode: scripted | agent | vision
// session: optional { cookies, localStorage, sessionStorage }
app.post('/automate', async (req, res) => {
  const { prompt, mode = 'scripted', session = null } = req.body;
  if (!prompt?.trim()) return res.status(400).json({ error: 'prompt required' });
  const sessionId = randomUUID();
  res.json({ sessionId });
  setTimeout(() => runAutomation(prompt, sessionId, mode, session), 400);
});

// Export to Playwright script
app.post('/export', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt?.trim()) return res.status(400).json({ error: 'prompt required' });
  let stagehand;
  try {
    await tokenManager.getToken();
    const plan = await generatePlan(prompt);
    stagehand  = createStagehand();
    const { context } = await stagehand.init();
    const page  = context.pages()[0];
    const state = { activePage: page };
    attachMultiTabHandler(context, () => {}, '', state);
    const resolvedSteps = [];
    for (const step of plan.steps) {
      if (step.type === 'navigate') {
        await state.activePage.goto(step.url, { waitUntil: 'domcontentloaded', timeout: 20_000 });
        resolvedSteps.push({ ...step });
      } else if (step.type === 'act') {
        const observed = await stagehand.observe(step.instruction);
        const raw      = observed?.[0];
        if (raw?.selector) {
          const best = await getBestLocator(state.activePage, raw.selector, step.description);
          resolvedSteps.push({ ...step, ...best, method: raw.method });
        } else {
          resolvedSteps.push({ ...step, selector: '/* not found */', stability: 'low' });
        }
        await stagehand.act(step.instruction);
      } else {
        resolvedSteps.push({ ...step });
      }
    }
    const script   = buildPlaywrightScript(prompt, plan.goal, resolvedSteps);
    const filename = `automation-${Date.now()}.js`;
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(script);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    try { await stagehand?.close(); } catch {}
  }
});

// ── Schedules ─────────────────────────────────────────────────────────────────

app.get('/schedules', (_, res) => res.json(listSchedules()));

app.post('/schedules', (req, res) => {
  const { prompt, mode, cronExpression, humanReadable } = req.body;
  if (!prompt || !cronExpression) return res.status(400).json({ error: 'prompt and cronExpression required' });
  if (!cron.validate(cronExpression)) return res.status(400).json({ error: 'invalid cron' });
  const schedule = createSchedule({ prompt, mode, cronExpression, humanReadable });
  registerCron(schedule);
  res.status(201).json(schedule);
});

app.put('/schedules/:id', (req, res) => {
  const updated = updateSchedule(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'not found' });
  if (updated.enabled) registerCron(updated); else unregisterCron(updated.id);
  res.json(updated);
});

app.delete('/schedules/:id', (req, res) => {
  unregisterCron(req.params.id); deleteSchedule(req.params.id);
  res.json({ ok: true });
});

app.post('/schedules/:id/run', async (req, res) => {
  const schedule = getSchedule(req.params.id);
  if (!schedule) return res.status(404).json({ error: 'not found' });
  const sessionId = randomUUID();
  res.json({ sessionId });
  setTimeout(async () => {
    const result = await runAutomation(schedule.prompt, sessionId, schedule.mode);
    saveResult({
      scheduleId: schedule.id, status: result.success ? 'success' : 'error',
      extracted:  typeof result.extracted === 'object'
        ? JSON.stringify(result.extracted) : result.extracted,
      goal: result.goal, error: result.error,
    });
  }, 400);
});

app.get('/health', (_, res) => res.json({ ok: true, modes: ['scripted', 'agent', 'vision'] }));

// ─── Scheduler ────────────────────────────────────────────────────────────────

const cronJobs = new Map();

function startScheduler() {
  const schedules = listSchedules();
  schedules.forEach(s => { if (s.enabled) registerCron(s); });
  console.log(`⏰  Scheduler: ${schedules.filter(s=>s.enabled).length} active job(s)`);
}

function registerCron(schedule) {
  if (cronJobs.has(schedule.id)) cronJobs.get(schedule.id).stop();
  if (!cron.validate(schedule.cronExpression)) return;
  const task = cron.schedule(schedule.cronExpression, async () => {
    console.log(`⏰  Running: "${schedule.prompt}"`);
    const sessionId = randomUUID();
    sseClients.set(sessionId, { write: () => {} });
    const result = await runAutomation(schedule.prompt, sessionId, schedule.mode);
    saveResult({
      scheduleId: schedule.id, status: result.success ? 'success' : 'error',
      extracted:  typeof result.extracted === 'object'
        ? JSON.stringify(result.extracted) : result.extracted,
      goal: result.goal, error: result.error,
    });
    sseClients.delete(sessionId);
  });
  cronJobs.set(schedule.id, task);
}

function unregisterCron(id) {
  if (cronJobs.has(id)) { cronJobs.get(id).stop(); cronJobs.delete(id); }
}

// ─── Utils + Start ────────────────────────────────────────────────────────────

const sleep = ms => new Promise(r => setTimeout(r, ms));

startScheduler();

app.listen(PORT, () => {
  console.log(`\n🎬  Director → http://localhost:${PORT}`);
  console.log(`   Gateway      : ${LLM_BASE_URL}`);
  console.log(`   LLM Model    : ${LLM_MODEL}`);
  console.log(`   Vision Model : ${VISION_MODEL}`);
  console.log(`   Modes        : scripted | agent | vision\n`);
});
