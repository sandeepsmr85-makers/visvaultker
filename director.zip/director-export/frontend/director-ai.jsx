import { useState, useEffect, useRef } from "react";

const BACKEND = "http://localhost:3001";

const CRON_PRESETS = [
  { label:"Every hour",           cron:"0 * * * *"    },
  { label:"Every day at 9am",     cron:"0 9 * * *"    },
  { label:"Weekdays at 9am",      cron:"0 9 * * 1-5"  },
  { label:"Every 30 minutes",     cron:"*/30 * * * *" },
  { label:"Custom…",              cron:""              },
];

const MODES = [
  { id:"scripted", icon:"⚡", label:"Scripted",
    desc:"Plan → observe → act with DOM. Uses cache. Best for known repeatable flows." },
  { id:"agent",    icon:"🤖", label:"Agent",
    desc:"Stagehand agent — reasons autonomously, handles unexpected modals and redirects." },
  { id:"vision",   icon:"👁️", label:"Vision",
    desc:"Screenshot-only. No DOM. Works on canvas, iframes, shadow DOM, any visible UI." },
];

const TYPE_ICONS   = { navigate:"🌐", act:"🖱️", extract:"📋", loop:"🔁", wait:"⏳", upload:"📤" };
const STAB_COLOR   = { high:"#6ee7b7", medium:"#fbbf24", "low-medium":"#fb923c", low:"#f87171" };
const STATUS_COLOR = { success:"#6ee7b7", error:"#f87171" };

// ─── Small reusable components ────────────────────────────────────────────────

function Badge({ children, color="#60a5fa", bg="#0f1629", border="#1e3a5f" }) {
  return <span style={{ background:bg, border:`1px solid ${border}`, borderRadius:4,
    padding:"2px 7px", fontSize:10, color, letterSpacing:".04em", flexShrink:0 }}>{children}</span>;
}

function Spinner({ size=16, color="#3b82f6" }) {
  return <div style={{ width:size, height:size, borderRadius:"50%", flexShrink:0,
    border:`2px solid ${color}`, borderTopColor:"transparent", animation:"spin .8s linear infinite" }} />;
}

function Tag({ label, color="#444", bg="#111" }) {
  return <span style={{ background:bg, borderRadius:4, padding:"1px 5px",
    fontSize:9, color, fontFamily:"monospace", flexShrink:0 }}>{label}</span>;
}

// ─── Code Modal ───────────────────────────────────────────────────────────────

function CodeModal({ code, filename, onClose }) {
  const dl = () => {
    const a = Object.assign(document.createElement("a"), {
      href: URL.createObjectURL(new Blob([code], { type:"application/javascript" })),
      download: filename,
    });
    a.click();
  };
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.88)", zIndex:200,
      display:"flex", alignItems:"center", justifyContent:"center", padding:24 }}
      onClick={e => e.target===e.currentTarget && onClose()}>
      <div style={{ background:"#080808", border:"1px solid #1a1a1a", borderRadius:14,
        width:"100%", maxWidth:820, maxHeight:"85vh", display:"flex", flexDirection:"column" }}>
        <div style={{ padding:"13px 18px", borderBottom:"1px solid #111",
          display:"flex", alignItems:"center", justifyContent:"space-between", flexShrink:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <span>📄</span>
            <span style={{ fontWeight:600, fontSize:13 }}>{filename}</span>
            <Badge>Playwright · Node.js</Badge>
          </div>
          <div style={{ display:"flex", gap:7 }}>
            {[["Copy", () => navigator.clipboard.writeText(code), "#111","#aaa"],
              ["↓ Download", dl, "#3b82f6","white"]].map(([l,fn,bg,c]) => (
              <button key={l} onClick={fn}
                style={{ background:bg, border:bg==="#111"?"1px solid #222":"none",
                  borderRadius:7, padding:"5px 12px", fontSize:12, color:c, cursor:"pointer",
                  fontWeight:bg==="#3b82f6"?500:400 }}>{l}</button>
            ))}
            <button onClick={onClose}
              style={{ background:"transparent", border:"1px solid #1a1a1a", borderRadius:7,
                padding:"5px 9px", fontSize:12, color:"#444", cursor:"pointer" }}>✕</button>
          </div>
        </div>
        <div style={{ padding:"6px 18px", borderBottom:"1px solid #0a0a0a",
          display:"flex", gap:12, flexShrink:0 }}>
          {Object.entries({high:"Stable",medium:"Good","low-medium":"Ok",low:"Fragile"}).map(([k,v]) => (
            <div key={k} style={{ display:"flex", alignItems:"center", gap:4 }}>
              <div style={{ width:6, height:6, borderRadius:"50%", background:STAB_COLOR[k] }} />
              <span style={{ color:"#333", fontSize:10 }}>{v}</span>
            </div>
          ))}
          <code style={{ color:"#3b82f6", fontSize:9, marginLeft:"auto" }}>node {filename}</code>
        </div>
        <pre style={{ flex:1, overflowY:"auto", margin:0, padding:"14px 18px",
          fontSize:11, fontFamily:"JetBrains Mono,monospace", color:"#ccc",
          lineHeight:1.75, whiteSpace:"pre-wrap", wordBreak:"break-word" }}>
          {code.split('\n').map((line, i) => (
            <span key={i} style={{ color:
              line.includes('⚠️')?'#f87171':line.includes('✅')?'#6ee7b7':
              line.includes('🌑')?'#a78bfa':line.trim().startsWith('// Step')?'#60a5fa':
              line.trim().startsWith('//')?'#2a2a2a':'#ccc' }}>{line}{'\n'}</span>
          ))}
        </pre>
      </div>
    </div>
  );
}

// ─── Session Config Panel ─────────────────────────────────────────────────────

function SessionPanel({ session, onChange }) {
  const [open, setOpen] = useState(false);
  const [raw,  setRaw]  = useState(JSON.stringify(session || {}, null, 2));
  const [err,  setErr]  = useState(null);

  function apply() {
    try { onChange(JSON.parse(raw)); setErr(null); setOpen(false); }
    catch (e) { setErr(e.message); }
  }

  return (
    <div style={{ width:"100%" }}>
      <button onClick={() => setOpen(!open)}
        style={{ background:"transparent", border:"1px solid #1a1a1a", borderRadius:7,
          padding:"6px 12px", fontSize:12, color: session?"#fbbf24":"#444",
          cursor:"pointer", display:"flex", alignItems:"center", gap:6 }}>
        {session ? "🍪 Session configured" : "🔑 Inject session (cookies / localStorage)"}
        <span style={{ color:"#333", fontSize:10 }}>{open?"▲":"▼"}</span>
      </button>
      {open && (
        <div style={{ marginTop:8, background:"#080808", border:"1px solid #1a1a1a",
          borderRadius:10, padding:14, animation:"fadeIn .2s ease" }}>
          <div style={{ fontSize:11, color:"#555", marginBottom:8, lineHeight:1.6 }}>
            JSON with optional keys: <code style={{ color:"#60a5fa" }}>cookies</code>, <code style={{ color:"#60a5fa" }}>localStorage</code>, <code style={{ color:"#60a5fa" }}>sessionStorage</code>
          </div>
          <textarea value={raw} onChange={e => setRaw(e.target.value)} rows={7}
            style={{ width:"100%", background:"#0a0a0a", border:"1px solid #1e1e1e",
              borderRadius:7, padding:"9px 11px", fontSize:11,
              fontFamily:"JetBrains Mono,monospace", color:"#ccc", resize:"vertical", outline:"none" }} />
          {err && <div style={{ color:"#f87171", fontSize:11, marginTop:5 }}>{err}</div>}
          <div style={{ display:"flex", gap:8, marginTop:8 }}>
            <button onClick={apply}
              style={{ background:"#3b82f6", border:"none", borderRadius:7, padding:"6px 14px",
                fontSize:12, color:"white", cursor:"pointer", fontWeight:500 }}>Apply</button>
            <button onClick={() => { onChange(null); setOpen(false); }}
              style={{ background:"transparent", border:"1px solid #1e1e1e", borderRadius:7,
                padding:"6px 12px", fontSize:12, color:"#555", cursor:"pointer" }}>Clear</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Schedule modal ───────────────────────────────────────────────────────────

function ScheduleModal({ prompt: initial, onSave, onClose }) {
  const [p, setP]         = useState(initial || "");
  const [mode, setMode]   = useState("scripted");
  const [preset, setPreset] = useState(0);
  const [custom, setCustom] = useState("");
  const [saving, setSaving] = useState(false);

  const cronVal  = preset < CRON_PRESETS.length-1 ? CRON_PRESETS[preset].cron : custom;
  const cronLabel= preset < CRON_PRESETS.length-1 ? CRON_PRESETS[preset].label : custom;

  async function save() {
    if (!p.trim()||!cronVal.trim()) return;
    setSaving(true);
    try { await onSave({ prompt:p, mode, cronExpression:cronVal, humanReadable:cronLabel }); }
    finally { setSaving(false); }
  }

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.85)", zIndex:200,
      display:"flex", alignItems:"center", justifyContent:"center", padding:24 }}
      onClick={e => e.target===e.currentTarget && onClose()}>
      <div style={{ background:"#0a0a0a", border:"1px solid #1e1e1e", borderRadius:14,
        width:"100%", maxWidth:500, animation:"fadeIn .2s ease" }}>
        <div style={{ padding:"15px 20px", borderBottom:"1px solid #111",
          display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <span style={{ fontWeight:600, fontSize:14 }}>⏰ Schedule automation</span>
          <button onClick={onClose}
            style={{ background:"transparent", border:"none", color:"#444", cursor:"pointer", fontSize:16 }}>✕</button>
        </div>
        <div style={{ padding:"18px 20px", display:"flex", flexDirection:"column", gap:14 }}>
          <div>
            <label style={{ fontSize:11, color:"#555", display:"block", marginBottom:5 }}>Task</label>
            <textarea value={p} onChange={e=>setP(e.target.value)} rows={3}
              style={{ width:"100%", background:"#0d0d0d", border:"1px solid #1e1e1e", borderRadius:8,
                padding:"9px 11px", fontSize:13, color:"#ddd", fontFamily:"inherit", resize:"none", outline:"none" }} />
          </div>
          <div>
            <label style={{ fontSize:11, color:"#555", display:"block", marginBottom:8 }}>Mode</label>
            <div style={{ display:"flex", gap:6 }}>
              {MODES.map(m => (
                <button key={m.id} onClick={() => setMode(m.id)}
                  style={{ flex:1, padding:"7px 8px", borderRadius:8, cursor:"pointer", fontFamily:"inherit",
                    border:`1px solid ${mode===m.id?"#3b82f6":"#1a1a1a"}`,
                    background: mode===m.id ? "#0f1629" : "#090909",
                    color: mode===m.id ? "#60a5fa" : "#444", fontSize:12 }}>
                  {m.icon} {m.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label style={{ fontSize:11, color:"#555", display:"block", marginBottom:8 }}>Frequency</label>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:5 }}>
              {CRON_PRESETS.map((c,i) => (
                <button key={i} onClick={() => setPreset(i)}
                  style={{ padding:"7px 10px", borderRadius:7, cursor:"pointer", fontFamily:"inherit",
                    textAlign:"left", fontSize:12, border:`1px solid ${preset===i?"#3b82f6":"#1a1a1a"}`,
                    background: preset===i?"#0f1629":"#090909",
                    color: preset===i?"#60a5fa":"#444" }}>{c.label}</button>
              ))}
            </div>
            {preset===CRON_PRESETS.length-1 && (
              <input value={custom} onChange={e=>setCustom(e.target.value)}
                placeholder="0 9 * * 1-5" style={{ marginTop:7, width:"100%",
                  background:"#0d0d0d", border:"1px solid #1e1e1e", borderRadius:7,
                  padding:"8px 11px", fontSize:12, color:"#ddd",
                  fontFamily:"monospace", outline:"none" }} />
            )}
          </div>
          <button onClick={save} disabled={saving||!p.trim()||!cronVal.trim()}
            style={{ background:"#3b82f6", border:"none", borderRadius:8, padding:"10px",
              fontSize:13, fontWeight:500, color:"white", cursor:"pointer",
              opacity:saving||!p.trim()||!cronVal.trim()?0.4:1 }}>
            {saving ? "Saving…" : "Create schedule"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Schedules tab ────────────────────────────────────────────────────────────

function SchedulesTab({ onRunNow }) {
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [modal, setModal]         = useState(false);
  const [expanded, setExpanded]   = useState(null);

  const load = async () => {
    setLoading(true);
    try { setSchedules(await (await fetch(`${BACKEND}/schedules`)).json()); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const toggle = async (s) => {
    await fetch(`${BACKEND}/schedules/${s.id}`, {
      method:"PUT", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ enabled:!s.enabled }),
    });
    load();
  };

  const remove = async (s) => {
    if (!confirm(`Delete "${s.prompt.slice(0,50)}…"?`)) return;
    await fetch(`${BACKEND}/schedules/${s.id}`, { method:"DELETE" });
    load();
  };

  const runNow = async (s) => {
    const { sessionId } = await (await fetch(`${BACKEND}/schedules/${s.id}/run`, { method:"POST" })).json();
    onRunNow(s.prompt, sessionId, s.mode);
  };

  const save = async (data) => {
    await fetch(`${BACKEND}/schedules`, {
      method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data),
    });
    setModal(false); load();
  };

  return (
    <div style={{ maxWidth:720, margin:"0 auto", padding:"30px 24px", width:"100%" }}>
      {modal && <ScheduleModal onSave={save} onClose={() => setModal(false)} />}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:22 }}>
        <div>
          <h2 style={{ fontWeight:600, fontSize:17, color:"#e0e0e0", letterSpacing:"-0.02em" }}>Scheduled automations</h2>
          <p style={{ color:"#333", fontSize:12, marginTop:3 }}>Run automations automatically on a cron schedule</p>
        </div>
        <button onClick={() => setModal(true)}
          style={{ background:"#3b82f6", border:"none", borderRadius:8, padding:"7px 14px",
            fontSize:12, fontWeight:500, color:"white", cursor:"pointer" }}>+ New</button>
      </div>

      {loading
        ? <div style={{ display:"flex", justifyContent:"center", padding:50 }}><Spinner size={22}/></div>
        : schedules.length === 0
          ? <div style={{ textAlign:"center", padding:50, color:"#222", fontSize:13 }}>
              No schedules yet
            </div>
          : schedules.map(s => (
            <div key={s.id} style={{ background:"#090909", border:"1px solid #111",
              borderRadius:11, marginBottom:8, overflow:"hidden" }}>
              <div style={{ padding:"12px 14px", display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ width:7, height:7, borderRadius:"50%", flexShrink:0,
                  background:s.enabled?"#6ee7b7":"#1e1e1e",
                  boxShadow:s.enabled?"0 0 5px #6ee7b740":"none" }} />
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:12, color:"#bbb", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{s.prompt}</div>
                  <div style={{ display:"flex", gap:7, marginTop:4, alignItems:"center" }}>
                    <Badge>{s.humanReadable || s.cronExpression}</Badge>
                    <Badge color={s.mode==="vision"?"#c084fc":s.mode==="agent"?"#a78bfa":"#60a5fa"}
                      bg={s.mode==="vision"?"#180a2e":s.mode==="agent"?"#1a0f2e":"#0f1629"}
                      border={s.mode==="vision"?"#6b21a8":s.mode==="agent"?"#4c1d95":"#1e3a5f"}>
                      {s.mode==="vision"?"👁️":s.mode==="agent"?"🤖":"⚡"} {s.mode}
                    </Badge>
                    {s.lastRun && <span style={{ fontSize:9, color:"#222" }}>{new Date(s.lastRun).toLocaleString()}</span>}
                    {s.lastStatus && <div style={{ width:5, height:5, borderRadius:"50%", background:STATUS_COLOR[s.lastStatus]||"#333" }} />}
                  </div>
                </div>
                <div style={{ display:"flex", gap:5, flexShrink:0 }}>
                  <button onClick={() => setExpanded(expanded===s.id?null:s.id)}
                    style={{ background:"#0d0d0d", border:"1px solid #1a1a1a", borderRadius:6,
                      padding:"4px 9px", fontSize:10, color:"#444", cursor:"pointer" }}>
                    {expanded===s.id?"hide":"history"}
                  </button>
                  <button onClick={() => runNow(s)}
                    style={{ background:"#0f1629", border:"1px solid #1e3a5f", borderRadius:6,
                      padding:"4px 9px", fontSize:10, color:"#60a5fa", cursor:"pointer" }}>▶</button>
                  <button onClick={() => toggle(s)}
                    style={{ background:s.enabled?"#0a1a0a":"#0d0d0d",
                      border:`1px solid ${s.enabled?"#14532d":"#1a1a1a"}`,
                      borderRadius:6, padding:"4px 9px", fontSize:10,
                      color:s.enabled?"#6ee7b7":"#444", cursor:"pointer" }}>
                    {s.enabled?"on":"off"}
                  </button>
                  <button onClick={() => remove(s)}
                    style={{ background:"transparent", border:"1px solid #1e0a0a", borderRadius:6,
                      padding:"4px 7px", fontSize:10, color:"#3a1010", cursor:"pointer" }}>✕</button>
                </div>
              </div>
              {expanded===s.id && s.history?.length>0 && (
                <div style={{ borderTop:"1px solid #0d0d0d", padding:"10px 14px" }}>
                  {s.history.map((r,i) => (
                    <div key={i} style={{ display:"flex", gap:9, padding:"5px 0",
                      borderBottom:"1px solid #0a0a0a", fontSize:10 }}>
                      <div style={{ width:5, height:5, borderRadius:"50%", marginTop:4, flexShrink:0,
                        background:STATUS_COLOR[r.status]||"#444" }} />
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ color:"#2a2a2a" }}>{new Date(r.runAt).toLocaleString()}</div>
                        {r.extracted && (
                          <div style={{ color:"#1e2e1e", fontFamily:"monospace", marginTop:2,
                            overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                            {typeof r.extracted==="object"?JSON.stringify(r.extracted):r.extracted}
                          </div>
                        )}
                        {r.error && <div style={{ color:"#4a1a1a", marginTop:2 }}>{r.error}</div>}
                      </div>
                      <span style={{ color:STATUS_COLOR[r.status]||"#444", flexShrink:0 }}>{r.status}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))
      }
    </div>
  );
}

// ─── Extracted data viewer ────────────────────────────────────────────────────

function ExtractedView({ data, schemaType }) {
  if (!data) return null;
  if (schemaType==='table' && data.rows?.length) {
    const headers = data.headers || Object.keys(data.rows[0]||{});
    return (
      <div style={{ overflowX:"auto" }}>
        <table style={{ width:"100%", borderCollapse:"collapse", fontSize:10.5 }}>
          <thead>
            <tr>{headers.map(h => <th key={h} style={{ padding:"4px 8px",
              borderBottom:"1px solid #1a1a1a", color:"#60a5fa", fontWeight:500,
              textAlign:"left", whiteSpace:"nowrap" }}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {data.rows.slice(0,6).map((r,i) => (
              <tr key={i}>{Object.values(r).map((v,j) => (
                <td key={j} style={{ padding:"3px 8px", borderBottom:"1px solid #0d0d0d",
                  color:"#777", maxWidth:120, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                  {String(v)}
                </td>
              ))}</tr>
            ))}
          </tbody>
        </table>
        {data.rows.length>6 && <div style={{ color:"#222", fontSize:9, padding:"4px 8px" }}>+{data.rows.length-6} rows</div>}
      </div>
    );
  }
  if (schemaType==='keyValue' && data.fields) {
    return Object.entries(data.fields).map(([k,v]) => (
      <div key={k} style={{ display:"flex", gap:10, padding:"2px 0", fontSize:11 }}>
        <span style={{ color:"#60a5fa", flexShrink:0, minWidth:80 }}>{k}</span>
        <span style={{ color:"#777" }}>{v}</span>
      </div>
    ));
  }
  if (schemaType==='list' && data.items) {
    return data.items.slice(0,8).map((item,i) => (
      <div key={i} style={{ fontSize:11, color:"#777", padding:"2px 0",
        display:"flex", gap:7 }}>
        <span style={{ color:"#222" }}>{i+1}.</span>{item}
      </div>
    ));
  }
  const text = typeof data==='string' ? data : data.data || JSON.stringify(data);
  return <div style={{ fontSize:11, color:"#777", lineHeight:1.6, whiteSpace:"pre-wrap" }}>{text.slice(0,400)}</div>;
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function DirectorAI() {
  const [tab,    setTab]    = useState("run");
  const [mode,   setMode]   = useState("scripted");
  const [prompt, setPrompt] = useState("");
  const [phase,  setPhase]  = useState("home");
  const [session,setSession]= useState(null);

  const [steps,         setSteps]        = useState([]);
  const [currentUrl,    setCurrentUrl]   = useState("");
  const [screenshot,    setScreenshot]   = useState(null);
  const [goal,          setGoal]         = useState("");
  const [extractedList, setExtractedList]= useState([]);  // array of {schemaType, data}
  const [errorMsg,      setErrorMsg]     = useState("");
  const [inputFocused,  setInputFocused] = useState(false);
  const [totalSteps,    setTotalSteps]   = useState(0);
  const [statusText,    setStatusText]   = useState("");
  const [agentFrames,   setAgentFrames]  = useState(0);
  const [newTabs,       setNewTabs]      = useState(0);
  const [loopStates,    setLoopStates]   = useState({});   // index → {iter, max}
  const [visionActions, setVisionActions]= useState([]);
  const [exporting,     setExporting]    = useState(false);
  const [exportCode,    setExportCode]   = useState(null);
  const [exportFile,    setExportFile]   = useState(null);
  const [showSchedule,  setShowSchedule] = useState(false);

  const logRef = useRef(null);
  const esRef  = useRef(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [steps, statusText, visionActions, loopStates]);

  function reset() {
    esRef.current?.close();
    setPhase("home"); setPrompt(""); setSteps([]);
    setCurrentUrl(""); setScreenshot(null); setGoal("");
    setExtractedList([]); setErrorMsg(""); setTotalSteps(0);
    setStatusText(""); setAgentFrames(0); setNewTabs(0);
    setLoopStates({}); setVisionActions([]);
    setExportCode(null); setExportFile(null);
  }

  function openStream(sessionId) {
    const es = new EventSource(`${BACKEND}/stream/${sessionId}`);
    esRef.current = es;

    es.addEventListener("connected",     ()  => setStatusText("Connected ✓"));
    es.addEventListener("status",        (e) => setStatusText(JSON.parse(e.data).text));
    es.addEventListener("browser_ready", (e) => setStatusText(JSON.parse(e.data).text));

    es.addEventListener("plan", (e) => {
      const d = JSON.parse(e.data);
      setGoal(d.goal); setTotalSteps(d.totalSteps); setCurrentUrl(d.startUrl||"");
      setStatusText(`Plan ready`);
    });

    es.addEventListener("new_tab", (e) => {
      const d = JSON.parse(e.data);
      setNewTabs(d.total||1); setCurrentUrl(d.url);
    });

    es.addEventListener("preflight", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index
        ? {...s, preflight: d.found?"found":"missing"} : s));
    });

    es.addEventListener("retry", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index
        ? {...s, retried:true, retryReason:d.reason} : s));
    });

    es.addEventListener("vision_fallback", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index
        ? {...s, visionFallback:true, visionReason:d.reason} : s));
    });

    es.addEventListener("vision_result", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index
        ? {...s, visionConfidence:d.confidence, visionFound:d.found, visionNote:d.note} : s));
    });

    es.addEventListener("step_validated", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index
        ? {...s, validated:true, outcomeMet:d.met} : s));
    });

    es.addEventListener("step_warning", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index
        ? {...s, warning:d.warning} : s));
    });

    es.addEventListener("loop_start", (e) => {
      const d = JSON.parse(e.data);
      setLoopStates(prev => ({...prev, [d.index]: {iter:0, max:d.max, active:true}}));
    });

    es.addEventListener("loop_iteration", (e) => {
      const d = JSON.parse(e.data);
      setLoopStates(prev => ({...prev, [d.index]: {...(prev[d.index]||{}), iter:d.iteration+1}}));
    });

    es.addEventListener("loop_end", (e) => {
      const d = JSON.parse(e.data);
      setLoopStates(prev => ({...prev, [d.index]: {...(prev[d.index]||{}), active:false, reason:d.reason}}));
    });

    es.addEventListener("step_start", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => [...prev, {...d, status:"running"}]);
    });

    es.addEventListener("step_done", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index ? {...s,...d,status:"done"} : s));
      setCurrentUrl(d.url||"");
      if (d.screenshot) setScreenshot(d.screenshot);
    });

    es.addEventListener("extracted", (e) => {
      const d = JSON.parse(e.data);
      setExtractedList(prev => [...prev, {schemaType:d.schemaType||"text", data:d.data}]);
    });

    es.addEventListener("step_error", (e) => {
      const d = JSON.parse(e.data);
      setSteps(prev => prev.map(s => s.index===d.index ? {...s,status:"error",error:d.error} : s));
    });

    es.addEventListener("agent_frame", (e) => {
      const d = JSON.parse(e.data);
      setScreenshot(d.screenshot); setCurrentUrl(d.url); setAgentFrames(d.frame);
    });

    es.addEventListener("vision_action", (e) => {
      const d = JSON.parse(e.data);
      setVisionActions(prev => [...prev, d]);
      setCurrentUrl(d.url||"");
    });

    es.addEventListener("done", (e) => {
      const d = JSON.parse(e.data);
      setCurrentUrl(d.url); setPhase("done"); setStatusText("Done ✓");
      if (d.screenshot) setScreenshot(d.screenshot);
      es.close();
    });

    es.addEventListener("error", (e) => {
      try { const d = JSON.parse(e.data); setPhase("error"); setErrorMsg(d.message); } catch {}
      es.close();
    });

    es.addEventListener("close", () => es.close());
  }

  async function runAutomation(text, m=mode) {
    if (!text.trim()) return;
    setPhase("running"); setSteps([]); setScreenshot(null);
    setExtractedList([]); setErrorMsg(""); setGoal(""); setCurrentUrl("");
    setStatusText("Connecting…"); setAgentFrames(0); setNewTabs(0);
    setLoopStates({}); setVisionActions([]); setExportCode(null);

    let sessionId;
    try {
      const res = await fetch(`${BACKEND}/automate`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ prompt:text, mode:m, session }),
      });
      if (!res.ok) throw new Error(`Backend ${res.status}`);
      sessionId = (await res.json()).sessionId;
    } catch (e) {
      setPhase("error"); setErrorMsg(`Could not reach ${BACKEND}\n\n${e.message}`); return;
    }
    openStream(sessionId);
  }

  async function startFromSessionId(p, sessionId, m) {
    setPrompt(p); setPhase("running"); setMode(m);
    setSteps([]); setScreenshot(null); setExtractedList([]); setErrorMsg("");
    setGoal(""); setCurrentUrl(""); setStatusText("Connecting…");
    setAgentFrames(0); setNewTabs(0); setLoopStates({}); setVisionActions([]);
    setTab("run");
    openStream(sessionId);
  }

  async function exportToCode() {
    setExporting(true);
    try {
      const res = await fetch(`${BACKEND}/export`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ prompt }),
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.error); }
      const code = await res.text();
      const fn   = res.headers.get("Content-Disposition")?.match(/filename="(.+?)"/)?.[1]||"automation.js";
      setExportCode(code); setExportFile(fn);
    } catch (e) { alert(`Export failed: ${e.message}`); }
    finally { setExporting(false); }
  }

  const latestExtracted = extractedList[extractedList.length-1];

  // ── Render ──────────────────────────────────────────────────────────────────

  return (
    <div style={{ minHeight:"100vh", background:"#060606", color:"#e8e8e8",
      fontFamily:"'DM Sans','Helvetica Neue',sans-serif", display:"flex", flexDirection:"column" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:#1e1e1e;border-radius:2px}
        @keyframes fadeIn{from{opacity:0;transform:translateY(3px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}
        @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
        @keyframes visionPulse{0%,100%{box-shadow:0 0 0 0 rgba(192,132,252,.3)}50%{box-shadow:0 0 0 6px rgba(192,132,252,0)}}
        button:focus{outline:none}textarea:focus{outline:none}input:focus{outline:none}
        textarea::placeholder{color:#2a2a2a}input::placeholder{color:#1e1e1e}
      `}</style>

      {exportCode && <CodeModal code={exportCode} filename={exportFile} onClose={() => setExportCode(null)} />}
      {showSchedule && (
        <ScheduleModal prompt={prompt} onSave={async (d) => {
          await fetch(`${BACKEND}/schedules`, {
            method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(d),
          });
          setShowSchedule(false);
        }} onClose={() => setShowSchedule(false)} />
      )}

      {/* ── Header ── */}
      <header style={{ padding:"12px 22px", display:"flex", alignItems:"center",
        justifyContent:"space-between", borderBottom:"1px solid #0d0d0d",
        background:"rgba(6,6,6,.96)", backdropFilter:"blur(12px)",
        position:"sticky", top:0, zIndex:50 }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ display:"flex", alignItems:"center", gap:9, cursor:"pointer" }} onClick={reset}>
            <div style={{ width:25, height:25, borderRadius:7,
              background:"linear-gradient(135deg,#3b82f6,#1d4ed8)",
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:12, fontWeight:700, color:"white" }}>D</div>
            <span style={{ fontWeight:600, fontSize:13, letterSpacing:"-0.02em" }}>director</span>
          </div>
          <div style={{ display:"flex", gap:2, background:"#0a0a0a",
            border:"1px solid #111", borderRadius:7, padding:2 }}>
            {[["run","▶ Run"],["schedules","⏰ Schedules"]].map(([t,l]) => (
              <button key={t} onClick={() => setTab(t)}
                style={{ padding:"4px 11px", borderRadius:5, fontSize:11, cursor:"pointer",
                  fontFamily:"inherit", border:"none",
                  background: tab===t?"#1a1a1a":"transparent",
                  color: tab===t?"#e8e8e8":"#3a3a3a" }}>{l}</button>
            ))}
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          {phase!=="home" && tab==="run" && (
            <div style={{ display:"flex", alignItems:"center", gap:6, fontSize:11,
              color:phase==="running"?"#60a5fa":phase==="done"?"#6ee7b7":"#f87171" }}>
              {phase==="running" && <div style={{ width:6, height:6, borderRadius:"50%",
                background:"#3b82f6", animation:"pulse 1.5s infinite" }} />}
              {statusText}
              {agentFrames>0 && <span style={{ color:"#222", fontSize:9 }}>({agentFrames}f)</span>}
              {newTabs>1 && <Badge color="#fbbf24" bg="#0d0c00" border="#2a2200">📄 {newTabs}</Badge>}
            </div>
          )}
          {phase==="done" && tab==="run" && (
            <>
              <button onClick={() => setShowSchedule(true)}
                style={{ background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:7,
                  padding:"5px 11px", fontSize:11, color:"#555", cursor:"pointer" }}>⏰ Schedule</button>
              <button onClick={exportToCode} disabled={exporting}
                style={{ background:"#065f46", border:"none", borderRadius:7, padding:"5px 12px",
                  fontSize:11, fontWeight:500, color:"#6ee7b7", cursor:"pointer",
                  display:"flex", alignItems:"center", gap:5, opacity:exporting?.5:1 }}>
                {exporting ? <><Spinner size={9} color="#6ee7b7"/>Exporting…</> : "↓ Export"}
              </button>
            </>
          )}
          <button onClick={reset}
            style={{ background:"transparent", border:"1px solid #111", borderRadius:7,
              padding:"5px 11px", fontSize:11, color:"#444", cursor:"pointer" }}>
            {phase==="home"?"Docs":"New task"}
          </button>
        </div>
      </header>

      {/* ── Schedules tab ── */}
      {tab==="schedules" && <SchedulesTab onRunNow={startFromSessionId} />}

      {/* ── Home ── */}
      {tab==="run" && phase==="home" && (
        <main style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center",
          justifyContent:"center", padding:"44px 22px", maxWidth:720, margin:"0 auto", width:"100%" }}>

          <div style={{ textAlign:"center", marginBottom:36, animation:"fadeIn .5s ease" }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:6, background:"#0a0f1e",
              border:"1px solid #1a2a4a", borderRadius:20, padding:"4px 11px",
              marginBottom:16, fontSize:11, color:"#60a5fa" }}>
              <span style={{ width:5, height:5, borderRadius:"50%", background:"#3b82f6",
                animation:"pulse 2s infinite", display:"inline-block" }} />
              Scripted · Agent · Vision · Scheduler · Export
            </div>
            <h1 style={{ fontSize:"clamp(26px,5vw,44px)", fontWeight:600,
              letterSpacing:"-0.04em", lineHeight:1.1, marginBottom:12, color:"#f0f0f0" }}>
              Automate your <span style={{ color:"#3b82f6" }}>internal tools</span>
            </h1>
            <p style={{ color:"#444", fontSize:14, maxWidth:400, margin:"0 auto", lineHeight:1.6 }}>
              Three execution modes. Vision fallback. Loop/pagination. Session injection. Export to Playwright.
            </p>
          </div>

          {/* Mode selector */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr",
            gap:7, marginBottom:14, width:"100%" }}>
            {MODES.map(m => (
              <button key={m.id} onClick={() => setMode(m.id)}
                style={{ padding:"11px 12px", borderRadius:10, cursor:"pointer", fontFamily:"inherit",
                  textAlign:"left", transition:"all .15s",
                  background: mode===m.id
                    ? m.id==="vision"?"#120a20":m.id==="agent"?"#110818":"#09111f"
                    : "#080808",
                  border: `1px solid ${mode===m.id
                    ? m.id==="vision"?"#6b21a8":m.id==="agent"?"#4c1d95":"#1e3a5f"
                    : "#0f0f0f"}` }}>
                <div style={{ fontSize:14, marginBottom:4 }}>{m.icon}</div>
                <div style={{ fontSize:12, fontWeight:500,
                  color: mode===m.id
                    ? m.id==="vision"?"#c084fc":m.id==="agent"?"#a78bfa":"#60a5fa"
                    : "#333" }}>{m.label}</div>
                <div style={{ fontSize:10, lineHeight:1.5, marginTop:2,
                  color: mode===m.id?"#3a3a3a":"#1e1e1e" }}>{m.desc}</div>
              </button>
            ))}
          </div>

          {/* Prompt input */}
          <div style={{ width:"100%", background:"#080808",
            border:`1px solid ${inputFocused?"#3b82f6":"#111"}`,
            borderRadius:11, padding:"13px 13px 9px", transition:"border-color .2s", marginBottom:12 }}>
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)}
              onFocus={() => setInputFocused(true)} onBlur={() => setInputFocused(false)}
              onKeyDown={e => { if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();runAutomation(prompt);}}}
              placeholder={
                mode==="vision"   ? "e.g. Go to http://localhost:3000, find the Export button and click it…" :
                mode==="agent"    ? "e.g. Log into http://localhost:3000 and approve all pending requests…" :
                "e.g. Go to http://localhost:3000 and extract all rows from the orders table…"
              }
              rows={3} style={{ width:"100%", background:"transparent", border:"none",
                resize:"none", fontSize:13, color:"#ddd", lineHeight:1.6, fontFamily:"inherit" }} />
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <span style={{ fontSize:9, color:"#111" }}>{BACKEND}</span>
              <button onClick={() => runAutomation(prompt)} disabled={!prompt.trim()}
                style={{ background: mode==="vision"?"#581c87":mode==="agent"?"#3b0764":"#1d4ed8",
                  border:"none", borderRadius:7, padding:"6px 14px", fontSize:12, fontWeight:500,
                  color:"white", cursor:"pointer", opacity:prompt.trim()?1:.35,
                  display:"flex", alignItems:"center", gap:4 }}>
                {MODES.find(m=>m.id===mode)?.icon} Run <span style={{ fontSize:10, opacity:.6 }}>↵</span>
              </button>
            </div>
          </div>

          {/* Session config */}
          <div style={{ width:"100%", marginBottom:12 }}>
            <SessionPanel session={session} onChange={setSession} />
          </div>
        </main>
      )}

      {/* ── Error ── */}
      {tab==="run" && phase==="error" && (
        <main style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", padding:40 }}>
          <div style={{ background:"#0a0505", border:"1px solid #2a0a0a", borderRadius:12,
            padding:26, maxWidth:480, width:"100%" }}>
            <div style={{ color:"#f87171", fontSize:15, marginBottom:10 }}>✗ Error</div>
            <pre style={{ color:"#fca5a5", fontSize:11, fontFamily:"JetBrains Mono,monospace",
              whiteSpace:"pre-wrap", lineHeight:1.7 }}>{errorMsg}</pre>
            <button onClick={reset} style={{ marginTop:16, background:"#3b82f6", border:"none",
              borderRadius:7, padding:"7px 14px", fontSize:12, color:"white",
              cursor:"pointer", fontWeight:500 }}>Try again</button>
          </div>
        </main>
      )}

      {/* ── Running / Done ── */}
      {tab==="run" && (phase==="running"||phase==="done") && (
        <main style={{ flex:1, display:"flex", flexDirection:"column",
          padding:"12px 20px", gap:10, maxWidth:1200, margin:"0 auto", width:"100%" }}>

          {/* Task bar */}
          <div style={{ background:"#080808", border:"1px solid #0f0f0f", borderRadius:9,
            padding:"9px 13px", display:"flex", alignItems:"center",
            gap:9, flexShrink:0 }}>
            {phase==="running" ? <Spinner size={15}/>
              : <div style={{ width:15, height:15, borderRadius:"50%", background:"#065f46",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontSize:9, color:"#6ee7b7", flexShrink:0 }}>✓</div>
            }
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:12, color:"#aaa", overflow:"hidden",
                textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{prompt}</div>
              {goal && <div style={{ fontSize:9, color:"#222", marginTop:2 }}>{goal}</div>}
            </div>
            <Badge
              color={mode==="vision"?"#c084fc":mode==="agent"?"#a78bfa":"#60a5fa"}
              bg={mode==="vision"?"#120a20":mode==="agent"?"#110818":"#09111f"}
              border={mode==="vision"?"#6b21a8":mode==="agent"?"#4c1d95":"#1e3a5f"}>
              {MODES.find(m=>m.id===mode)?.icon} {mode}
            </Badge>
            {totalSteps>0 && (
              <span style={{ fontSize:10, color:"#1e1e1e", fontFamily:"monospace" }}>
                {steps.filter(s=>s.status==="done").length}/{totalSteps}
              </span>
            )}
          </div>

          {/* Grid */}
          <div style={{ flex:1, display:"grid", gridTemplateColumns:"1fr 270px",
            gap:10, minHeight:0, height:"calc(100vh - 165px)" }}>

            {/* Browser */}
            <div style={{ background:"#060606", border:"1px solid #0d0d0d", borderRadius:10,
              overflow:"hidden", display:"flex", flexDirection:"column" }}>
              {/* Chrome */}
              <div style={{ background:"#040404", padding:"7px 11px", display:"flex",
                alignItems:"center", gap:8, borderBottom:"1px solid #0a0a0a", flexShrink:0 }}>
                <div style={{ display:"flex", gap:4 }}>
                  {["#ff5f57","#febc2e","#28c840"].map((c,i) => (
                    <div key={i} style={{ width:8, height:8, borderRadius:"50%", background:c }} />
                  ))}
                </div>
                <div style={{ flex:1, background:"#0a0a0a", borderRadius:5,
                  padding:"3px 8px", fontSize:10, fontFamily:"monospace",
                  display:"flex", alignItems:"center", gap:5, overflow:"hidden", whiteSpace:"nowrap" }}>
                  {phase==="running" && <span style={{ flexShrink:0,
                    color: mode==="vision"?"#c084fc":mode==="agent"?"#a78bfa":"#3b82f6",
                    animation:"spin 1s linear infinite", display:"inline-block" }}>◌</span>}
                  <span style={{ overflow:"hidden", textOverflow:"ellipsis",
                    color:currentUrl?"#444":"#1a1a1a" }}>{currentUrl||"about:blank"}</span>
                </div>
                {newTabs>1 && <Tag label={`${newTabs} tabs`} color="#fbbf24" bg="#0d0a00"/>}
                {mode==="vision" && phase==="running" && (
                  <div style={{ width:8, height:8, borderRadius:"50%", background:"#c084fc",
                    animation:"visionPulse 2s infinite", flexShrink:0 }} />
                )}
              </div>
              {/* Screenshot */}
              <div style={{ flex:1, overflow:"auto", background:"#030303" }}>
                {screenshot
                  ? <img src={screenshot} alt="browser"
                      style={{ width:"100%", height:"auto", display:"block", animation:"fadeIn .15s ease" }} />
                  : <div style={{ padding:16 }}>
                      {[72,48,85,40,62,33].map((w,i) => (
                        <div key={i} style={{ height:8, borderRadius:4, width:`${w}%`, marginBottom:8,
                          background:"linear-gradient(90deg,#080808 25%,#0d0d0d 50%,#080808 75%)",
                          backgroundSize:"200% 100%", animation:`shimmer 1.5s infinite ${i*.1}s` }} />
                      ))}
                      <div style={{ height:70, borderRadius:7, background:"#0a0a0a", margin:"8px 0" }}/>
                    </div>
                }
              </div>
              {/* Extracted */}
              {latestExtracted && (
                <div style={{ padding:"9px 12px", borderTop:"1px solid #0a0a0a",
                  background:"#050e16", flexShrink:0 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:6 }}>
                    <span style={{ fontSize:9, color:"#3b82f6", textTransform:"uppercase",
                      letterSpacing:".08em" }}>Extracted</span>
                    <Badge>{latestExtracted.schemaType}</Badge>
                    {extractedList.length>1 && (
                      <span style={{ fontSize:9, color:"#1a2a3a" }}>({extractedList.length} sets)</span>
                    )}
                  </div>
                  <div style={{ maxHeight:100, overflow:"auto" }}>
                    <ExtractedView data={latestExtracted.data} schemaType={latestExtracted.schemaType}/>
                  </div>
                </div>
              )}
            </div>

            {/* Log */}
            <div ref={logRef} style={{ background:"#050505", border:"1px solid #0a0a0a",
              borderRadius:10, padding:11, overflowY:"auto",
              fontFamily:"JetBrains Mono,monospace", fontSize:10 }}>
              <div style={{ color:"#161616", fontSize:8, letterSpacing:".1em",
                textTransform:"uppercase", marginBottom:10 }}>Agent Log</div>

              {/* Vision agent actions */}
              {mode==="vision" && visionActions.map((va, i) => (
                <div key={i} style={{ marginBottom:7, padding:"7px 9px", background:"#090009",
                  borderRadius:7, border:"1px solid #1a0a2a", animation:"fadeIn .3s ease" }}>
                  <div style={{ display:"flex", gap:6, alignItems:"center", marginBottom:3 }}>
                    <span>👁️</span>
                    <Tag label={`step ${va.step+1}`} color="#c084fc" bg="#0d0014"/>
                    <Tag label={va.action.type} color="#8b5cf6" bg="#0a0016"/>
                  </div>
                  <div style={{ color:"#6a3a8a", lineHeight:1.4 }}>{va.action.description}</div>
                  {va.action.type==="click" && (
                    <div style={{ color:"#3a1a5a", fontSize:9, marginTop:2 }}>
                      @ ({va.action.x}, {va.action.y})
                    </div>
                  )}
                </div>
              ))}

              {mode==="agent" && phase==="running" && steps.length===0 && (
                <div style={{ color:"#1e1e1e", display:"flex", gap:7, marginBottom:8 }}>
                  <Spinner size={11} color="#a78bfa"/>
                  <span>Agent thinking…</span>
                </div>
              )}

              {statusText && steps.length===0 && mode!=="agent" && mode!=="vision" && (
                <div style={{ color:"#222", display:"flex", gap:7, marginBottom:8 }}>
                  <span style={{ animation:"pulse 1.2s infinite" }}>⚡</span>
                  <span>{statusText}</span>
                </div>
              )}

              {steps.map((step, i) => {
                const loop = loopStates[step.index];
                return (
                  <div key={i} style={{ marginBottom:7, animation:"fadeIn .25s ease",
                    padding:"8px 9px", background:"#080808", borderRadius:7,
                    border:`1px solid ${step.status==="error"?"#1e0707":
                      step.status==="done"?"#071407":"#07070e"}` }}>
                    <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:3, flexWrap:"wrap" }}>
                      <span style={{ fontSize:11 }}>{TYPE_ICONS[step.type]||"•"}</span>
                      <span style={{ fontSize:8, textTransform:"uppercase", letterSpacing:".06em",
                        color:step.status==="error"?"#f87171":step.status==="done"?"#6ee7b7":"#60a5fa" }}>
                        {step.type}
                      </span>
                      {/* Pre-flight badge */}
                      {step.preflight==="found"   && <Tag label="✓ found"   color="#6ee7b7" bg="#051405"/>}
                      {step.preflight==="missing"  && <Tag label="⚠ no DOM" color="#fbbf24" bg="#140e00"/>}
                      {/* Vision fallback badge */}
                      {step.visionFallback && (
                        <Tag label={step.visionFound?"👁️ vision click":"👁️ vision fail"}
                          color={step.visionFound?"#c084fc":"#f87171"}
                          bg={step.visionFound?"#0d0018":"#180505"}/>
                      )}
                      {/* Retry badge */}
                      {step.retried && <Tag label="↺ retried" color="#fb923c" bg="#120700"/>}
                      {/* Validation badge */}
                      {step.validated && step.outcomeMet===true  && <Tag label="✓ validated" color="#6ee7b7" bg="#051405"/>}
                      {step.validated && step.outcomeMet===false && <Tag label="⚠ mismatch"  color="#fbbf24" bg="#140e00"/>}
                      <span style={{ marginLeft:"auto", color:"#111", fontSize:8 }}>{i+1}/{totalSteps||"?"}</span>
                    </div>
                    <div style={{ color:step.status==="error"?"#fca5a5":
                      step.status==="done"?"#2a4a2a":"#555", lineHeight:1.4 }}>
                      {step.description}
                      {step.status==="running" && !loop && <span style={{ color:"#3b82f6" }}> ···</span>}
                    </div>
                    {/* Loop progress */}
                    {loop && (
                      <div style={{ marginTop:5 }}>
                        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                          <span style={{ fontSize:9, color:"#3b82f6" }}>🔁 iteration {loop.iter}/{loop.max}</span>
                          {!loop.active && <span style={{ fontSize:8, color:"#333" }}>{loop.reason}</span>}
                        </div>
                        {loop.active && (
                          <div style={{ height:2, background:"#0f1629", borderRadius:2, marginTop:4 }}>
                            <div style={{ height:"100%", background:"#3b82f6", borderRadius:2,
                              width:`${Math.min((loop.iter/loop.max)*100, 100)}%`,
                              transition:"width .3s" }}/>
                          </div>
                        )}
                      </div>
                    )}
                    {step.warning && (
                      <div style={{ color:"#fbbf24", fontSize:9, marginTop:3 }}>⚠ {step.warning}</div>
                    )}
                    {step.status==="error" && step.error && (
                      <div style={{ color:"#f87171", fontSize:9, marginTop:3, opacity:.7 }}>{step.error}</div>
                    )}
                  </div>
                );
              })}

              {phase==="done" && (
                <div style={{ padding:"8px 9px", background:"#030a04", borderRadius:7,
                  border:"1px solid #081408", animation:"fadeIn .3s ease" }}>
                  <div style={{ color:"#6ee7b7", fontSize:11 }}>✅ Complete</div>
                  {goal && <div style={{ color:"#1a3a1a", fontSize:9, marginTop:2, lineHeight:1.4 }}>{goal}</div>}
                  {extractedList.length>1 && (
                    <div style={{ color:"#1a2a1a", fontSize:9, marginTop:3 }}>
                      {extractedList.length} data sets collected
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </main>
      )}

      <footer style={{ padding:"7px 20px", borderTop:"1px solid #080808",
        display:"flex", justifyContent:"space-between", flexShrink:0 }}>
        <span style={{ color:"#0d0d0d", fontSize:9 }}>
          scripted · agent · vision · preflight · retry · vision-fallback · validate · loop · shadow-dom · session
        </span>
        <span style={{ color:"#0d0d0d", fontSize:9 }}>Stagehand v3.4.0</span>
      </footer>
    </div>
  );
}
