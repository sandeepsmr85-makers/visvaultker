import { useState, useEffect, useRef, useCallback } from "react";

// ═══════════════════════════════════════════════════════════════════════════
// CONSTANTS & TOOL REGISTRY
// ═══════════════════════════════════════════════════════════════════════════

const MCP_META = {
  airflow:  { color: "#00C7B7", bg: "#001f1d", label: "AIRFLOW"  },
  ssms:     { color: "#E05A5A", bg: "#1a0808", label: "SQL"      },
  s3:       { color: "#FF9900", bg: "#1a0e00", label: "AWS S3"   },
  python:   { color: "#4B9EE5", bg: "#051525", label: "PYTHON"   },
  http:     { color: "#34D399", bg: "#012118", label: "HTTP"     },
  sftp:     { color: "#C084FC", bg: "#1a0a2e", label: "SFTP"     },
  browser:  { color: "#38BDF8", bg: "#001a2e", label: "BROWSER"  },
  logic:    { color: "#A855F7", bg: "#1a0533", label: "LOGIC"    },
  complete: { color: "#22C55E", bg: "#051409", label: "DONE"     },
  ai:       { color: "#F59E0B", bg: "#1a1000", label: "AI"       },
};

const TOOL_MCP_MAP = {
  trigger_dag_run:"airflow", wait_for_dag_run:"airflow", get_task_logs:"airflow",
  get_all_task_logs:"airflow", search_task_logs:"airflow", list_dags:"airflow",
  get_dag_run:"airflow", list_dag_runs:"airflow", list_task_instances:"airflow",
  get_dag_stats:"airflow", pause_dag:"airflow", unpause_dag:"airflow",
  get_variable:"airflow", set_variable:"airflow", get_xcom_value:"airflow",
  run_query:"ssms", assert_row_count:"ssms", assert_value_exists:"ssms",
  assert_query_returns_rows:"ssms", assert_no_rows:"ssms",
  run_assertion_suite:"ssms", export_to_excel:"ssms",
  export_multiple_queries_to_excel:"ssms", get_row_count:"ssms",
  get_table_sample:"ssms", list_tables:"ssms", list_columns:"ssms",
  get_table_schema:"ssms", run_stored_procedure:"ssms", run_raw_sql:"ssms",
  assert_prefix_has_files:"s3", check_file_exists:"s3", list_objects:"s3",
  search_objects:"s3", get_object_content:"s3", get_object_metadata:"s3",
  find_recent_objects:"s3", find_objects_by_extension:"s3",
  get_presigned_url:"s3", upload_text_content:"s3", copy_object:"s3",
  delete_object:"s3", download_file:"s3", compare_prefixes:"s3",
  execute_python:"python", execute_python_with_data:"python",
  analyze_dataframe:"python", filter_dataframe:"python",
  aggregate_dataframe:"python", compare_dataframes:"python",
  profile_dataframe:"python", parse_airflow_logs:"python",
  extract_log_counts:"python", search_logs_for_pattern:"python",
  run_assertions_on_data:"python", dataframe_to_excel:"python",
  calculate_statistics:"python", parse_csv_content:"python",
  // HTTP
  http_get:"http", http_post:"http", http_put:"http",
  http_patch:"http", http_delete:"http",
  http_get_json:"http", http_post_json:"http",
  http_get_with_auth:"http", http_post_with_auth:"http",
  http_poll_until:"http", http_assert_status:"http",
  // SFTP
  sftp_test_connection:"sftp", sftp_list_dir:"sftp", sftp_find_files:"sftp",
  sftp_get_file_info:"sftp", sftp_upload_file:"sftp", sftp_upload_text:"sftp",
  sftp_download_file:"sftp", sftp_read_file:"sftp", sftp_mkdir:"sftp",
  sftp_delete_file:"sftp", sftp_rename:"sftp", sftp_copy_file:"sftp",
  sftp_assert_file_exists:"sftp", sftp_assert_dir_has_files:"sftp",
  sftp_run_command:"sftp",

  browser_new_session:"browser", browser_close_session:"browser", browser_list_sessions:"browser",
  browser_navigate:"browser", browser_go_back:"browser", browser_go_forward:"browser", browser_refresh:"browser",
  browser_get_text:"browser", browser_get_page_source:"browser", browser_get_current_url:"browser",
  browser_find_elements:"browser", browser_extract_table:"browser", browser_screenshot:"browser",
  browser_click:"browser", browser_type:"browser", browser_fill_form:"browser",
  browser_select_option:"browser", browser_scroll:"browser",
  browser_wait_for_element:"browser", browser_wait_for_navigation:"browser",
  browser_execute_script:"browser",
  browser_assert_text_present:"browser", browser_assert_url:"browser",
};

// ═══════════════════════════════════════════════════════════════════════════
// ALL MCP TOOL DEFINITIONS (Claude tool_use schema)
// ═══════════════════════════════════════════════════════════════════════════

const ALL_TOOLS = [
  // ── AIRFLOW ──────────────────────────────────────────────────────────────
  { name:"trigger_dag_run", description:"Trigger an Airflow DAG run. Returns dag_run_id and initial state.",
    input_schema:{type:"object",required:["dag_id"],properties:{dag_id:{type:"string"},conf:{type:"object",default:{}},run_id:{type:"string"},note:{type:"string"}}}},
  { name:"wait_for_dag_run", description:"Poll a DAG run until it reaches success/failed/error. Returns final state and elapsed time.",
    input_schema:{type:"object",required:["dag_id","run_id"],properties:{dag_id:{type:"string"},run_id:{type:"string"},poll_interval_seconds:{type:"integer",default:10},timeout_seconds:{type:"integer",default:3600}}}},
  { name:"get_task_logs", description:"Fetch the full log text for a specific task instance. Returns raw log lines.",
    input_schema:{type:"object",required:["dag_id","run_id","task_id"],properties:{dag_id:{type:"string"},run_id:{type:"string"},task_id:{type:"string"},task_try_number:{type:"integer",default:1}}}},
  { name:"get_all_task_logs", description:"Fetch logs for every task in a DAG run. Returns dict keyed by task_id.",
    input_schema:{type:"object",required:["dag_id","run_id"],properties:{dag_id:{type:"string"},run_id:{type:"string"}}}},
  { name:"search_task_logs", description:"Search all task logs for a string/pattern. Returns matching lines with task_id and line number.",
    input_schema:{type:"object",required:["dag_id","run_id","search_term"],properties:{dag_id:{type:"string"},run_id:{type:"string"},search_term:{type:"string"},case_sensitive:{type:"boolean",default:false}}}},
  { name:"list_task_instances", description:"List all task instances in a DAG run with their states and durations.",
    input_schema:{type:"object",required:["dag_id","run_id"],properties:{dag_id:{type:"string"},run_id:{type:"string"}}}},
  { name:"list_dags", description:"List all DAGs with optional tag/pattern filter.",
    input_schema:{type:"object",properties:{limit:{type:"integer",default:100},tags:{type:"array",items:{type:"string"}},dag_id_pattern:{type:"string"},only_active:{type:"boolean",default:true}}}},
  { name:"get_dag_run", description:"Get status and details of a specific DAG run.",
    input_schema:{type:"object",required:["dag_id","run_id"],properties:{dag_id:{type:"string"},run_id:{type:"string"}}}},
  { name:"list_dag_runs", description:"List runs for a DAG with optional state filter.",
    input_schema:{type:"object",required:["dag_id"],properties:{dag_id:{type:"string"},state:{type:"string",enum:["queued","running","success","failed",""]},limit:{type:"integer",default:25}}}},
  { name:"get_dag_stats", description:"Get run statistics (count per state) for one or more DAGs.",
    input_schema:{type:"object",properties:{dag_ids:{type:"array",items:{type:"string"}}}}},
  { name:"pause_dag", description:"Pause a DAG to stop scheduling.",
    input_schema:{type:"object",required:["dag_id"],properties:{dag_id:{type:"string"}}}},
  { name:"unpause_dag", description:"Unpause/activate a DAG.",
    input_schema:{type:"object",required:["dag_id"],properties:{dag_id:{type:"string"}}}},
  { name:"get_variable", description:"Get the value of an Airflow Variable.",
    input_schema:{type:"object",required:["variable_key"],properties:{variable_key:{type:"string"}}}},
  { name:"set_variable", description:"Create or update an Airflow Variable.",
    input_schema:{type:"object",required:["variable_key","value"],properties:{variable_key:{type:"string"},value:{type:"string"}}}},
  { name:"get_xcom_value", description:"Retrieve an XCom value pushed by a task.",
    input_schema:{type:"object",required:["dag_id","run_id","task_id","xcom_key"],properties:{dag_id:{type:"string"},run_id:{type:"string"},task_id:{type:"string"},xcom_key:{type:"string",default:"return_value"}}}},

  // ── SQL SERVER ────────────────────────────────────────────────────────────
  { name:"run_query", description:"Execute a SELECT SQL query. Returns rows as JSON array with column names.",
    input_schema:{type:"object",required:["sql"],properties:{sql:{type:"string"},database:{type:"string"},max_rows:{type:"integer",default:1000}}}},
  { name:"assert_row_count", description:"Assert row count of a query meets a condition (==, !=, >, <, >=, <=). Returns PASS or FAIL with actual count.",
    input_schema:{type:"object",required:["sql_or_table","operator","expected_value"],properties:{sql_or_table:{type:"string"},operator:{type:"string",enum:["==","!=",">","<",">=","<="]},expected_value:{type:"integer"},database:{type:"string"},where_clause:{type:"string"}}}},
  { name:"assert_value_exists", description:"Assert a specific value exists in a column. Returns PASS or FAIL with occurrence count.",
    input_schema:{type:"object",required:["table_name","column_name","expected_value"],properties:{table_name:{type:"string"},column_name:{type:"string"},expected_value:{type:"string"},database:{type:"string"},where_clause:{type:"string"}}}},
  { name:"assert_query_returns_rows", description:"Assert a query returns at least one row. Returns PASS or FAIL.",
    input_schema:{type:"object",required:["sql"],properties:{sql:{type:"string"},database:{type:"string"},description:{type:"string"}}}},
  { name:"assert_no_rows", description:"Assert a query returns zero rows. Returns PASS or FAIL.",
    input_schema:{type:"object",required:["sql"],properties:{sql:{type:"string"},database:{type:"string"},description:{type:"string"}}}},
  { name:"run_assertion_suite", description:"Run multiple SQL assertions at once and return a summary report with PASS/FAIL per assertion.",
    input_schema:{type:"object",required:["assertions"],properties:{database:{type:"string"},assertions:{type:"array",items:{type:"object",required:["name","sql","check_type"],properties:{name:{type:"string"},sql:{type:"string"},check_type:{type:"string",enum:["has_rows","no_rows","row_count_eq","row_count_gt","value_eq"]},expected:{type:"string"}}}}}}},
  { name:"export_to_excel", description:"Run a SQL query and export results to a formatted Excel (.xlsx) file.",
    input_schema:{type:"object",required:["sql","filename"],properties:{sql:{type:"string"},filename:{type:"string"},database:{type:"string"},sheet_name:{type:"string",default:"Results"},title:{type:"string"}}}},
  { name:"get_row_count", description:"Get the total row count of a table (fast, with optional WHERE filter).",
    input_schema:{type:"object",required:["sql_or_table"],properties:{sql_or_table:{type:"string"},database:{type:"string"},where_clause:{type:"string"}}}},
  { name:"get_table_sample", description:"Get a sample of N rows from a table.",
    input_schema:{type:"object",required:["table_name"],properties:{table_name:{type:"string"},database:{type:"string"},sample_size:{type:"integer",default:10},where_clause:{type:"string"}}}},
  { name:"list_tables", description:"List all tables in a database/schema.",
    input_schema:{type:"object",properties:{database:{type:"string"},schema:{type:"string",default:"dbo"},name_filter:{type:"string"}}}},
  { name:"list_columns", description:"List all columns for a table with data types and nullability.",
    input_schema:{type:"object",required:["table_name"],properties:{table_name:{type:"string"},database:{type:"string"}}}},
  { name:"get_table_schema", description:"Get full schema of a table: columns, PKs, FKs, indexes.",
    input_schema:{type:"object",required:["table_name"],properties:{table_name:{type:"string"},database:{type:"string"}}}},
  { name:"run_stored_procedure", description:"Execute a SQL Server stored procedure with named parameters.",
    input_schema:{type:"object",required:["procedure_name"],properties:{procedure_name:{type:"string"},database:{type:"string"},parameters:{type:"object",default:{}}}}},
  { name:"run_raw_sql", description:"Execute any SQL (INSERT/UPDATE/DELETE/DDL). Requires confirm=true.",
    input_schema:{type:"object",required:["sql","confirm"],properties:{sql:{type:"string"},database:{type:"string"},confirm:{type:"boolean"}}}},

  // ── AWS S3 ────────────────────────────────────────────────────────────────
  { name:"assert_prefix_has_files", description:"Assert at least N files exist under an S3 prefix. Returns PASS or FAIL with actual file count.",
    input_schema:{type:"object",required:["bucket","prefix"],properties:{bucket:{type:"string"},prefix:{type:"string"},min_count:{type:"integer",default:1},extension:{type:"string"}}}},
  { name:"check_file_exists", description:"Check whether a specific S3 object exists. Returns EXISTS or NOT FOUND.",
    input_schema:{type:"object",required:["bucket","key"],properties:{bucket:{type:"string"},key:{type:"string"}}}},
  { name:"list_objects", description:"List objects in an S3 bucket under a prefix.",
    input_schema:{type:"object",required:["bucket"],properties:{bucket:{type:"string"},prefix:{type:"string",default:""},max_keys:{type:"integer",default:100},sort_by:{type:"string",enum:["key","size","last_modified"],default:"last_modified"}}}},
  { name:"search_objects", description:"Search for S3 objects matching a filename pattern.",
    input_schema:{type:"object",required:["bucket","search_term"],properties:{bucket:{type:"string"},search_term:{type:"string"},prefix:{type:"string",default:""},max_results:{type:"integer",default:50}}}},
  { name:"get_object_content", description:"Read the text content of an S3 object (text, JSON, CSV, log).",
    input_schema:{type:"object",required:["bucket","key"],properties:{bucket:{type:"string"},key:{type:"string"},max_bytes:{type:"integer",default:102400}}}},
  { name:"get_object_metadata", description:"Get metadata of an S3 object: size, content-type, last_modified, tags.",
    input_schema:{type:"object",required:["bucket","key"],properties:{bucket:{type:"string"},key:{type:"string"}}}},
  { name:"find_recent_objects", description:"Find the N most recently modified objects under an S3 prefix.",
    input_schema:{type:"object",required:["bucket"],properties:{bucket:{type:"string"},prefix:{type:"string",default:""},top_n:{type:"integer",default:10},since_hours:{type:"integer"}}}},
  { name:"find_objects_by_extension", description:"Find all S3 objects with a specific file extension.",
    input_schema:{type:"object",required:["bucket","extension"],properties:{bucket:{type:"string"},extension:{type:"string"},prefix:{type:"string",default:""},max_results:{type:"integer",default:100}}}},
  { name:"get_presigned_url", description:"Generate a pre-signed URL for temporary S3 object access.",
    input_schema:{type:"object",required:["bucket","key"],properties:{bucket:{type:"string"},key:{type:"string"},expiry_seconds:{type:"integer",default:3600}}}},
  { name:"upload_text_content", description:"Upload string/JSON/CSV content directly to S3.",
    input_schema:{type:"object",required:["bucket","key","content"],properties:{bucket:{type:"string"},key:{type:"string"},content:{type:"string"},content_type:{type:"string",default:"text/plain"}}}},
  { name:"copy_object", description:"Copy an S3 object to another location.",
    input_schema:{type:"object",required:["source_bucket","source_key","dest_bucket","dest_key"],properties:{source_bucket:{type:"string"},source_key:{type:"string"},dest_bucket:{type:"string"},dest_key:{type:"string"}}}},
  { name:"delete_object", description:"Delete a single S3 object.",
    input_schema:{type:"object",required:["bucket","key"],properties:{bucket:{type:"string"},key:{type:"string"}}}},
  { name:"download_file", description:"Download an S3 object to local storage.",
    input_schema:{type:"object",required:["bucket","key"],properties:{bucket:{type:"string"},key:{type:"string"},local_filename:{type:"string"}}}},
  { name:"compare_prefixes", description:"Compare object lists between two S3 prefixes. Finds added, removed items.",
    input_schema:{type:"object",required:["bucket_a","prefix_a","bucket_b","prefix_b"],properties:{bucket_a:{type:"string"},prefix_a:{type:"string"},bucket_b:{type:"string"},prefix_b:{type:"string"}}}},

  // ── PYTHON EXECUTOR ───────────────────────────────────────────────────────
  { name:"execute_python", description:"Execute Python code with pandas/numpy available. Use result= to capture output.",
    input_schema:{type:"object",required:["code"],properties:{code:{type:"string"},description:{type:"string"}}}},
  { name:"execute_python_with_data", description:"Execute Python code with pre-loaded JSON/CSV data as 'data' variable.",
    input_schema:{type:"object",required:["code","data"],properties:{code:{type:"string"},data:{type:"string"},data_format:{type:"string",enum:["json","csv","text","lines"],default:"json"}}}},
  { name:"analyze_dataframe", description:"Load JSON rows into pandas and run full descriptive analysis.",
    input_schema:{type:"object",required:["rows_json"],properties:{rows_json:{type:"string"}}}},
  { name:"filter_dataframe", description:"Filter rows from a JSON dataset using a pandas query expression.",
    input_schema:{type:"object",required:["rows_json","filter_expr"],properties:{rows_json:{type:"string"},filter_expr:{type:"string"},output_columns:{type:"array",items:{type:"string"}}}}},
  { name:"aggregate_dataframe", description:"Group and aggregate a JSON dataset.",
    input_schema:{type:"object",required:["rows_json","group_by","aggregations"],properties:{rows_json:{type:"string"},group_by:{type:"array",items:{type:"string"}},aggregations:{type:"object"}}}},
  { name:"compare_dataframes", description:"Compare two JSON datasets. Finds added, removed, and changed rows.",
    input_schema:{type:"object",required:["rows_a","rows_b","key_columns"],properties:{rows_a:{type:"string"},rows_b:{type:"string"},key_columns:{type:"array",items:{type:"string"}}}}},
  { name:"profile_dataframe", description:"Generate per-column data quality profile: nulls, uniques, min/max, samples.",
    input_schema:{type:"object",required:["rows_json"],properties:{rows_json:{type:"string"}}}},
  { name:"parse_airflow_logs", description:"Parse Airflow log text. Extracts log levels, timings, errors, and KV metrics.",
    input_schema:{type:"object",required:["log_text"],properties:{log_text:{type:"string"},task_id:{type:"string"}}}},
  { name:"extract_log_counts", description:"Extract a named numeric metric from Airflow log text (e.g. total_count, subscribed_count).",
    input_schema:{type:"object",required:["log_text","metric_name"],properties:{log_text:{type:"string"},metric_name:{type:"string"},return_all:{type:"boolean",default:false}}}},
  { name:"search_logs_for_pattern", description:"Search log text for lines matching a regex pattern.",
    input_schema:{type:"object",required:["log_text","pattern"],properties:{log_text:{type:"string"},pattern:{type:"string"},context_lines:{type:"integer",default:0},max_matches:{type:"integer",default:50}}}},
  { name:"run_assertions_on_data", description:"Run multiple data assertions on a JSON dataset. Returns PASS/FAIL per assertion.",
    input_schema:{type:"object",required:["rows_json","assertions"],properties:{rows_json:{type:"string"},assertions:{type:"array",items:{type:"object"}}}}},
  { name:"dataframe_to_excel", description:"Convert JSON rows to a formatted Excel file.",
    input_schema:{type:"object",required:["rows_json","filename"],properties:{rows_json:{type:"string"},filename:{type:"string"},sheet_name:{type:"string",default:"Results"},title:{type:"string"}}}},
  { name:"calculate_statistics", description:"Calculate statistics for numeric data (count, mean, median, std, min, max).",
    input_schema:{type:"object",required:["values_or_json"],properties:{values_or_json:{type:"string"},column_name:{type:"string"}}}},
  { name:"parse_csv_content", description:"Parse CSV text into a JSON rows array.",
    input_schema:{type:"object",required:["csv_text"],properties:{csv_text:{type:"string"},delimiter:{type:"string",default:","},has_header:{type:"boolean",default:true}}}},

  // ── HTTP REQUEST ─────────────────────────────────────────────────────────
  { name:"http_get", description:"Make an HTTP GET request to any URL. Returns status code, headers, and body.",
    input_schema:{type:"object",required:["url"],properties:{url:{type:"string"},headers:{type:"object",default:{}},params:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_post", description:"Make an HTTP POST request with a JSON body. Use to create resources, submit forms, or trigger webhooks.",
    input_schema:{type:"object",required:["url"],properties:{url:{type:"string"},body:{type:"object",default:{}},headers:{type:"object",default:{}},params:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_put", description:"Make an HTTP PUT request with a JSON body. Use to replace/update a full resource.",
    input_schema:{type:"object",required:["url"],properties:{url:{type:"string"},body:{type:"object",default:{}},headers:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_patch", description:"Make an HTTP PATCH request with a JSON body. Use for partial resource updates.",
    input_schema:{type:"object",required:["url"],properties:{url:{type:"string"},body:{type:"object",default:{}},headers:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_delete", description:"Make an HTTP DELETE request. Use to remove/delete a resource via REST API.",
    input_schema:{type:"object",required:["url"],properties:{url:{type:"string"},headers:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_get_json", description:"GET a URL and return only the parsed JSON body. Supports dot-notation json_path extraction.",
    input_schema:{type:"object",required:["url"],properties:{url:{type:"string"},headers:{type:"object",default:{}},params:{type:"object",default:{}},json_path:{type:"string",default:""},timeout:{type:"integer",default:30}}}},
  { name:"http_post_json", description:"POST a JSON body and return only the parsed JSON response.",
    input_schema:{type:"object",required:["url"],properties:{url:{type:"string"},body:{type:"object",default:{}},headers:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_get_with_auth", description:"GET a URL with Bearer token or Basic auth. Use for protected APIs.",
    input_schema:{type:"object",required:["url","auth_type"],properties:{url:{type:"string"},auth_type:{type:"string",enum:["bearer","basic"]},token:{type:"string"},username:{type:"string"},password:{type:"string"},params:{type:"object",default:{}},extra_headers:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_post_with_auth", description:"POST with Bearer token or Basic auth.",
    input_schema:{type:"object",required:["url","auth_type"],properties:{url:{type:"string"},auth_type:{type:"string",enum:["bearer","basic"]},token:{type:"string"},username:{type:"string"},password:{type:"string"},body:{type:"object",default:{}},extra_headers:{type:"object",default:{}},timeout:{type:"integer",default:30}}}},
  { name:"http_poll_until", description:"Repeatedly GET a URL until the response contains an expected value or timeout is reached.",
    input_schema:{type:"object",required:["url","expected_value"],properties:{url:{type:"string"},expected_value:{type:"string"},json_path:{type:"string",default:""},headers:{type:"object",default:{}},poll_interval_seconds:{type:"integer",default:10},timeout_seconds:{type:"integer",default:300},bearer_token:{type:"string",default:""}}}},
  { name:"http_assert_status", description:"GET a URL and assert it returns a specific HTTP status code. Returns PASS or FAIL.",
    input_schema:{type:"object",required:["url","expected_status"],properties:{url:{type:"string"},expected_status:{type:"integer"},headers:{type:"object",default:{}},bearer_token:{type:"string",default:""},timeout:{type:"integer",default:30}}}},

  // ── SFTP ─────────────────────────────────────────────────────────────────
  { name:"sftp_test_connection", description:"Test the SFTP connection. Returns server banner, home directory, and auth method used.",
    input_schema:{type:"object",properties:{}}},
  { name:"sftp_list_dir", description:"List files and directories in a remote directory with size, type, permissions, and last-modified.",
    input_schema:{type:"object",properties:{remote_path:{type:"string"},pattern:{type:"string",default:""},show_hidden:{type:"boolean",default:false}}}},
  { name:"sftp_find_files", description:"Recursively search a remote directory for files matching a glob pattern.",
    input_schema:{type:"object",required:["pattern"],properties:{pattern:{type:"string"},remote_path:{type:"string"},max_depth:{type:"integer",default:5},max_results:{type:"integer",default:50}}}},
  { name:"sftp_get_file_info", description:"Get metadata for a specific remote file: size, permissions, last modified.",
    input_schema:{type:"object",required:["remote_path"],properties:{remote_path:{type:"string"}}}},
  { name:"sftp_upload_file", description:"Upload a local file to the remote SFTP server.",
    input_schema:{type:"object",required:["local_path","remote_path"],properties:{local_path:{type:"string"},remote_path:{type:"string"},overwrite:{type:"boolean",default:true}}}},
  { name:"sftp_upload_text", description:"Write a text or JSON string directly to a remote file — no local file needed.",
    input_schema:{type:"object",required:["content","remote_path"],properties:{content:{type:"string"},remote_path:{type:"string"},encoding:{type:"string",default:"utf-8"}}}},
  { name:"sftp_download_file", description:"Download a remote file to the local machine.",
    input_schema:{type:"object",required:["remote_path"],properties:{remote_path:{type:"string"},local_path:{type:"string"}}}},
  { name:"sftp_read_file", description:"Read and return the text content of a remote file without saving it locally.",
    input_schema:{type:"object",required:["remote_path"],properties:{remote_path:{type:"string"},max_bytes:{type:"integer",default:102400},encoding:{type:"string",default:"utf-8"}}}},
  { name:"sftp_mkdir", description:"Create a directory (and any missing parents) on the remote server.",
    input_schema:{type:"object",required:["remote_path"],properties:{remote_path:{type:"string"},mode:{type:"integer",default:755}}}},
  { name:"sftp_delete_file", description:"Delete a file from the remote server. Requires confirm=true.",
    input_schema:{type:"object",required:["remote_path"],properties:{remote_path:{type:"string"},confirm:{type:"boolean",default:false}}}},
  { name:"sftp_rename", description:"Rename or move a file or directory on the remote server.",
    input_schema:{type:"object",required:["remote_src","remote_dst"],properties:{remote_src:{type:"string"},remote_dst:{type:"string"}}}},
  { name:"sftp_copy_file", description:"Copy a remote file to another remote location (download-then-upload).",
    input_schema:{type:"object",required:["remote_src","remote_dst"],properties:{remote_src:{type:"string"},remote_dst:{type:"string"}}}},
  { name:"sftp_assert_file_exists", description:"Assert that a specific file exists on the remote server. Returns PASS or FAIL.",
    input_schema:{type:"object",required:["remote_path"],properties:{remote_path:{type:"string"},min_size_bytes:{type:"integer",default:0}}}},
  { name:"sftp_assert_dir_has_files", description:"Assert a remote directory has at least N files matching an optional pattern. Returns PASS or FAIL.",
    input_schema:{type:"object",required:["remote_path"],properties:{remote_path:{type:"string"},min_count:{type:"integer",default:1},pattern:{type:"string",default:""}}}},
  { name:"sftp_run_command", description:"Execute a shell command on the remote server over SSH and return stdout/stderr.",
    input_schema:{type:"object",required:["command"],properties:{command:{type:"string"},timeout:{type:"integer",default:30}}}},

  // ── Browser (Playwright) ─────────────────────────────────────────────────
  { name:"browser_new_session", description:"Open a new browser session. Returns a session_id used by all other browser tools.",
    input_schema:{type:"object",properties:{session_id:{type:"string"},browser_type:{type:"string",enum:["chromium","firefox","webkit"]},headless:{type:"boolean"}}}},
  { name:"browser_close_session", description:"Close a browser session and free all resources. Always call this when done.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"}}}},
  { name:"browser_list_sessions", description:"List all active browser sessions with their current URLs and creation times.",
    input_schema:{type:"object",properties:{}}},
  { name:"browser_navigate", description:"Navigate to a URL. Waits for the page to load. Returns page title and final URL.",
    input_schema:{type:"object",required:["session_id","url"],properties:{session_id:{type:"string"},url:{type:"string"},wait_until:{type:"string"},timeout_ms:{type:"integer"}}}},
  { name:"browser_go_back", description:"Navigate back in the browser history.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"}}}},
  { name:"browser_go_forward", description:"Navigate forward in the browser history.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"}}}},
  { name:"browser_refresh", description:"Reload the current page.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"}}}},
  { name:"browser_get_text", description:"Get all visible text content from the current page. Strips scripts and styles.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"},selector:{type:"string"},max_chars:{type:"integer"}}}},
  { name:"browser_get_page_source", description:"Get the full HTML source of the current page.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"},max_chars:{type:"integer"}}}},
  { name:"browser_get_current_url", description:"Get the current URL and page title of the session.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"}}}},
  { name:"browser_find_elements", description:"Find elements matching a CSS selector. Returns tag, text, id, class, href, value.",
    input_schema:{type:"object",required:["session_id","selector"],properties:{session_id:{type:"string"},selector:{type:"string"},limit:{type:"integer"}}}},
  { name:"browser_extract_table", description:"Extract a table from the page as structured JSON with headers and rows.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"},selector:{type:"string"},table_index:{type:"integer"}}}},
  { name:"browser_screenshot", description:"Take a screenshot of the current page and save it to disk. Returns the file path.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"},label:{type:"string"},full_page:{type:"boolean"}}}},
  { name:"browser_click", description:"Click an element by CSS selector or visible text.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"},selector:{type:"string"},text:{type:"string"},timeout_ms:{type:"integer"}}}},
  { name:"browser_type", description:"Type text into an input field by CSS selector. Clears existing content first by default.",
    input_schema:{type:"object",required:["session_id","selector","text"],properties:{session_id:{type:"string"},selector:{type:"string"},text:{type:"string"},clear_first:{type:"boolean"},press_enter:{type:"boolean"}}}},
  { name:"browser_fill_form", description:"Fill multiple form fields at once with {selector, value} pairs.",
    input_schema:{type:"object",required:["session_id","fields"],properties:{session_id:{type:"string"},fields:{type:"array",items:{type:"object"}},submit_selector:{type:"string"}}}},
  { name:"browser_select_option", description:"Select an option from a <select> dropdown by value or visible label.",
    input_schema:{type:"object",required:["session_id","selector"],properties:{session_id:{type:"string"},selector:{type:"string"},value:{type:"string"},label:{type:"string"}}}},
  { name:"browser_scroll", description:"Scroll the page up, down, to top, or to bottom. Can also scroll a specific element into view.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"},direction:{type:"string",enum:["down","up","bottom","top"]},pixels:{type:"integer"},selector:{type:"string"}}}},
  { name:"browser_wait_for_element", description:"Wait until a CSS selector appears or disappears on the page.",
    input_schema:{type:"object",required:["session_id","selector"],properties:{session_id:{type:"string"},selector:{type:"string"},state:{type:"string",enum:["visible","hidden","attached","detached"]},timeout_ms:{type:"integer"}}}},
  { name:"browser_wait_for_navigation", description:"Wait for the page to finish navigating after a form submit or redirect.",
    input_schema:{type:"object",required:["session_id"],properties:{session_id:{type:"string"},wait_until:{type:"string"},timeout_ms:{type:"integer"}}}},
  { name:"browser_execute_script", description:"Execute JavaScript in the page context and return the result.",
    input_schema:{type:"object",required:["session_id","script"],properties:{session_id:{type:"string"},script:{type:"string"}}}},
  { name:"browser_assert_text_present", description:"Assert that specific text appears on the current page. Returns PASS or FAIL.",
    input_schema:{type:"object",required:["session_id","text"],properties:{session_id:{type:"string"},text:{type:"string"},case_sensitive:{type:"boolean"}}}},
  { name:"browser_assert_url", description:"Assert the current URL matches an expected value or pattern. Returns PASS or FAIL.",
    input_schema:{type:"object",required:["session_id","expected_url"],properties:{session_id:{type:"string"},expected_url:{type:"string"},match_type:{type:"string",enum:["exact","contains","startswith"]}}}},
];

// ═══════════════════════════════════════════════════════════════════════════
// REALISTIC TOOL RESPONSES (what real MCP servers would return)
// ═══════════════════════════════════════════════════════════════════════════

function executeTool(toolName, toolInput) {
  const ts = () => new Date().toISOString();
  const runId = `manual__${new Date().toISOString().replace(/[:.]/g,"-")}`;

  const responses = {
    trigger_dag_run: () => ({
      dag_id: toolInput.dag_id, dag_run_id: runId,
      state: "queued", logical_date: ts(),
      start_date: null, end_date: null,
      conf: toolInput.conf || {},
      note: `✅ DAG '${toolInput.dag_id}' triggered. run_id=${runId}`
    }),
    wait_for_dag_run: () => {
      const duration = Math.floor(Math.random()*40+15);
      return `✅ DAG run finished\n  state   : success\n  elapsed : ${duration}s\n  start   : ${new Date(Date.now()-duration*1000).toISOString()}\n  end     : ${ts()}\n  run_id  : ${toolInput.run_id||runId}`;
    },
    get_task_logs: () => {
      const taskId = toolInput.task_id;
      const count = Math.floor(Math.random()*2000+800);
      return `[${ts()}] INFO - Starting task ${taskId}\n[${ts()}] INFO - Connecting to data source\n[${ts()}] INFO - Processing records...\n[${ts()}] INFO - total_count=${count}\n[${ts()}] INFO - subscribed_count=${Math.floor(count*0.7)}\n[${ts()}] INFO - processed_records=${count}\n[${ts()}] INFO - failed_records=0\n[${ts()}] INFO - Task ${taskId} completed successfully\n[${ts()}] INFO - Duration: ${Math.floor(Math.random()*30+5)}s`;
    },
    get_all_task_logs: () => {
      const tasks = ["extract","transform","load","validate","notify"];
      return tasks.map(t => `\n${"═".repeat(50)}\nTASK: ${t}\n${"═".repeat(50)}\n[${ts()}] INFO - ${t} started\n[${ts()}] INFO - records_processed=${Math.floor(Math.random()*5000+100)}\n[${ts()}] INFO - ${t} completed OK`).join("");
    },
    search_task_logs: () => {
      const term = toolInput.search_term;
      return `Found 3 matches for '${term}':\n[line 42] task=extract: ${term} found in data processing\n[line 89] task=transform: ${term} count=1247\n[line 134] task=load: ${term} value=1247 loaded successfully`;
    },
    list_task_instances: () => JSON.stringify({task_instances:[
      {task_id:"extract",state:"success",duration:12.3,start_date:ts()},
      {task_id:"transform",state:"success",duration:8.7,start_date:ts()},
      {task_id:"load",state:"success",duration:5.1,start_date:ts()},
      {task_id:toolInput.task_id||"task_b",state:"success",duration:15.2,start_date:ts()},
    ]},null,2),
    list_dags: () => `Found 8 DAGs:\n${JSON.stringify([
      {dag_id:"DAG_Alpha",is_paused:false,schedule_interval:"@daily",owners:["data-team"]},
      {dag_id:"DAG_Beta",is_paused:false,schedule_interval:"@daily",owners:["data-team"]},
      {dag_id:"daily_etl",is_paused:false,schedule_interval:"0 2 * * *"},
      {dag_id:"weekly_report",is_paused:false,schedule_interval:"@weekly"},
    ],null,2)}`,
    get_dag_run: () => JSON.stringify({dag_id:toolInput.dag_id,dag_run_id:toolInput.run_id,state:"success",start_date:new Date(Date.now()-30000).toISOString(),end_date:ts()},null,2),
    list_dag_runs: () => JSON.stringify({dag_runs:[
      {dag_run_id:runId,state:"success",start_date:ts(),end_date:ts()},
      {dag_run_id:"scheduled__yesterday",state:"success",start_date:ts(),end_date:ts()},
    ]},null,2),
    get_dag_stats: () => `DAG Stats:\n  dag_id : ${toolInput.dag_ids?.[0]||"requested_dag"}\n  success: 12\n  failed : 1\n  running: 0\n  queued : 0`,
    pause_dag: () => `✅ DAG '${toolInput.dag_id}' paused successfully`,
    unpause_dag: () => `✅ DAG '${toolInput.dag_id}' unpaused successfully`,
    get_variable: () => JSON.stringify({key:toolInput.variable_key,value:"production",description:"Environment variable"},null,2),
    set_variable: () => `✅ Variable '${toolInput.variable_key}' set to '${toolInput.value}'`,
    get_xcom_value: () => JSON.stringify({dag_id:toolInput.dag_id,task_id:toolInput.task_id,key:toolInput.xcom_key,value:{status:"success",processed:1247,timestamp:ts()}},null,2),

    run_query: () => {
      const rows = Array.from({length:Math.min(5,Math.floor(Math.random()*20+3))},(_,i)=>({id:i+1,column_b:10,status:"active",value:Math.floor(Math.random()*100),created_at:ts()}));
      return `Query returned ${rows.length} row(s)\nColumns: [id, column_b, status, value, created_at]\n\n${JSON.stringify(rows,null,2)}`;
    },
    assert_row_count: () => {
      const actual = Math.floor(Math.random()*800+300);
      const expected = toolInput.expected_value;
      const op = toolInput.operator;
      const ops = {"==":actual===expected,"!=":actual!==expected,">":actual>expected,"<":actual<expected,">=":actual>=expected,"<=":actual<=expected};
      const pass = ops[op]??true;
      return `Assertion: row_count ${op} ${expected}\nActual   : ${actual.toLocaleString()}\nResult   : ${pass?"✅ PASS":"❌ FAIL"}`;
    },
    assert_value_exists: () => {
      const occ = Math.floor(Math.random()*50+3);
      return `Assertion: value '${toolInput.expected_value}' exists in [${toolInput.table_name}].[${toolInput.column_name}]\nFound     : ${occ} occurrence(s)\nResult    : ✅ PASS`;
    },
    assert_query_returns_rows: () => `Assertion: '${toolInput.description||"query has rows"}'\nRow count: ${Math.floor(Math.random()*100+1)}\nResult   : ✅ PASS`,
    assert_no_rows: () => `Assertion: '${toolInput.description||"no rows"}'\nRow count: 0\nResult   : ✅ PASS`,
    run_assertion_suite: () => {
      const results = (toolInput.assertions||[]).map(a=>({name:a.name,status:"PASS",check:a.check_type}));
      return `Assertion Suite: ${results.length} PASS / 0 FAIL\n\n${results.map(r=>`✅ ${r.name}: PASS`).join("\n")}`;
    },
    export_to_excel: () => `✅ Exported ${Math.floor(Math.random()*1000+100)} rows to:\n  ./exports/${toolInput.filename}\nSheet: ${toolInput.sheet_name||"Results"}\nGenerated: ${ts()}`,
    get_row_count: () => `Row count: ${Math.floor(Math.random()*50000+1000).toLocaleString()}`,
    get_table_sample: () => {
      const rows = Array.from({length:toolInput.sample_size||5},(_,i)=>({id:i+1,name:`Record_${i+1}`,value:Math.floor(Math.random()*100),status:"active"}));
      return `Sample (${rows.length} rows) from [${toolInput.table_name}]:\n${JSON.stringify(rows,null,2)}`;
    },
    list_tables: () => `12 tables in [${toolInput.database||"OperationsDB"}].[${toolInput.schema||"dbo"}]:\n${JSON.stringify(["orders","customers","products","inventory","sales","audit_log","subscribers","transactions","events","logs","config","reports"],null,2)}`,
    list_columns: () => `8 columns in [${toolInput.table_name}]:\n${JSON.stringify([{COLUMN_NAME:"id",DATA_TYPE:"int",IS_NULLABLE:"NO"},{COLUMN_NAME:"column_b",DATA_TYPE:"int",IS_NULLABLE:"YES"},{COLUMN_NAME:"status",DATA_TYPE:"varchar",IS_NULLABLE:"YES"},{COLUMN_NAME:"created_at",DATA_TYPE:"datetime",IS_NULLABLE:"NO"}],null,2)}`,
    get_table_schema: () => `Schema for [dbo].[${toolInput.table_name}]:\n\nCOLUMNS: id(int PK), column_b(int), status(varchar(50)), value(decimal), created_at(datetime)\nINDEXES: PK_id(clustered), IX_status(nonclustered), IX_created(nonclustered)`,
    run_stored_procedure: () => `SP '${toolInput.procedure_name}' executed\nRows affected: ${Math.floor(Math.random()*500+10)}\nResult sets: 1`,
    run_raw_sql: () => `✅ Executed. Rows affected: ${Math.floor(Math.random()*100)}`,

    assert_prefix_has_files: () => {
      const found = Math.floor(Math.random()*300+(toolInput.min_count||1000)-50);
      const pass = found >= (toolInput.min_count||1);
      return `Assertion: s3://${toolInput.bucket}/${toolInput.prefix} has >= ${toolInput.min_count} file(s)\nFound: ${found.toLocaleString()} file(s)\nMin  : ${(toolInput.min_count||1).toLocaleString()}\nResult: ${pass?"✅ PASS":"❌ FAIL"}`;
    },
    check_file_exists: () => `✅ EXISTS: s3://${toolInput.bucket}/${toolInput.key}\nSize: ${Math.floor(Math.random()*10000+100)} KB\nLast modified: ${ts()}`,
    list_objects: () => {
      const objs = Array.from({length:Math.min(10,Math.floor(Math.random()*50+5))},(_,i)=>({key:`${toolInput.prefix||""}file_${i+1}.csv`,size:`${Math.floor(Math.random()*5000+100)} KB`,last_modified:ts()}));
      return `${objs.length} object(s) in s3://${toolInput.bucket}/${toolInput.prefix||""}\n\n${JSON.stringify(objs,null,2)}`;
    },
    search_objects: () => {
      const matches = Array.from({length:Math.floor(Math.random()*10+2)},(_,i)=>({key:`${toolInput.prefix||""}${toolInput.search_term}_${i+1}.csv`,size:"2.3 MB",last_modified:ts()}));
      return `Found ${matches.length} match(es) for '${toolInput.search_term}':\n${JSON.stringify(matches,null,2)}`;
    },
    get_object_content: () => `s3://${toolInput.bucket}/${toolInput.key}\nSize: 48.2 KB | Type: text/csv\n${"─".repeat(50)}\nid,name,value,status,created_at\n1,Record_A,1247,active,${ts()}\n2,Record_B,982,active,${ts()}\n3,Record_C,1105,inactive,${ts()}\n... (1201 more rows)`,
    get_object_metadata: () => JSON.stringify({key:toolInput.key,bucket:toolInput.bucket,size:"48.2 KB",size_bytes:49356,content_type:"text/csv",last_modified:ts(),etag:"a1b2c3d4",tags:{environment:"production",owner:"data-team"}},null,2),
    find_recent_objects: () => {
      const objs = Array.from({length:toolInput.top_n||5},(_,i)=>({key:`${toolInput.prefix||""}recent_file_${i+1}.parquet`,last_modified:new Date(Date.now()-i*3600000).toISOString(),size:`${Math.floor(Math.random()*500+50)} MB`}));
      return `Top ${objs.length} most recent:\n${JSON.stringify(objs,null,2)}`;
    },
    find_objects_by_extension: () => {
      const ext = toolInput.extension?.replace(/^\./,"");
      const objs = Array.from({length:Math.floor(Math.random()*20+5)},(_,i)=>({key:`${toolInput.prefix||""}data_${i+1}.${ext}`,size:`${Math.floor(Math.random()*100+1)} MB`,last_modified:ts()}));
      return `Found ${objs.length} .${ext} files:\n${JSON.stringify(objs.slice(0,5),null,2)}\n... and ${Math.max(0,objs.length-5)} more`;
    },
    get_presigned_url: () => `Pre-signed URL (expires in ${toolInput.expiry_seconds||3600}s):\nhttps://s3.amazonaws.com/${toolInput.bucket}/${toolInput.key}?X-Amz-Expires=${toolInput.expiry_seconds||3600}&X-Amz-Signature=abc123...`,
    upload_text_content: () => `✅ Uploaded ${(toolInput.content||"").length} chars to s3://${toolInput.bucket}/${toolInput.key}`,
    copy_object: () => `✅ Copied:\n  FROM: s3://${toolInput.source_bucket}/${toolInput.source_key}\n  TO  : s3://${toolInput.dest_bucket}/${toolInput.dest_key}`,
    delete_object: () => `✅ Deleted: s3://${toolInput.bucket}/${toolInput.key}`,
    download_file: () => `✅ Downloaded to ./downloads/${(toolInput.key||"").split("/").pop()} (${Math.floor(Math.random()*50+1)} MB)`,
    compare_prefixes: () => `Comparison:\n  A: s3://${toolInput.bucket_a}/${toolInput.prefix_a} (${Math.floor(Math.random()*200+50)} objects)\n  B: s3://${toolInput.bucket_b}/${toolInput.prefix_b} (${Math.floor(Math.random()*200+50)} objects)\n\nOnly in A: []\nOnly in B: []\nIn both  : all files matched ✅`,

    execute_python: () => `✅ Executed in 0.34s\n\nOutput:\n${toolInput.description||"Analysis complete"}\nRows: 1247\nMean: 42.3\nMax: 99\nMin: 1\n\nResult: DataFrame(1247 rows × 8 columns)`,
    execute_python_with_data: () => `✅ Executed in 0.41s\n\nOutput:\nLoaded ${Math.floor(Math.random()*1000+100)} rows\nAnalysis complete\nTotal: ${Math.floor(Math.random()*50000+1000).toLocaleString()}\nAverage: ${(Math.random()*100+10).toFixed(2)}`,
    analyze_dataframe: () => `DataFrame Analysis: ${Math.floor(Math.random()*1000+100)} rows × 8 columns\n\nData Types: id(int64), name(object), value(float64), status(object)\nNull Counts: all 0\nDuplicate Rows: 0\n\nNumeric Statistics:\n  value: mean=42.3, std=18.7, min=1, max=99, median=41.0`,
    filter_dataframe: () => `Filtered ${Math.floor(Math.random()*500+100)} → ${Math.floor(Math.random()*50+10)} rows\n\n${JSON.stringify([{id:1,value:87,status:"active"},{id:2,value:92,status:"active"}],null,2)}`,
    aggregate_dataframe: () => `Aggregation (${Math.floor(Math.random()*10+3)} groups):\n${JSON.stringify([{status:"active",count:847,total_value:35821},{status:"inactive",count:400,total_value:16203}],null,2)}`,
    compare_dataframes: () => `Comparison:\n  Rows in A: 1247\n  Rows in B: 1251\n  Only in A: 0\n  Only in B: 4 (new records)\n  Changed  : 2 (value updated)`,
    profile_dataframe: () => `Data Profile (1247 rows, 8 cols):\n${JSON.stringify([{column:"id",dtype:"int64",null_count:0,unique_count:1247},{column:"column_b",dtype:"int64",null_count:0,unique_count:87,min:1,max:100,mean:42.3},{column:"status",dtype:"object",null_count:5,unique_count:3}],null,2)}`,
    parse_airflow_logs: () => `Airflow Log Analysis — Task: ${toolInput.task_id||"task"}\nTotal lines  : 142\nTime range   : ${ts()} → ${ts()}\nLog levels   : {"INFO":138,"WARNING":3,"ERROR":0}\nKV metrics   : {"total_count":1247,"duration":28.3,"records_loaded":1247}\n\nErrors (0):\n(none)\n\nWarnings (3):\n[WARN] Processing took longer than expected`,
    extract_log_counts: () => `'${toolInput.metric_name}' = 1247 (first occurrence)\nAll occurrences: [1247]`,
    search_logs_for_pattern: () => `Found 3 match(es) for pattern '${toolInput.pattern}':\n${JSON.stringify([{line_no:42,match:`[INFO] ${toolInput.pattern} value=1247`},{line_no:89,match:`[INFO] Processing: ${toolInput.pattern} complete`}],null,2)}`,
    run_assertions_on_data: () => `Data Assertions: 3 PASS / 0 FAIL / 3 total\n\n✅ row_count_gt: PASS (count=1247, expected>1000)\n✅ no_nulls: PASS (null_count=0)\n✅ column_value_eq: PASS (status contains 'active')`,
    dataframe_to_excel: () => `✅ Saved ${Math.floor(Math.random()*1000+100)} rows to ./py_outputs/${toolInput.filename}`,
    calculate_statistics: () => `Statistics:\n${JSON.stringify({count:1247,mean:42.3,median:41.0,std:18.7,min:1,max:99,"25th_pct":28.0,"75th_pct":57.0,sum:52726.1},null,2)}`,
    parse_csv_content: () => `✅ Parsed CSV: ${Math.floor(Math.random()*500+100)} rows × 6 columns\nColumns: [id, name, value, status, created_at, updated_at]\n\n${JSON.stringify([{id:1,name:"Row A",value:42,status:"active"},{id:2,name:"Row B",value:87,status:"inactive"}],null,2)}`,

    // ── HTTP ──────────────────────────────────────────────────────────────
    http_get: () => `Status  : 200 OK\nElapsed : ${(Math.random()*0.4+0.05).toFixed(2)}s\nURL     : ${toolInput.url}\n${"─".repeat(50)}\n${JSON.stringify({success:true,data:{id:1,status:"active",timestamp:new Date().toISOString()}},null,2)}`,
    http_post: () => `Status  : 201 Created\nElapsed : ${(Math.random()*0.4+0.05).toFixed(2)}s\nURL     : ${toolInput.url}\n${"─".repeat(50)}\n${JSON.stringify({id:Math.floor(Math.random()*10000+1),status:"created",message:"Resource created successfully"},null,2)}`,
    http_put: () => `Status  : 200 OK\nElapsed : ${(Math.random()*0.3+0.05).toFixed(2)}s\nURL     : ${toolInput.url}\n${"─".repeat(50)}\n${JSON.stringify({status:"updated",message:"Resource replaced successfully"},null,2)}`,
    http_patch: () => `Status  : 200 OK\nElapsed : ${(Math.random()*0.3+0.05).toFixed(2)}s\nURL     : ${toolInput.url}\n${"─".repeat(50)}\n${JSON.stringify({status:"updated",message:"Resource patched successfully"},null,2)}`,
    http_delete: () => `Status  : 204 No Content\nElapsed : ${(Math.random()*0.2+0.05).toFixed(2)}s\nURL     : ${toolInput.url}\n${"─".repeat(50)}\n(No response body)`,
    http_get_json: () => {
      const data = {id:1,name:"Example Resource",status:"active",value:Math.floor(Math.random()*1000),created_at:new Date().toISOString()};
      const path = toolInput.json_path;
      if(path) return `json_path '${path}' → ${JSON.stringify(data[path]??data,null,2)}`;
      return JSON.stringify(data,null,2);
    },
    http_post_json: () => JSON.stringify({id:Math.floor(Math.random()*10000+1),status:"created",message:"Success",timestamp:new Date().toISOString()},null,2),
    http_get_with_auth: () => `Status  : 200 OK\nElapsed : ${(Math.random()*0.4+0.1).toFixed(2)}s\nURL     : ${toolInput.url}\nAuth    : ${toolInput.auth_type}\n${"─".repeat(50)}\n${JSON.stringify({authenticated:true,user:{id:42,role:"admin"},data:{records:Math.floor(Math.random()*500+10)}},null,2)}`,
    http_post_with_auth: () => `Status  : 201 Created\nElapsed : ${(Math.random()*0.4+0.1).toFixed(2)}s\nURL     : ${toolInput.url}\nAuth    : ${toolInput.auth_type}\n${"─".repeat(50)}\n${JSON.stringify({id:Math.floor(Math.random()*10000+1),status:"created",authenticated:true},null,2)}`,
    http_poll_until: () => {
      const attempts = Math.floor(Math.random()*4+2);
      return `✅ PASS — found '${toolInput.expected_value}' after ${attempts} attempt(s)\nFinal value: {"status":"${toolInput.expected_value}","updated_at":"${new Date().toISOString()}"}\nStatus: 200`;
    },
    http_assert_status: () => {
      const expected = toolInput.expected_status||200;
      return `Assertion: GET ${toolInput.url} returns ${expected}\nActual   : ${expected} OK\nElapsed  : ${(Math.random()*0.3+0.05).toFixed(2)}s\nResult   : ✅ PASS`;
    },

    // ── SFTP ──────────────────────────────────────────────────────────────
    sftp_test_connection: () => `✅ Connection successful\nHost        : sftp-server.example.com:22\nUsername    : ${toolInput.username||"sftpuser"}\nAuth method : password\nServer      : SSH-2.0-OpenSSH_8.9\nRemote home : /home/sftpuser`,
    sftp_list_dir: () => {
      const path = toolInput.remote_path||"/home/sftpuser";
      const files = Array.from({length:Math.floor(Math.random()*8+3)},(_,i)=>({name:`file_${i+1}.csv`,type:"file",size:`${Math.floor(Math.random()*5000+100)} KB`,size_bytes:Math.floor(Math.random()*5000000+100000),last_modified:new Date(Date.now()-i*86400000).toISOString(),permissions:"0o644"}));
      return `${files.length} item(s) in ${path}:\n\n${JSON.stringify(files,null,2)}`;
    },
    sftp_find_files: () => {
      const pattern = toolInput.pattern||"*.csv";
      const matches = Array.from({length:Math.floor(Math.random()*6+2)},(_,i)=>({name:`/data/reports/report_${i+1}.csv`,type:"file",size:`${Math.floor(Math.random()*2000+50)} KB`,last_modified:new Date(Date.now()-i*3600000).toISOString()}));
      return `Found ${matches.length} file(s) matching '${pattern}':\n\n${JSON.stringify(matches,null,2)}`;
    },
    sftp_get_file_info: () => JSON.stringify({name:toolInput.remote_path,type:"file",size:`${Math.floor(Math.random()*5000+100)} KB`,size_bytes:Math.floor(Math.random()*5000000),last_modified:new Date().toISOString(),permissions:"0o644"},null,2),
    sftp_upload_file: () => {
      const size = Math.floor(Math.random()*5000+100);
      const elapsed = (Math.random()*2+0.3).toFixed(2);
      return `✅ Uploaded ${toolInput.local_path} → sftp-server:${toolInput.remote_path}\nSize    : ${size} KB\nElapsed : ${elapsed}s\nSpeed   : ${Math.floor(size/elapsed)} KB/s`;
    },
    sftp_upload_text: () => `✅ Written ${(toolInput.content||"").length.toLocaleString()} bytes to sftp-server:${toolInput.remote_path}`,
    sftp_download_file: () => {
      const size = Math.floor(Math.random()*5000+100);
      const elapsed = (Math.random()*2+0.3).toFixed(2);
      const filename = (toolInput.remote_path||"file.csv").split("/").pop();
      return `✅ Downloaded sftp-server:${toolInput.remote_path} → ./sftp_downloads/${filename}\nSize    : ${size} KB\nElapsed : ${elapsed}s\nSpeed   : ${Math.floor(size/elapsed)} KB/s`;
    },
    sftp_read_file: () => `File    : sftp-server:${toolInput.remote_path}\nSize    : 48.2 KB\n${"─".repeat(50)}\nid,name,value,status,created_at\n1,Record_A,1247,active,${new Date().toISOString()}\n2,Record_B,982,active,${new Date().toISOString()}\n3,Record_C,1105,inactive,${new Date().toISOString()}\n... (1201 more rows)`,
    sftp_mkdir: () => `✅ Directory created: sftp-server:${toolInput.remote_path}`,
    sftp_delete_file: () => toolInput.confirm ? `✅ Deleted: sftp-server:${toolInput.remote_path}` : `⚠️  Deletion requires confirm=true`,
    sftp_rename: () => `✅ Renamed:\n  FROM: sftp-server:${toolInput.remote_src}\n  TO  : sftp-server:${toolInput.remote_dst}`,
    sftp_copy_file: () => `✅ Copied:\n  FROM: sftp-server:${toolInput.remote_src}\n  TO  : sftp-server:${toolInput.remote_dst}\n  Size: ${Math.floor(Math.random()*5000+100)} KB`,
    sftp_assert_file_exists: () => `Assertion: ${toolInput.remote_path} exists\nSize     : ${Math.floor(Math.random()*5000+100)} KB\nResult   : ✅ PASS`,
    sftp_assert_dir_has_files: () => {
      const found = Math.floor(Math.random()*20+(toolInput.min_count||1));
      return `Assertion: ${toolInput.remote_path} has >= ${toolInput.min_count||1} file(s)\nFound    : ${found} file(s)\nResult   : ✅ PASS`;
    },
    sftp_run_command: () => `✅ Command: ${toolInput.command}\nExit code : 0\nElapsed   : ${(Math.random()*0.5+0.1).toFixed(2)}s\n${"─".repeat(50)}\nSTDOUT:\n${toolInput.command?.startsWith("ls") ? "file1.csv  file2.csv  file3.csv  report.xlsx" : toolInput.command?.startsWith("df") ? "Filesystem  Size  Used  Avail  Use%\n/dev/sda1   100G   42G    58G   42%" : "Command executed successfully."}`,

    // ── Browser (Playwright) ───────────────────────────────────────────────
    browser_new_session: () => {
      const sid = toolInput.session_id || "sess_" + Math.random().toString(36).slice(2,6);
      const btype = toolInput.browser_type || "chromium";
      return `✅ Browser session opened\nSession ID  : ${sid}\nBrowser     : ${btype}\nHeadless    : ${toolInput.headless !== false}\nViewport    : 1280×800\n\nUse session_id='${sid}' in all subsequent browser tools.`;
    },
    browser_close_session: () => `✅ Session '${toolInput.session_id}' closed. Browser and all resources released.`,
    browser_list_sessions: () => `Active browser sessions:\n  • sess_a1b2 | chromium | created ${new Date().toISOString()} | url=https://example.com/dashboard`,
    browser_navigate: () => {
      const url = toolInput.url || "https://example.com";
      const title = url.includes("github") ? "GitHub" : url.includes("google") ? "Google" : url.includes("login") ? "Login — App" : "Page Title";
      return `✅ Navigated\nURL       : ${url}\nTitle     : ${title}\nStatus    : 200\nElapsed   : ${(Math.random()*0.8+0.2).toFixed(2)}s`;
    },
    browser_go_back: () => `✅ Navigated back → https://example.com/previous-page`,
    browser_go_forward: () => `✅ Navigated forward → https://example.com/next-page`,
    browser_refresh: () => `✅ Page refreshed | https://example.com/dashboard | "Dashboard — App"`,
    browser_get_text: () => {
      const sel = toolInput.selector || "body";
      return `Page text (https://example.com/dashboard):\n${"─".repeat(50)}\nDashboard\nWelcome back, Admin\n\nTotal Records: 14,823\nLast Updated: ${new Date().toISOString()}\n\nRecent Activity\n───────────────\nETL Job completed at 03:42 UTC — 1,247 rows processed\nS3 sync finished — 83 files uploaded\nAlert: pipeline_daily finished with status SUCCESS`;
    },
    browser_get_page_source: () => `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <title>Dashboard — App</title>\n</head>\n<body>\n  <header><h1>Dashboard</h1></header>\n  <main>\n    <div class="metric">Total Records: 14,823</div>\n    <div class="metric">Last Updated: ${new Date().toISOString()}</div>\n  </main>\n</body>\n</html>`,
    browser_get_current_url: () => `URL   : https://example.com/dashboard\nTitle : Dashboard — App`,
    browser_find_elements: () => {
      const sel = toolInput.selector || "button";
      return `Found 4 element(s) for '${sel}' (showing 4):\n  [1] tag=button  text="Submit Report"  id=submit-btn  class=btn btn-primary\n  [2] tag=button  text="Export CSV"  id=export-btn  class=btn btn-secondary\n  [3] tag=button  text="Refresh"  class=btn btn-outline\n  [4] tag=button  text="Settings"  class=btn btn-icon`;
    },
    browser_extract_table: () => JSON.stringify({
      table_index: toolInput.table_index || 0,
      headers: ["ID", "Name", "Status", "Records", "Last Run"],
      row_count: 5,
      rows: [
        ["1", "ETL_daily", "SUCCESS", "14823", new Date().toISOString()],
        ["2", "S3_sync", "SUCCESS", "83", new Date().toISOString()],
        ["3", "report_gen", "RUNNING", "—", new Date().toISOString()],
        ["4", "cleanup_job", "SUCCESS", "412", new Date().toISOString()],
        ["5", "audit_check", "FAILED", "0", new Date().toISOString()],
      ]
    }, null, 2),
    browser_screenshot: () => {
      const label = toolInput.label || toolInput.session_id || "screenshot";
      const ts = new Date().toISOString().replace(/[:.]/g,"-").slice(0,19);
      return `📸 Screenshot saved\nPath       : ./browser_shots/${ts}_${label}.png\nURL        : https://example.com/dashboard\nFull page  : ${toolInput.full_page || false}\nSize       : ${Math.floor(Math.random()*300+80)} KB`;
    },
    browser_click: () => {
      const target = toolInput.selector || `"${toolInput.text}"` || "element";
      return `✅ Clicked '${target}'`;
    },
    browser_type: () => `✅ Typed into '${toolInput.selector}': "${(toolInput.text||"").slice(0,60)}"`,
    browser_fill_form: () => {
      const fields = toolInput.fields || [];
      const lines = fields.map(f => `  ✓ ${f.selector} = "${(f.value||"").slice(0,40)}"`).join("\n");
      const submit = toolInput.submit_selector ? `\n  ✓ Submitted via '${toolInput.submit_selector}'` : "";
      return `✅ Form filled (${fields.length} field(s)):\n${lines}${submit}`;
    },
    browser_select_option: () => `✅ Selected ${toolInput.value ? `value='${toolInput.value}'` : `label='${toolInput.label}'`} in '${toolInput.selector}'`,
    browser_scroll: () => {
      const dir = toolInput.direction || "down";
      const px = toolInput.pixels || 500;
      return `✅ Scrolled ${dir}${dir === "up" || dir === "down" ? ` by ${px}px` : ""}`;
    },
    browser_wait_for_element: () => {
      const state = toolInput.state || "visible";
      const waited = (Math.random()*0.8+0.1).toFixed(2);
      return `✅ Element '${toolInput.selector}' is now ${state} (waited ${waited}s)`;
    },
    browser_wait_for_navigation: () => `✅ Navigation complete | https://example.com/dashboard`,
    browser_execute_script: () => {
      const script = toolInput.script || "";
      if (script.includes("document.title")) return `Script result:\n"Dashboard — App"`;
      if (script.includes("scrollHeight")) return `Script result:\n4823`;
      if (script.includes("querySelectorAll")) return `Script result:\n12`;
      return `Script result:\n${JSON.stringify({success: true, timestamp: new Date().toISOString()}, null, 2)}`;
    },
    browser_assert_text_present: () => {
      const text = toolInput.text || "";
      return `✅ PASS — Text found on https://example.com/dashboard\nSearch    : "${text}"\nContext   : "...${text} — confirmed present on page..."`;
    },
    browser_assert_url: () => {
      const expected = toolInput.expected_url || "";
      const match = toolInput.match_type || "contains";
      return `✅ PASS — URL assertion\nMatch type : ${match}\nExpected   : ${expected}\nActual     : https://example.com/dashboard`;
    },
  };

  const fn = responses[toolName];
  if (!fn) return `Tool '${toolName}' executed successfully.`;
  try { return typeof fn()==="object" ? JSON.stringify(fn(),null,2) : String(fn()); }
  catch(e) { return `Error executing ${toolName}: ${e.message}`; }
}

// ═══════════════════════════════════════════════════════════════════════════
// CLAUDE API
// ═══════════════════════════════════════════════════════════════════════════

const WORKFLOW_AGENT_SYSTEM = `You are an intelligent automation workflow engine. Your job is to:

1. PARSE natural language instructions into structured workflows
2. EXECUTE workflows step by step using the provided tools
3. MAKE DECISIONS by reading actual tool outputs — extract metrics, evaluate conditions, determine branches
4. REASON about what each result means and what to do next
5. ADAPT the plan if something unexpected happens

When executing:
- Always call the right tool for each step
- After getting tool results, ANALYZE them carefully before deciding next step
- For log analysis: actually read the log text and extract the specific metric mentioned
- For conditions: evaluate them based on REAL values returned by previous tools
- For assertions: explain what PASS/FAIL means in context
- Track key values across steps (store them as context)
- Be explicit about your reasoning at each decision point

You have access to 60+ tools across Airflow, SQL Server, AWS S3, and Python execution.
Always explain what you're about to do, then call the tool, then explain what you found.`;

// ─── API config helpers ───────────────────────────────────────────────────────
// apiCfg = { apiKey: string, apiUrl: string }
// If apiUrl is the Anthropic origin we add the direct-browser-access header so
// the call works from the browser in dev mode.
// If apiUrl points to the local proxy we omit the header (the proxy holds the key).

function buildHeaders(apiCfg) {
  const headers = {
    "Content-Type": "application/json",
    "anthropic-version": "2023-06-01",
  };
  const isDirectAnthropic = false; // Always use proxy — Gen AI Gateway OAuth is server-side
  if (isDirectAnthropic) {
    // Fix 5: only add the dangerous header when calling Anthropic directly from browser
    headers["anthropic-dangerous-direct-browser-access"] = "true";
    if (apiCfg.apiKey) headers["x-api-key"] = apiCfg.apiKey;
  }
  // When using the proxy, the server holds ANTHROPIC_API_KEY — no key in browser.
  return headers;
}

async function callClaude(messages, tools = ALL_TOOLS, apiCfg) {
  const res = await fetch(`${apiCfg.apiUrl}`, {
    method: "POST",
    headers: buildHeaders(apiCfg),
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4000,
      system: WORKFLOW_AGENT_SYSTEM,
      tools,
      messages,
    }),
  });
  if (!res.ok) { const e = await res.text(); throw new Error(`API ${res.status}: ${e}`); }
  return res.json();
}

async function parseWorkflowAI(prompt, apiCfg) {
  const res = await fetch(`${apiCfg.apiUrl}`, {
    method: "POST",
    headers: buildHeaders(apiCfg),
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 3000,
      system: `Convert automation instructions to a JSON workflow. Return ONLY valid JSON, no markdown.

Schema:
{
  "workflow_name": "short name",
  "description": "one line",
  "steps": [{
    "id": "s1",
    "type": "trigger_dag|wait_dag|get_logs|all_logs|search_logs|run_query|assert_value|assert_count|export_excel|s3_assert|s3_search|s3_read|s3_upload|extract_metric|run_python|analyze_data|condition|end",
    "label": "human label",
    "description": "what this does",
    "mcp": "airflow|ssms|s3|python|logic|complete",
    "tool": "tool_name",
    "params": {},
    "next": "s2",
    "next_true": null,
    "next_false": null,
    "condition": {"expression":"x > 1000","left":"x","op":">","right":"1000"}
  }]
}

Rules: condition steps use next_true/next_false. Linear steps use next. Always end with type=end. Extract ALL entities (DAG names, tables, buckets, paths, thresholds). Step IDs: s1, s2, s3...`,
      messages: [{ role: "user", content: `Parse into workflow JSON:\n\n${prompt}` }],
    }),
  });
  if (!res.ok) { const e = await res.text(); throw new Error(`API ${res.status}: ${e}`); }
  const data = await res.json();
  const text = data.content?.map(b => b.text || "").join("") || "";
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("No JSON in response");
  return JSON.parse(match[0]);
}

// ═══════════════════════════════════════════════════════════════════════════
// AGENTIC EXECUTION ENGINE
// ═══════════════════════════════════════════════════════════════════════════

// Fix 4: Corrected stop_reason handling.
//
// Old bug: after processing tool calls the loop checked
//   if (stop_reason === "end_turn" || stop_reason === "stop_sequence") break;
// which would exit BEFORE feeding tool results back to Claude on turns where
// stop_reason happened to be "end_turn" alongside tool_use blocks.
//
// Correct logic:
//  - stop_reason === "tool_use"  → tool calls present, process them and loop
//  - stop_reason === "end_turn"  → no tool calls, Claude is done → break
//  - anything else (max_tokens, stop_sequence, error) → break with warning
//
// The loop now only breaks at ONE place: when there are no tool calls,
// regardless of the stop_reason variant.

async function* runAgentLoop(userPrompt, onEvent, apiCfg) {
  const messages = [{ role: "user", content: userPrompt }];
  const MAX_TURNS = 30;
  let turns = 0;

  while (turns < MAX_TURNS) {
    turns++;
    onEvent({ type: "thinking", text: `Agent turn ${turns}...` });

    const response = await callClaude(messages, ALL_TOOLS, apiCfg);
    const { content, stop_reason } = response;

    const textBlocks = content.filter(b => b.type === "text");
    const toolBlocks = content.filter(b => b.type === "tool_use");

    // Emit AI reasoning text
    for (const tb of textBlocks) {
      if (tb.text?.trim()) {
        onEvent({ type: "ai_text", text: tb.text });
        yield { type: "ai_text", text: tb.text };
      }
    }

    // ── Fix 4: single unified exit point ─────────────────────────────────
    // Only break when there are no tool calls (regardless of stop_reason).
    // Previously the loop also broke after processing tool calls when
    // stop_reason was "end_turn", preventing results from being fed back.
    if (toolBlocks.length === 0) {
      if (stop_reason === "max_tokens") {
        onEvent({ type: "ai_text", text: "⚠️ Reached max tokens — workflow may be incomplete." });
        yield { type: "ai_text", text: "⚠️ Reached max tokens — workflow may be incomplete." };
      }
      onEvent({ type: "done" });
      yield { type: "done" };
      break;
    }

    // ── Process tool calls and feed results back ───────────────────────────
    const toolResults = [];
    for (const tool of toolBlocks) {
      onEvent({ type: "tool_start", tool: tool.name, input: tool.input, id: tool.id });
      yield { type: "tool_start", tool: tool.name, input: tool.input, id: tool.id };

      const result = executeTool(tool.name, tool.input || {});

      onEvent({ type: "tool_result", tool: tool.name, result, id: tool.id });
      yield { type: "tool_result", tool: tool.name, result, id: tool.id };

      toolResults.push({
        type: "tool_result",
        tool_use_id: tool.id,
        content: result,
      });
    }

    // Extend conversation with this turn's assistant content + tool results.
    // Loop continues — Claude will analyse the results and decide next steps.
    messages.push({ role: "assistant", content });
    messages.push({ role: "user", content: toolResults });
  }

  if (turns >= MAX_TURNS) {
    onEvent({ type: "ai_text", text: `⚠️ Reached turn limit (${MAX_TURNS}). Workflow stopped.` });
    yield { type: "ai_text", text: `⚠️ Reached turn limit (${MAX_TURNS}). Workflow stopped.` };
    onEvent({ type: "done" });
    yield { type: "done" };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// UI COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════

const EXAMPLES = [
  "Trigger DAG Alpha, wait for it to complete, then in task_b fetch the total count. If total count > 1000, run SQL on table_z and assert column_b = 10. If assertion passes, trigger DAG Beta, wait for it, then assert S3 bucket-2 at path Gama has 1000 files.",
  "Check S3 bucket data-lake at path raw/sales/ has at least 5 CSV files. Read the latest one and run Python to calculate average revenue. Then run SQL SELECT SUM(revenue) FROM sales and assert sum > 50000. Export results to Excel as daily_report.xlsx.",
  "List all DAGs. Fetch all task logs from DAG daily_etl latest run and search for ERROR messages. If any errors found, run SQL on audit_log table and assert no rows where resolved=0. Then trigger DAG alert_pipeline.",
  "Trigger DAG_Subscribers, wait for completion, get logs from task load_subscribers and extract subscribed_count. If subscribed_count >= 2000 trigger DAG_Notify and wait. Then run SQL: SELECT COUNT(*) FROM dbo.Subscribers WHERE status='active' and assert count > 1500. Export to Excel.",
];

function ToolCallCard({ event }) {
  const [expanded, setExpanded] = useState(false);
  const mcp = TOOL_MCP_MAP[event.tool] || "ai";
  const m = MCP_META[mcp] || MCP_META.ai;
  return (
    <div style={{ margin:"4px 0", borderRadius:6, overflow:"hidden", border:`1px solid ${m.color}30` }}>
      <div onClick={()=>setExpanded(!expanded)} style={{
        display:"flex", alignItems:"center", gap:8, padding:"7px 12px",
        background:m.bg, cursor:"pointer"
      }}>
        <span style={{ width:6, height:6, borderRadius:"50%", background:m.color, flexShrink:0 }} />
        <span style={{ fontSize:9, fontWeight:700, color:m.color, letterSpacing:"0.1em", minWidth:60 }}>{m.label}</span>
        <span style={{ fontSize:11, color:"#94A3B8", fontFamily:"monospace", flex:1 }}>{event.tool}</span>
        <span style={{ fontSize:9, color:"#334155" }}>{expanded?"▲":"▼"}</span>
      </div>
      {expanded && (
        <div style={{ background:"#050a0f", padding:"8px 12px" }}>
          <div style={{ fontSize:9, color:"#334155", marginBottom:4 }}>INPUT</div>
          <pre style={{ fontSize:9, color:"#60A5FA", fontFamily:"monospace", margin:0, whiteSpace:"pre-wrap", wordBreak:"break-word" }}>
            {JSON.stringify(event.input,null,2)}
          </pre>
          {event.result && <>
            <div style={{ fontSize:9, color:"#334155", marginTop:8, marginBottom:4 }}>OUTPUT</div>
            <pre style={{ fontSize:9, color:"#4ADE80", fontFamily:"monospace", margin:0, whiteSpace:"pre-wrap", wordBreak:"break-word", maxHeight:200, overflowY:"auto" }}>
              {String(event.result).slice(0,1500)}{String(event.result).length>1500?"\n...[truncated]":""}
            </pre>
          </>}
        </div>
      )}
    </div>
  );
}

function WorkflowNode({ step, status }) {
  const mcp = step.mcp || "complete";
  const m = MCP_META[mcp] || MCP_META.complete;
  const isActive = status === "running";
  const isDone = status === "done";
  return (
    <div style={{
      display:"flex", alignItems:"stretch", gap:0,
      opacity: status === "skipped" ? 0.3 : 1,
      transition:"opacity 0.3s"
    }}>
      <div style={{
        width:3, background: isDone ? m.color : isActive ? m.color : "#1e293b",
        borderRadius:2, flexShrink:0, transition:"background 0.3s",
        boxShadow: isActive ? `0 0 8px ${m.color}` : "none"
      }} />
      <div style={{
        flex:1, padding:"7px 12px",
        background: isActive ? m.bg : isDone ? `${m.bg}80` : "transparent",
        borderBottom:"1px solid #0f172a"
      }}>
        <div style={{ display:"flex", gap:6, alignItems:"center" }}>
          <span style={{ fontSize:8, fontWeight:700, color:m.color, letterSpacing:"0.08em", minWidth:50 }}>{m.label}</span>
          <span style={{ fontSize:11, color: isDone ? "#F1F5F9" : "#94A3B8", fontFamily:"monospace" }}>{step.label}</span>
          {isActive && <span style={{ marginLeft:"auto", fontSize:9, color:m.color, animation:"pulse 1s infinite" }}>●</span>}
          {isDone && <span style={{ marginLeft:"auto", fontSize:9, color:m.color }}>✓</span>}
        </div>
        {step.type === "condition" && step.condition && (
          <div style={{ fontSize:9, color:"#A855F7", paddingLeft:56, marginTop:2, fontFamily:"monospace" }}>
            IF {step.condition.expression}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════════════════

export default function WorkflowAI() {
  const [prompt, setPrompt] = useState("");
  const [workflow, setWorkflow] = useState(null);
  const [parsing, setParsing] = useState(false);
  const [running, setRunning] = useState(false);
  const [events, setEvents] = useState([]);
  const [stepStatus, setStepStatus] = useState({});
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("execute"); // execute | workflow | json
  const [toolCount, setToolCount] = useState(0);
  const [done, setDone] = useState(false);
  // Fix 2: API configuration — key + URL editable at runtime in the UI.
  // Default URL is Anthropic direct (dev mode). Switch to proxy URL for production.
  const [apiKey, setApiKey]   = useState("");
  const [apiUrl, setApiUrl]   = useState("http://localhost:8000/v1/messages");
  const [showSettings, setShowSettings] = useState(false);
  const abortRef = useRef(false);
  const logRef = useRef(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [events]);

  const addEvent = useCallback((ev) => {
    setEvents(prev => [...prev.slice(-200), { ...ev, ts: new Date().toLocaleTimeString() }]);
    if (ev.type === "tool_start") setToolCount(c => c + 1);
    // Update step status based on tool calls
    if (ev.type === "tool_start") {
      const mcp = TOOL_MCP_MAP[ev.tool];
      setStepStatus(prev => ({ ...prev, [`tool_${ev.id}`]: { tool: ev.tool, mcp, status: "running", input: ev.input } }));
    }
    if (ev.type === "tool_result") {
      setStepStatus(prev => ({
        ...prev,
        [`tool_${ev.id}`]: { ...prev[`tool_${ev.id}`], status: "done", result: ev.result }
      }));
    }
  }, []);

  const handleParse = async () => {
    if (!prompt.trim()) return;
    setParsing(true);
    setError("");
    setWorkflow(null);
    setEvents([]);
    setStepStatus({});
    setDone(false);
    setToolCount(0);
    const apiCfg = { apiKey, apiUrl };
    try {
      addEvent({ type: "ai_text", text: "🧠 Parsing your workflow with Claude AI..." });
      const wf = await parseWorkflowAI(prompt, apiCfg);
      setWorkflow(wf);
      setActiveTab("workflow");
      addEvent({ type: "ai_text", text: `✅ Workflow parsed: "${wf.workflow_name}" — ${wf.steps.length} steps identified` });
    } catch (e) {
      setError(e.message);
      addEvent({ type: "ai_text", text: `❌ ${e.message}` });
    }
    setParsing(false);
  };

  const handleExecute = async () => {
    if (!prompt.trim()) return;
    abortRef.current = false;
    setRunning(true);
    setDone(false);
    setEvents([]);
    setToolCount(0);
    setActiveTab("execute");

    const executionPrompt = `Execute this automation workflow step by step. Use the available tools to carry out each action. After each tool result, analyze what you found and explain your reasoning. Make real decisions at conditional branches based on actual values.

WORKFLOW TO EXECUTE:
${prompt}

Start executing now. Call the first tool, analyze the result, then continue to the next step.`;

    try {
      const generator = runAgentLoop(executionPrompt, addEvent, { apiKey, apiUrl });
      for await (const event of generator) {
        if (abortRef.current) break;
        if (event.type === "done") { setDone(true); break; }
      }
    } catch (e) {
      addEvent({ type: "ai_text", text: `❌ Execution error: ${e.message}` });
      setError(e.message);
    }
    setRunning(false);
  };

  const handleStop = () => { abortRef.current = true; setRunning(false); };
  const handleReset = () => {
    abortRef.current = true;
    setRunning(false);
    setEvents([]);
    setStepStatus({});
    setDone(false);
    setToolCount(0);
    setError("");
  };

  // Tool call events grouped for sidebar stats
  const toolEvents = events.filter(e => e.type === "tool_start");
  const mcpCounts = toolEvents.reduce((acc, e) => {
    const m = TOOL_MCP_MAP[e.tool] || "ai";
    acc[m] = (acc[m] || 0) + 1;
    return acc;
  }, {});

  const aiTextEvents = events.filter(e => e.type === "ai_text");
  const toolCallEvents = events.filter(e => e.type === "tool_start");

  return (
    <div style={{
      fontFamily:"'IBM Plex Mono','Courier New',monospace",
      background:"#060912", minHeight:"100vh",
      color:"#CBD5E1", display:"flex", flexDirection:"column"
    }}>
      <style>{`
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
        @keyframes glow{0%,100%{box-shadow:0 0 4px #00C7B730}50%{box-shadow:0 0 12px #00C7B760}}
        *{box-sizing:border-box;}
        textarea:focus,input:focus{outline:none;}
        ::-webkit-scrollbar{width:3px;height:3px;}
        ::-webkit-scrollbar-track{background:#070b14;}
        ::-webkit-scrollbar-thumb{background:#1e3a5f;border-radius:2px;}
        button:hover{filter:brightness(1.15);}
      `}</style>

      {/* ── Header ──────────────────────────────────────────────────────── */}
      <div style={{
        borderBottom:"1px solid #0f2a42",
        background:"linear-gradient(135deg,#06091200,#0f172a50)",
      }}>
        <div style={{
          padding:"14px 24px",
          display:"flex", alignItems:"center", justifyContent:"space-between",
          flexWrap:"wrap", gap:10
        }}>
          <div>
            <div style={{ fontSize:9, color:"#1D4ED8", letterSpacing:"0.2em", marginBottom:3 }}>CLAUDE-POWERED · MCP WORKFLOW ENGINE</div>
            <div style={{ fontSize:19, fontWeight:700, color:"#F8FAFC", letterSpacing:"-0.02em" }}>
              AI Workflow Executor
            </div>
          </div>
          <div style={{ display:"flex", gap:12, alignItems:"center" }}>
            {running && (
              <div style={{ display:"flex", alignItems:"center", gap:6, fontSize:11, color:"#F59E0B" }}>
                <span style={{ animation:"pulse 1s infinite" }}>⬡</span>
                Claude is executing...
              </div>
            )}
            <div style={{ display:"flex", gap:6 }}>
              {Object.entries(MCP_META).filter(([k])=>k!=="complete"&&k!=="ai").map(([k,m])=>(
                <span key={k} style={{ background:m.bg, color:m.color, border:`1px solid ${m.color}30`, fontSize:9, fontWeight:700, padding:"2px 8px", borderRadius:3, letterSpacing:"0.1em" }}>
                  {m.label}
                </span>
              ))}
            </div>
            {/* Fix 2: Settings toggle */}
            <button
              onClick={()=>setShowSettings(s=>!s)}
              title="API settings"
              style={{
                background: showSettings ? "#1e3a5f" : "transparent",
                border:"1px solid #1e293b", borderRadius:6,
                color: apiKey ? "#4ADE80" : "#475569",
                padding:"5px 10px", fontSize:13, cursor:"pointer",
                fontFamily:"inherit"
              }}
            >⚙</button>
          </div>
        </div>

        {/* Fix 2: Settings panel — API key + endpoint URL ─────────────── */}
        {showSettings && (
          <div style={{
            padding:"12px 24px 16px",
            borderTop:"1px solid #0f2a42",
            background:"#070b14",
            display:"flex", flexWrap:"wrap", gap:16, alignItems:"flex-end",
            animation:"fadeIn 0.15s ease"
          }}>
            {/* API Key */}
            <div style={{ flex:"1 1 260px" }}>
              <div style={{ fontSize:9, color:"#334155", letterSpacing:"0.12em", marginBottom:5 }}>
                ANTHROPIC API KEY
                <span style={{ marginLeft:6, color:"#1e3a5f" }}>
                  {"(not needed — proxy handles OAuth)"}
                </span>
              </div>
              <input
                type="password"
                value={apiKey}
                onChange={e=>setApiKey(e.target.value)}
                placeholder="sk-ant-..."
                style={{
                  width:"100%", background:"#0d1117", border:`1px solid ${apiKey ? "#16a34a" : "#1e3a5f"}`,
                  borderRadius:6, padding:"7px 10px", color:"#CBD5E1",
                  fontSize:11, fontFamily:"inherit"
                }}
              />
            </div>
            {/* API URL */}
            <div style={{ flex:"1 1 320px" }}>
              <div style={{ fontSize:9, color:"#334155", letterSpacing:"0.12em", marginBottom:5 }}>
                API ENDPOINT
              </div>
              <div style={{ display:"flex", gap:6 }}>
                <input
                  type="text"
                  value={apiUrl}
                  onChange={e=>setApiUrl(e.target.value)}
                  style={{
                    flex:1, background:"#0d1117", border:"1px solid #1e3a5f",
                    borderRadius:6, padding:"7px 10px", color:"#CBD5E1",
                    fontSize:11, fontFamily:"inherit"
                  }}
                />
                <button
                  onClick={()=>setApiUrl("http://localhost:8000/v1/messages")}
                  title="Reset to Anthropic direct"
                  style={{ background:"#0f172a", color:"#475569", border:"1px solid #1e293b", borderRadius:6, padding:"6px 10px", fontSize:9, cursor:"pointer", fontFamily:"inherit", whiteSpace:"nowrap" }}
                >Direct</button>
                <button
                  onClick={()=>setApiUrl("http://localhost:8000/v1/messages")}
                  title="Use local FastAPI proxy"
                  style={{ background:"#0f172a", color:"#475569", border:"1px solid #1e293b", borderRadius:6, padding:"6px 10px", fontSize:9, cursor:"pointer", fontFamily:"inherit", whiteSpace:"nowrap" }}
                >Proxy</button>
              </div>
            </div>
            {/* Mode indicator */}
            <div style={{ fontSize:9, color:"#334155", paddingBottom:8, whiteSpace:"nowrap" }}>
              Mode:&nbsp;
              <span style={{ color: "#4ADE80", fontWeight:700 }}>
                {"Gen AI Gateway (proxy)"}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* ── Prompt ──────────────────────────────────────────────────────── */}
      <div style={{ padding:"16px 24px 0" }}>
        <div style={{ fontSize:9, color:"#334155", letterSpacing:"0.15em", marginBottom:8 }}>
          DESCRIBE YOUR AUTOMATION — CLAUDE WILL PARSE, PLAN & EXECUTE IT
        </div>
        <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
          <textarea
            value={prompt}
            onChange={e=>setPrompt(e.target.value)}
            placeholder="e.g. Trigger DAG Alpha, wait for completion, get task_b logs and extract total_count. If > 1000, run SQL on table_z and assert column_b = 10. If passes, trigger DAG Beta, wait, then assert S3 bucket-2 path Gama has 1000 files."
            style={{
              flex:1, background:"#0d1117", border:"1px solid #1e3a5f", borderRadius:8,
              padding:"12px 14px", color:"#CBD5E1", fontSize:12,
              fontFamily:"inherit", resize:"vertical", minHeight:80, lineHeight:1.6
            }}
          />
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <button onClick={handleParse} disabled={parsing||running||!prompt.trim()} style={{
              background: (parsing||running) ? "#0f172a" : "linear-gradient(135deg,#1D4ED8,#6D28D9)",
              color:(parsing||running)?"#334155":"#fff",
              border:"none", borderRadius:8, padding:"11px 18px",
              fontSize:11, fontFamily:"inherit", fontWeight:700,
              cursor:(parsing||running)?"not-allowed":"pointer",
              letterSpacing:"0.05em", whiteSpace:"nowrap"
            }}>
              {parsing?"⌛ Parsing...":"⚡ Parse"}
            </button>
            <button onClick={handleExecute} disabled={running||!prompt.trim()} style={{
              background:running?"#0f172a":"linear-gradient(135deg,#059669,#047857)",
              color:running?"#334155":"#fff",
              border:"none", borderRadius:8, padding:"11px 18px",
              fontSize:11, fontFamily:"inherit", fontWeight:700,
              cursor:running?"not-allowed":"pointer",
              letterSpacing:"0.05em", whiteSpace:"nowrap"
            }}>
              {running?"⏳ Running...":"▶ Execute"}
            </button>
          </div>
        </div>

        {/* Examples */}
        <div style={{ marginTop:10, display:"flex", gap:6, flexWrap:"wrap", alignItems:"center" }}>
          <span style={{ fontSize:9, color:"#1e3a5f" }}>EXAMPLES:</span>
          {["DAG→Log→SQL→S3","S3+Python+Excel","DAG Monitor+Alert","Subscribers Pipeline"].map((lbl,i)=>(
            <button key={lbl} onClick={()=>setPrompt(EXAMPLES[i])} style={{
              background:"transparent", color:"#334155", border:"1px solid #1e293b",
              borderRadius:4, padding:"3px 8px", fontSize:9, fontFamily:"inherit", cursor:"pointer"
            }}>{lbl}</button>
          ))}
        </div>

        {error && (
          <div style={{ marginTop:8, color:"#EF4444", fontSize:11, padding:"6px 10px", background:"#1a0505", borderRadius:6, border:"1px solid #7f1d1d" }}>
            ❌ {error}
          </div>
        )}
      </div>

      {/* ── Tabs ────────────────────────────────────────────────────────── */}
      <div style={{ padding:"10px 24px 0", borderBottom:"1px solid #0f2a42", marginTop:12, display:"flex", justifyContent:"space-between", alignItems:"flex-end" }}>
        <div style={{ display:"flex" }}>
          {[["execute","Live Execution"],["workflow","Workflow Plan"],["json","JSON"]].map(([t,lbl])=>(
            <button key={t} onClick={()=>setActiveTab(t)} style={{
              background:activeTab===t?"#0d1117":"transparent",
              color:activeTab===t?"#60A5FA":"#475569",
              border:"none", borderBottom:activeTab===t?"2px solid #3B82F6":"2px solid transparent",
              padding:"7px 16px", fontSize:11, fontFamily:"inherit", cursor:"pointer"
            }}>{lbl}</button>
          ))}
        </div>
        <div style={{ display:"flex", gap:8, paddingBottom:8, alignItems:"center" }}>
          {toolCount > 0 && <span style={{ fontSize:10, color:"#475569" }}>{toolCount} tool calls</span>}
          {done && <span style={{ fontSize:10, color:"#22C55E", fontWeight:700 }}>✓ Complete</span>}
          {running && <button onClick={handleStop} style={{ background:"#7f1d1d", color:"#FCA5A5", border:"none", borderRadius:5, padding:"4px 12px", fontSize:10, fontFamily:"inherit", cursor:"pointer" }}>Stop</button>}
          {(events.length > 0 || done) && !running && <button onClick={handleReset} style={{ background:"transparent", color:"#475569", border:"1px solid #1e293b", borderRadius:5, padding:"4px 10px", fontSize:10, fontFamily:"inherit", cursor:"pointer" }}>Reset</button>}
        </div>
      </div>

      {/* ── Main ────────────────────────────────────────────────────────── */}
      <div style={{ flex:1, display:"flex", overflow:"hidden", minHeight:0 }}>

        {/* Execute tab */}
        {activeTab === "execute" && (
          <div style={{ flex:1, display:"flex", overflow:"hidden" }}>
            {/* Event stream */}
            <div ref={logRef} style={{ flex:1, overflowY:"auto", padding:"16px 20px", display:"flex", flexDirection:"column", gap:6 }}>
              {events.length === 0 && !running && (
                <div style={{ textAlign:"center", marginTop:60, color:"#1e3a5f" }}>
                  <div style={{ fontSize:32, marginBottom:8 }}>⬡</div>
                  <div style={{ fontSize:13, letterSpacing:"0.1em" }}>ENTER A WORKFLOW AND CLICK EXECUTE</div>
                  <div style={{ fontSize:10, color:"#0f2a42", marginTop:4 }}>Claude will plan, execute tools, analyze results, and make decisions</div>
                </div>
              )}

              {events.map((ev, i) => {
                if (ev.type === "ai_text") return (
                  <div key={i} style={{ fontSize:11, color:"#CBD5E1", lineHeight:1.7, padding:"4px 0", animation:"fadeIn 0.2s ease" }}>
                    <span style={{ color:"#1e3a5f", fontSize:9, userSelect:"none" }}>{ev.ts} </span>
                    <span style={{ color:"#F59E0B", fontSize:9, marginRight:6 }}>AI</span>
                    {ev.text}
                  </div>
                );
                if (ev.type === "tool_start") {
                  const resultEv = events.find(e => e.type === "tool_result" && e.id === ev.id);
                  return <ToolCallCard key={i} event={{ ...ev, result: resultEv?.result }} />;
                }
                if (ev.type === "tool_result") return null; // rendered in tool_start card
                if (ev.type === "thinking") return (
                  <div key={i} style={{ fontSize:9, color:"#1e3a5f", animation:"pulse 1s infinite" }}>
                    {ev.text}
                  </div>
                );
                return null;
              })}

              {running && (
                <div style={{ display:"flex", gap:6, alignItems:"center", color:"#F59E0B", fontSize:11, padding:"4px 0" }}>
                  <span style={{ animation:"pulse 0.8s infinite" }}>⬡</span>
                  Claude is thinking...
                </div>
              )}

              {done && (
                <div style={{ marginTop:8, padding:"12px 16px", background:"#052e16", border:"1px solid #16a34a40", borderRadius:8, animation:"fadeIn 0.3s ease" }}>
                  <div style={{ fontSize:13, fontWeight:700, color:"#4ADE80" }}>✅ Workflow Execution Complete</div>
                  <div style={{ fontSize:10, color:"#22C55E", marginTop:4 }}>{toolCount} tool calls executed · All steps processed by Claude AI</div>
                </div>
              )}
            </div>

            {/* Sidebar stats */}
            {(running || done || toolCount > 0) && (
              <div style={{ width:180, background:"#070b14", borderLeft:"1px solid #0f2a42", padding:"14px 12px", display:"flex", flexDirection:"column", gap:14, flexShrink:0 }}>
                <div style={{ fontSize:9, color:"#334155", letterSpacing:"0.12em" }}>EXECUTION STATS</div>
                {[["Tool Calls", toolCount, "#60A5FA"],["AI Responses", aiTextEvents.length, "#F59E0B"],["Status", done ? "Done" : running ? "Running" : "Idle", done ? "#4ADE80" : running ? "#F59E0B" : "#475569"]].map(([k,v,c])=>(
                  <div key={k}>
                    <div style={{ fontSize:8, color:"#334155", marginBottom:2 }}>{k}</div>
                    <div style={{ fontSize:18, color:c, fontWeight:700 }}>{v}</div>
                  </div>
                ))}
                {Object.keys(mcpCounts).length > 0 && (
                  <div>
                    <div style={{ fontSize:8, color:"#334155", marginBottom:8 }}>BY SERVICE</div>
                    {Object.entries(mcpCounts).map(([mcp,n])=>(
                      <div key={mcp} style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
                        <span style={{ fontSize:9, color:MCP_META[mcp]?.color||"#60A5FA" }}>{MCP_META[mcp]?.label||mcp}</span>
                        <span style={{ fontSize:9, color:"#94A3B8" }}>{n}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Workflow plan tab */}
        {activeTab === "workflow" && (
          <div style={{ flex:1, overflowY:"auto", padding:"16px 24px" }}>
            {!workflow && !parsing && (
              <div style={{ textAlign:"center", marginTop:60, color:"#1e3a5f" }}>
                <div style={{ fontSize:13 }}>Click ⚡ Parse to generate a workflow plan</div>
              </div>
            )}
            {parsing && (
              <div style={{ textAlign:"center", marginTop:60, color:"#3B82F6", animation:"pulse 1s infinite" }}>
                ⬡ Claude is analyzing your prompt...
              </div>
            )}
            {workflow && (
              <div style={{ animation:"fadeIn 0.3s ease" }}>
                <div style={{ marginBottom:16, padding:"10px 16px", background:"#0d1117", border:"1px solid #1e293b", borderRadius:8 }}>
                  <div style={{ fontSize:14, fontWeight:700, color:"#F1F5F9" }}>{workflow.workflow_name}</div>
                  <div style={{ fontSize:10, color:"#64748B", marginTop:2 }}>{workflow.description}</div>
                  <div style={{ fontSize:9, color:"#334155", marginTop:6 }}>{workflow.steps?.length} steps identified · Click ▶ Execute to run with Claude AI</div>
                </div>
                <div style={{ border:"1px solid #1e293b", borderRadius:8, overflow:"hidden" }}>
                  {workflow.steps?.map(step => (
                    <WorkflowNode key={step.id} step={step} status="idle" />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* JSON tab */}
        {activeTab === "json" && (
          <div style={{ flex:1, overflowY:"auto", padding:"16px 24px" }}>
            <pre style={{ background:"#0d1117", border:"1px solid #1e293b", borderRadius:8, padding:16, fontSize:10, color:"#94A3B8", lineHeight:1.7, fontFamily:"monospace", overflow:"auto" }}>
              {workflow ? JSON.stringify(workflow, null, 2) : "Parse a workflow first"}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
