# Workflow Studio — AI-Powered MCP Automation Engine

Type any automation instruction in plain English.
Claude parses it, plans the steps, executes tools, reads results, evaluates conditions, and makes decisions — all autonomously.

---

## Project Structure

```
workflow-studio/
│
├── frontend/
│   ├── WorkflowAI.jsx          ← Main React component (drop into your app)
│   └── package.json
│
├── backend/
│   ├── api_server.py           ← Optional FastAPI proxy (production use)
│   ├── requirements.txt        ← Python dependencies
│   ├── .env.example            ← Copy to .env and fill credentials
│   ├── mcp_config.json         ← Claude Desktop / MCP registration
│   │
│   ├── config/
│   │   └── settings.py         ← Centralized env var loader
│   │
│   └── mcp_servers/
│       ├── airflow_mcp/        ← 27 Airflow tools
│       │   └── server.py
│       ├── ssms_mcp/           ← 28 SQL Server tools
│       │   └── server.py
│       ├── s3_mcp/             ← 26 AWS S3 tools
│       │   └── server.py
│       ├── python_executor_mcp/← 21 Python execution tools
│       │   └── server.py
│       ├── browser_mcp/        ← 22 Playwright browser automation tools
│       └── custom_mcp/         ← TEMPLATE: add any new service here
│           └── server.py
│
└── docs/
    └── adding_new_mcp.md
```

---

## Quick Start

### 1. Backend (MCP Servers)

```bash
cd backend
pip install -r requirements.txt

# Configure credentials
cp .env.example .env
# Edit .env with your Airflow URL, SQL Server, AWS credentials
```

### 2. Register MCPs with Claude Desktop

Edit `backend/mcp_config.json` — replace `/path/to/workflow-studio/backend` with your actual path.

Copy to Claude Desktop config:
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

Restart Claude Desktop. All 4 MCP servers appear as tool groups.

### 3. Frontend

The `WorkflowAI.jsx` component is self-contained — drop it into any React app.

```jsx
// In your App.js or any route:
import WorkflowAI from './WorkflowAI';
export default function App() { return <WorkflowAI />; }
```

It calls the Anthropic API directly from the browser (dev mode).
For production, run `api_server.py` and point the fetch URL there instead.

### 4. (Optional) Production API Proxy

```bash
cd backend
pip install fastapi uvicorn anthropic
export ANTHROPIC_API_KEY=sk-ant-...
uvicorn api_server:app --reload --port 8000
```

Then in `WorkflowAI.jsx`, change the two fetch URLs from:
```
https://api.anthropic.com/v1/messages
```
to:
```
http://localhost:8000/v1/messages
```
and remove the `anthropic-dangerous-direct-browser-access` header.

---

## MCP Tool Count

| Service            | Tools | Key Capabilities |
|--------------------|-------|-----------------|
| Apache Airflow     | 27    | Trigger, wait, poll, logs, XCom, variables, connections |
| SQL Server (SSMS)  | 28    | Queries, assertions, schema, Excel export, stored procs |
| AWS S3             | 26    | Browse, search, read, write, download, assert files |
| Python Executor    | 21    | Execute code, analyze data, parse logs, export Excel |
| Browser (Playwright) | 22  | Navigate, click, type, extract, screenshot, assert |
| **Total**          | **124** | |

---

## What Happens When a Tool Isn't Available?

If you ask Claude to do something not covered by the 4 MCP servers (e.g. "send a Slack message", "create a Jira ticket", "query Snowflake"):

**Claude's behavior:**
1. Attempts to reason through the steps anyway
2. Explains what it would do if it had the tool
3. Suggests what MCP server to add

**To add any new service:**
1. Copy `backend/mcp_servers/custom_mcp/server.py`
2. Implement your tools (Step 1 & 2 in that file)
3. Register in `mcp_config.json` (Step 3)
4. Add the tool→MCP mapping in `WorkflowAI.jsx` (Step 4)

That's it. Claude automatically picks up and uses new tools.

### Services you can add with the template:
- Slack, Microsoft Teams
- Jira, ServiceNow, Linear
- Snowflake, PostgreSQL, MySQL, MongoDB
- Databricks, Spark
- GitHub, GitLab
- PagerDuty, OpsGenie
- Email (SMTP)
- Any REST API
- Kafka, RabbitMQ
- Salesforce, HubSpot

---

## Example Workflows

```
Trigger DAG Alpha, wait for it to complete, fetch task_b logs and extract
total_count. If > 1000, run SQL on table_z and assert column_b = 10.
If passes, trigger DAG Beta, wait for it, then assert S3 bucket-2 at
path Gama has 1000 files.
```

```
Check S3 bucket data-lake at path raw/sales/ has at least 5 CSV files.
Read the latest one and run Python to calculate average revenue.
Then run SQL SELECT SUM(revenue) FROM sales and assert sum > 50000.
Export results to Excel as daily_report.xlsx.
```

```
List all DAGs. Fetch all task logs from DAG daily_etl and search for
ERROR messages. If any errors found, run SQL on audit_log and assert
no rows where resolved=0. Then trigger DAG alert_pipeline.
```

---

## Architecture

```
User Prompt
    │
    ▼
Claude API (parse)
    │ Structured workflow plan
    ▼
Claude API (execute — agentic loop)
    │
    ├── tool_use: trigger_dag_run  ──► Airflow MCP ──► Airflow REST API
    ├── tool_use: wait_for_dag_run ──► Airflow MCP ──► polls /dagRuns
    ├── tool_use: get_task_logs    ──► Airflow MCP ──► /taskInstances/logs
    ├── tool_use: extract_log_counts─► Python MCP  ──► parses log text
    │   [Claude reads result, evaluates total_count > 1000 → TRUE]
    ├── tool_use: run_query        ──► SSMS MCP    ──► pyodbc → SQL Server
    ├── tool_use: assert_value_exists─► SSMS MCP   ──► verifies column_b=10
    │   [Claude reads PASS, decides to continue]
    ├── tool_use: trigger_dag_run  ──► Airflow MCP ──► triggers DAG Beta
    ├── tool_use: wait_for_dag_run ──► Airflow MCP ──► polls until success
    └── tool_use: assert_prefix_has_files─► S3 MCP ──► boto3 → AWS S3
        [Claude reads 1043 files ≥ 1000 → PASS → workflow complete]
```

---

## Key Design Principles

- **Claude is the orchestrator** — not a parser. It reads actual results and makes real decisions.
- **Tools are stateless** — each MCP tool is independent, no shared state between them.
- **Conditions are AI-evaluated** — Claude reads log text, SQL results, S3 counts and reasons about them.
- **Extensible by design** — adding a new service requires touching exactly 2 files.
