"""
genai_gateway_tools/oauth.py
─────────────────────────────
OAuth2 client-credentials token fetcher for the Gen AI Gateway.

Handles:
  - Fetching an access token via client_credentials grant
  - Caching the token in memory
  - Proactively refreshing before expiry (early_refresh_seconds buffer)
  - Thread-safe refresh via threading.Lock

Usage:
    from genai_gateway_tools.oauth import OAuthConfig, OAuthTokenFetcher

    cfg = OAuthConfig(
        token_url=os.environ["OAUTH_TOKEN_URL"],
        client_id=os.environ["OAUTH_CLIENT_ID"],
        client_secret=os.environ["OAUTH_CLIENT_SECRET"],
        grant_type=os.environ["OAUTH_GRANT_TYPE"],
        scope=os.environ["OAUTH_SCOPE"],
    )
    fetcher = OAuthTokenFetcher(cfg)
    token = fetcher.get_token()   # returns cached token, refreshing if needed
"""

import threading
import httpx
from datetime import datetime
from dataclasses import dataclass, field, asdict


@dataclass
class OAuthConfig:
    """Class for keeping track of OAuth token configs."""
    token_url:             str = field(repr=False)    # excluded from oauth_payload
    client_id:             str
    client_secret:         str
    grant_type:            str
    scope:                 str
    early_refresh_seconds: int = field(default=300, repr=False)  # refresh N secs before expiry

    def oauth_payload(self) -> dict:
        """Return only fields where repr=True — excludes token_url and early_refresh_seconds."""
        return {
            k: v
            for k, v in asdict(self).items()
            if self.__dataclass_fields__[k].repr
        }


class OAuthTokenFetcher:
    """
    Fetches and caches an OAuth access token.
    Handles proactive refresh before the token expires.
    Thread-safe: concurrent calls to get_token() will only fetch once.
    """

    OAUTH_HEADERS = {"Content-Type": "application/x-www-form-urlencoded"}

    def __init__(self, oauth_config: OAuthConfig) -> None:
        self._oauth_config = oauth_config
        self._token: dict = {}
        self._refresh_after: float = 0.0
        self._lock = threading.Lock()
        self._fetch_token()   # eager fetch on construction

    def _fetch_token(self) -> None:
        """Fetch a fresh token and update the cache."""
        response = httpx.post(
            url=self._oauth_config.token_url,
            data=self._oauth_config.oauth_payload(),
            headers=self.OAUTH_HEADERS,
            timeout=10,
        )
        response.raise_for_status()
        self._token = response.json()
        expires_in = self._token.get("expires_in", 3600)
        self._refresh_after = (
            datetime.now().timestamp()
            + expires_in
            - self._oauth_config.early_refresh_seconds
        )

    def get_token(self) -> str:
        """
        Return a valid access token, refreshing proactively if near expiry.
        Thread-safe: only one thread will refresh at a time.
        """
        if datetime.now().timestamp() > self._refresh_after:
            with self._lock:
                # Double-checked locking — another thread may have already refreshed
                if datetime.now().timestamp() > self._refresh_after:
                    self._fetch_token()
        return self._token["access_token"]
