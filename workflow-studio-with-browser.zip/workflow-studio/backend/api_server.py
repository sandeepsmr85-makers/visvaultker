"""
backend/api_server.py
──────────────────────
FastAPI proxy server — Gen AI Gateway edition.

PURPOSE:
  The React frontend sends requests in Anthropic message format.
  This server:
    1. Translates the request to OpenAI format
    2. Fetches a fresh OAuth token from the Gen AI Gateway
    3. Calls the LLM via the OpenAI SDK pointed at the gateway base URL
    4. Translates the response back to Anthropic format (so the frontend
       doesn't need to change)
    5. Intercepts any tool_use blocks and routes them to real MCP servers
       via JSON-RPC over stdio

ARCHITECTURE:
  Browser → FastAPI (this file) → Gen AI Gateway (OpenAI-compatible)
                               → Airflow MCP  → Browser MCP → SFTP MCP
                               → SSMS MCP     → HTTP MCP    → S3 MCP
                               → Python MCP

RUN:
  pip install fastapi uvicorn openai httpx
  uvicorn api_server:app --reload --port 8000

REQUIRED ENV VARS (in backend/.env):
  OAUTH_TOKEN_URL, OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET,
  OAUTH_GRANT_TYPE, OAUTH_SCOPE, GW_BASE_URL, LLM_MODEL
"""

import asyncio
import json
import os
import subprocess
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
from pydantic import BaseModel

from config.settings import (
    AIRFLOW_BASE_URL, SSMS_SERVER, AWS_REGION, ALLOWED_ORIGINS,
    OAUTH_TOKEN_URL, OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET,
    OAUTH_GRANT_TYPE, OAUTH_SCOPE, GW_BASE_URL, LLM_MODEL,
)
from genai_gateway_tools.oauth import OAuthConfig, OAuthTokenFetcher

# ─── App ──────────────────────────────────────────────────────────────────────

app = FastAPI(title="Workflow Studio — Gen AI Gateway", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["POST", "GET", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "x-api-key"],
)

# ─── OAuth token fetcher ──────────────────────────────────────────────────────

_oauth_cfg = OAuthConfig(
    token_url=OAUTH_TOKEN_URL,
    client_id=OAUTH_CLIENT_ID,
    client_secret=OAUTH_CLIENT_SECRET,
    grant_type=OAUTH_GRANT_TYPE,
    scope=OAUTH_SCOPE,
)
_token_fetcher = OAuthTokenFetcher(_oauth_cfg)


def _get_openai_client() -> OpenAI:
    """Return an OpenAI client with a fresh OAuth token pointed at the gateway."""
    return OpenAI(api_key=_token_fetcher.get_token(), base_url=GW_BASE_URL)


# ─── Format translation: Anthropic → OpenAI ──────────────────────────────────

def _to_oai_tools(tools: list[dict]) -> list[dict]:
    """input_schema → parameters, wrap in OpenAI function tool format."""
    return [
        {
            "type": "function",
            "function": {
                "name":        t["name"],
                "description": t.get("description", ""),
                "parameters":  t.get("input_schema", t.get("parameters", {"type": "object", "properties": {}})),
            },
        }
        for t in tools
    ]


def _to_oai_messages(messages: list[dict], system: str | None = None) -> list[dict]:
    """
    Translate Anthropic message array to OpenAI message array.

    Handles:
      - system string       → {role: system}
      - string content      → kept as-is
      - text blocks         → joined into string content
      - tool_use blocks     → assistant message with tool_calls
      - tool_result blocks  → role="tool" messages (one per result)
    """
    out: list[dict] = []

    if system:
        out.append({"role": "system", "content": system})

    for msg in messages:
        role    = msg["role"]
        content = msg["content"]

        if isinstance(content, str):
            out.append({"role": role, "content": content})
            continue

        if isinstance(content, list):
            if role == "user":
                text_parts: list[str] = []
                for block in content:
                    if isinstance(block, str):
                        text_parts.append(block)
                    elif block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif block.get("type") == "tool_result":
                        # Each tool_result → separate tool-role message
                        tc = block.get("content", "")
                        if isinstance(tc, list):
                            tc = "\n".join(b.get("text", "") for b in tc if isinstance(b, dict))
                        out.append({
                            "role":         "tool",
                            "tool_call_id": block.get("tool_use_id", ""),
                            "content":      str(tc),
                        })
                if text_parts:
                    combined = "\n".join(text_parts).strip()
                    if combined:
                        out.append({"role": "user", "content": combined})

            elif role == "assistant":
                text_parts = []
                tool_calls = []
                for block in content:
                    if isinstance(block, str):
                        text_parts.append(block)
                    elif block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif block.get("type") == "tool_use":
                        tool_calls.append({
                            "id":   block.get("id", f"call_{block.get('name')}"),
                            "type": "function",
                            "function": {
                                "name":      block.get("name", ""),
                                "arguments": json.dumps(block.get("input", {})),
                            },
                        })
                am: dict = {"role": "assistant", "content": "\n".join(text_parts).strip() or None}
                if tool_calls:
                    am["tool_calls"] = tool_calls
                out.append(am)

    return out


# ─── Format translation: OpenAI → Anthropic ──────────────────────────────────

def _to_anthropic_response(oai_resp) -> dict:
    """
    Translate OpenAI chat completion → Anthropic messages API response shape.
    The frontend expects this exact shape.
    """
    choice  = oai_resp.choices[0]
    message = choice.message
    blocks: list[dict] = []

    if message.content:
        blocks.append({"type": "text", "text": message.content})

    if message.tool_calls:
        for tc in message.tool_calls:
            try:
                args = json.loads(tc.function.arguments)
            except (json.JSONDecodeError, TypeError):
                args = {}
            blocks.append({
                "type":  "tool_use",
                "id":    tc.id,
                "name":  tc.function.name,
                "input": args,
            })

    finish      = choice.finish_reason or "stop"
    stop_reason = "tool_use" if finish == "tool_calls" else "end_turn"
    usage       = oai_resp.usage

    return {
        "id":          oai_resp.id,
        "type":        "message",
        "role":        "assistant",
        "model":       oai_resp.model,
        "stop_reason": stop_reason,
        "content":     blocks,
        "usage": {
            "input_tokens":  usage.prompt_tokens     if usage else 0,
            "output_tokens": usage.completion_tokens if usage else 0,
        },
    }


# ─── Tool → MCP routing ───────────────────────────────────────────────────────

TOOL_TO_MCP: dict[str, str] = {
    # Airflow
    "trigger_dag_run": "airflow", "wait_for_dag_run": "airflow",
    "get_task_logs": "airflow", "get_all_task_logs": "airflow",
    "search_task_logs": "airflow", "list_dags": "airflow",
    "get_dag_run": "airflow", "list_dag_runs": "airflow",
    "list_task_instances": "airflow", "get_task_instance": "airflow",
    "get_dag_stats": "airflow", "pause_dag": "airflow", "unpause_dag": "airflow",
    "delete_dag": "airflow", "delete_dag_run": "airflow", "clear_dag_run": "airflow",
    "clear_task_instance": "airflow", "set_task_instance_state": "airflow",
    "get_variable": "airflow", "set_variable": "airflow",
    "list_variables": "airflow", "delete_variable": "airflow",
    "get_xcom_value": "airflow", "list_xcom_entries": "airflow",
    "list_connections": "airflow", "get_connection": "airflow",
    "list_pools": "airflow", "get_pool": "airflow",
    "get_health": "airflow", "get_version": "airflow",
    # SQL Server
    "run_query": "ssms", "run_query_paginated": "ssms",
    "assert_row_count": "ssms", "assert_value_exists": "ssms",
    "assert_column_value": "ssms", "assert_query_returns_rows": "ssms",
    "assert_no_rows": "ssms", "assert_column_not_null": "ssms",
    "run_assertion_suite": "ssms", "export_to_excel": "ssms",
    "export_multiple_queries_to_excel": "ssms", "get_row_count": "ssms",
    "get_table_sample": "ssms", "list_tables": "ssms", "list_views": "ssms",
    "list_columns": "ssms", "get_table_schema": "ssms", "get_table_ddl": "ssms",
    "list_stored_procedures": "ssms", "list_indexes": "ssms",
    "list_foreign_keys": "ssms", "list_databases": "ssms",
    "run_stored_procedure": "ssms", "run_raw_sql": "ssms",
    "get_distinct_values": "ssms", "search_column_for_value": "ssms",
    "insert_rows": "ssms", "update_rows": "ssms", "delete_rows": "ssms",
    "get_server_info": "ssms", "list_jobs": "ssms", "test_connection": "ssms",
    # AWS S3
    "assert_prefix_has_files": "s3", "assert_file_exists": "s3",
    "assert_file_not_exists": "s3", "assert_file_newer_than": "s3",
    "check_file_exists": "s3", "list_objects": "s3", "list_common_prefixes": "s3",
    "search_objects": "s3", "get_object_content": "s3", "get_object_metadata": "s3",
    "get_object_head": "s3", "find_recent_objects": "s3",
    "find_objects_by_extension": "s3", "get_presigned_url": "s3",
    "list_object_versions": "s3", "upload_text_content": "s3",
    "upload_local_file": "s3", "copy_object": "s3", "move_object": "s3",
    "delete_object": "s3", "delete_objects_by_prefix": "s3",
    "download_file": "s3", "download_folder": "s3",
    "list_buckets": "s3", "get_bucket_info": "s3", "get_bucket_location": "s3",
    "get_bucket_policy_summary": "s3", "get_bucket_size": "s3",
    "count_objects_by_prefix": "s3", "compare_prefixes": "s3",
    # Python executor
    "execute_python": "python", "execute_python_with_data": "python",
    "analyze_dataframe": "python", "filter_dataframe": "python",
    "aggregate_dataframe": "python", "pivot_dataframe": "python",
    "compare_dataframes": "python", "profile_dataframe": "python",
    "parse_airflow_logs": "python", "extract_log_metrics": "python",
    "extract_log_counts": "python", "search_logs_for_pattern": "python",
    "dataframe_to_excel": "python", "dataframe_to_csv": "python",
    "dataframe_to_json": "python", "generate_analysis_code": "python",
    "generate_transformation_code": "python", "validate_json": "python",
    "format_sql": "python", "parse_csv_content": "python",
    "calculate_statistics": "python", "run_assertions_on_data": "python",
    # HTTP
    "http_get": "http", "http_post": "http", "http_put": "http",
    "http_patch": "http", "http_delete": "http",
    "http_get_json": "http", "http_post_json": "http",
    "http_get_with_auth": "http", "http_post_with_auth": "http",
    "http_poll_until": "http", "http_assert_status": "http",
    # SFTP
    "sftp_test_connection": "sftp", "sftp_list_dir": "sftp",
    "sftp_find_files": "sftp", "sftp_get_file_info": "sftp",
    "sftp_upload_file": "sftp", "sftp_upload_text": "sftp",
    "sftp_download_file": "sftp", "sftp_read_file": "sftp",
    "sftp_mkdir": "sftp", "sftp_delete_file": "sftp",
    "sftp_rename": "sftp", "sftp_copy_file": "sftp",
    "sftp_assert_file_exists": "sftp", "sftp_assert_dir_has_files": "sftp",
    "sftp_run_command": "sftp",
    # Browser (Playwright)
    "browser_new_session": "browser", "browser_close_session": "browser",
    "browser_list_sessions": "browser", "browser_navigate": "browser",
    "browser_go_back": "browser", "browser_go_forward": "browser",
    "browser_refresh": "browser", "browser_get_text": "browser",
    "browser_get_page_source": "browser", "browser_get_current_url": "browser",
    "browser_find_elements": "browser", "browser_extract_table": "browser",
    "browser_screenshot": "browser", "browser_click": "browser",
    "browser_type": "browser", "browser_fill_form": "browser",
    "browser_select_option": "browser", "browser_scroll": "browser",
    "browser_wait_for_element": "browser", "browser_wait_for_navigation": "browser",
    "browser_execute_script": "browser", "browser_assert_text_present": "browser",
    "browser_assert_url": "browser",
}


# ─── MCP JSON-RPC client ──────────────────────────────────────────────────────

class MCPClient:
    MCP_PROTOCOL_VERSION = "2024-11-05"

    def __init__(self, name: str, proc: subprocess.Popen) -> None:
        self.name = name
        self.proc = proc
        self._lock = asyncio.Lock()
        self._next_id = 0
        self._initialized = False

    async def initialize(self) -> None:
        if self._initialized:
            return
        req = self._build_request("initialize", {
            "protocolVersion": self.MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "workflow-studio", "version": "2.0.0"},
        })
        await self._send_and_receive(req)
        await self._write_line({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
        self._initialized = True

    async def call_tool(self, tool_name: str, arguments: dict) -> str:
        await self.initialize()
        req = self._build_request("tools/call", {"name": tool_name, "arguments": arguments})
        response = await self._send_and_receive(req)
        if "error" in response:
            err = response["error"]
            raise RuntimeError(f"MCP {self.name} error {err.get('code')}: {err.get('message')}")
        result = response.get("result", {})
        if result.get("isError"):
            texts = [c.get("text", "") for c in result.get("content", []) if c.get("type") == "text"]
            raise RuntimeError("\n".join(texts) or "MCP tool error")
        texts = [c.get("text", "") for c in result.get("content", []) if c.get("type") == "text"]
        return "\n".join(texts) if texts else json.dumps(result, indent=2)

    def is_alive(self) -> bool:
        return self.proc.poll() is None

    def _build_request(self, method: str, params: dict) -> dict:
        self._next_id += 1
        return {"jsonrpc": "2.0", "id": self._next_id, "method": method, "params": params}

    async def _write_line(self, msg: dict) -> None:
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._sync_write, (json.dumps(msg) + "\n").encode())

    def _sync_write(self, data: bytes) -> None:
        self.proc.stdin.write(data)
        self.proc.stdin.flush()

    async def _send_and_receive(self, req: dict) -> dict:
        async with self._lock:
            await self._write_line(req)
            loop = asyncio.get_event_loop()
            raw = await loop.run_in_executor(None, self.proc.stdout.readline)
            if not raw:
                raise RuntimeError(f"MCP '{self.name}' closed stdout unexpectedly")
            return json.loads(raw.decode())


MCP_PROCESSES: dict[str, subprocess.Popen] = {}
MCP_CLIENTS:   dict[str, MCPClient]        = {}


def _start_mcp(name: str, module: str) -> subprocess.Popen:
    return subprocess.Popen(
        ["python", "-m", module],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=os.path.dirname(__file__),
    )


@app.on_event("startup")
async def startup() -> None:
    servers = {
        "airflow": "mcp_servers.airflow_mcp.server",
        "ssms":    "mcp_servers.ssms_mcp.server",
        "s3":      "mcp_servers.s3_mcp.server",
        "python":  "mcp_servers.python_executor_mcp.server",
        "http":    "mcp_servers.http_mcp.server",
        "sftp":    "mcp_servers.sftp_mcp.server",
        "browser": "mcp_servers.browser_mcp.server",
    }
    for name, module in servers.items():
        try:
            proc = _start_mcp(name, module)
            MCP_PROCESSES[name] = proc
            client = MCPClient(name, proc)
            await client.initialize()
            MCP_CLIENTS[name] = client
            print(f"✅ MCP ready: {name} (pid={proc.pid})")
        except Exception as exc:
            print(f"⚠️  MCP failed: {name} — {exc}")

    try:
        _token_fetcher.get_token()
        print(f"✅ Gen AI Gateway OAuth OK  (model: {LLM_MODEL}  gateway: {GW_BASE_URL})")
    except Exception as exc:
        print(f"⚠️  OAuth token fetch failed: {exc}")


@app.on_event("shutdown")
async def shutdown() -> None:
    for name, proc in MCP_PROCESSES.items():
        proc.terminate()
        print(f"Stopped MCP: {name}")


# ─── Proxy endpoint ───────────────────────────────────────────────────────────

class MessagesRequest(BaseModel):
    model:      str               = LLM_MODEL
    max_tokens: int               = 4000
    system:     str | None        = None
    tools:      list[dict] | None = None
    messages:   list[dict]


@app.post("/v1/messages")
async def proxy_messages(req: MessagesRequest) -> dict:
    """
    Accept an Anthropic-format request → call Gen AI Gateway → return Anthropic-format response.
    Also routes tool calls to real MCP servers.
    """
    oai_messages = _to_oai_messages(req.messages, req.system)
    oai_tools    = _to_oai_tools(req.tools) if req.tools else None

    kwargs: dict[str, Any] = {
        "model":      LLM_MODEL,
        "max_tokens": req.max_tokens,
        "messages":   oai_messages,
    }
    if oai_tools:
        kwargs["tools"]       = oai_tools
        kwargs["tool_choice"] = "auto"

    try:
        oai_response = _get_openai_client().chat.completions.create(**kwargs)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gateway error: {exc}")

    response = _to_anthropic_response(oai_response)

    # Route tool_use blocks to real MCP servers
    tool_results: list[dict] = []
    for block in response["content"]:
        if block["type"] == "tool_use":
            result_text = await _call_mcp_tool(block["name"], block["input"])
            tool_results.append({
                "type":        "tool_result",
                "tool_use_id": block["id"],
                "content":     result_text,
            })
    if tool_results:
        response["tool_results"] = tool_results

    return response


async def _call_mcp_tool(tool_name: str, tool_input: dict) -> str:
    mcp_name = TOOL_TO_MCP.get(tool_name)
    if not mcp_name:
        return f"❌ No MCP server for tool '{tool_name}'."
    client = MCP_CLIENTS.get(mcp_name)
    if not client:
        return f"❌ MCP '{mcp_name}' did not start."
    if not client.is_alive():
        return f"❌ MCP '{mcp_name}' has exited."
    try:
        return await client.call_tool(tool_name, tool_input)
    except Exception as exc:
        return f"❌ {tool_name} via {mcp_name}: {exc}"


# ─── Health ───────────────────────────────────────────────────────────────────

@app.get("/health")
async def health() -> dict:
    oauth_ok = False
    try:
        _token_fetcher.get_token()
        oauth_ok = True
    except Exception:
        pass
    return {
        "status":    "ok",
        "llm_model": LLM_MODEL,
        "gateway":   GW_BASE_URL,
        "oauth_ok":  oauth_ok,
        "mcps": {
            name: {"running": c.is_alive(), "initialized": c._initialized, "pid": MCP_PROCESSES[name].pid}
            for name, c in MCP_CLIENTS.items()
        },
        "config": {"airflow_url": AIRFLOW_BASE_URL, "ssms_server": SSMS_SERVER,
                   "aws_region": AWS_REGION, "allowed_origins": ALLOWED_ORIGINS},
    }


@app.get("/mcps")
async def list_mcps() -> dict:
    return {
        name: {"running": c.is_alive(), "initialized": c._initialized, "pid": MCP_PROCESSES[name].pid}
        for name, c in MCP_CLIENTS.items()
    }
