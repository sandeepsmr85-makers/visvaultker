"""
config/settings.py
──────────────────
Centralized config loader for the MCP suite.
All servers import from here so env vars are handled in one place.
"""

import json
import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env from project root (works regardless of which server runs)
_root = Path(__file__).resolve().parent.parent
load_dotenv(_root / ".env", override=False)
load_dotenv(_root / ".env.example", override=False)

# ─── Gen AI Gateway (OpenAI-compatible) ─────────────────────────────────────
OAUTH_TOKEN_URL    = os.getenv("OAUTH_TOKEN_URL", "")
OAUTH_CLIENT_ID    = os.getenv("OAUTH_CLIENT_ID", "")
OAUTH_CLIENT_SECRET= os.getenv("OAUTH_CLIENT_SECRET", "")
OAUTH_GRANT_TYPE   = os.getenv("OAUTH_GRANT_TYPE", "client_credentials")
OAUTH_SCOPE        = os.getenv("OAUTH_SCOPE", "")
GW_BASE_URL        = os.getenv("GW_BASE_URL", "")
LLM_MODEL          = os.getenv("LLM_MODEL", "gpt-3.5-turbo")

# ─── Airflow ────────────────────────────────────────────────────────────────
AIRFLOW_BASE_URL    = os.getenv("AIRFLOW_BASE_URL", "http://localhost:8080")
AIRFLOW_USERNAME    = os.getenv("AIRFLOW_USERNAME", "admin")
AIRFLOW_PASSWORD    = os.getenv("AIRFLOW_PASSWORD", "admin")
AIRFLOW_API_VERSION = os.getenv("AIRFLOW_API_VERSION", "v1")
AIRFLOW_AUTH_TOKEN  = os.getenv("AIRFLOW_AUTH_TOKEN", "")

# ─── SQL Server ─────────────────────────────────────────────────────────────
SSMS_SERVER          = os.getenv("SSMS_SERVER", "localhost")
SSMS_PORT            = int(os.getenv("SSMS_PORT", "1433"))
SSMS_USERNAME        = os.getenv("SSMS_USERNAME", "sa")
SSMS_PASSWORD        = os.getenv("SSMS_PASSWORD", "")
SSMS_DEFAULT_DB      = os.getenv("SSMS_DEFAULT_DATABASE", "master")
SSMS_DRIVER          = os.getenv("SSMS_DRIVER", "ODBC Driver 17 for SQL Server")
SSMS_USE_WINDOWS_AUTH = os.getenv("SSMS_USE_WINDOWS_AUTH", "false").lower() == "true"
SSMS_EXPORT_DIR      = Path(os.getenv("SSMS_EXPORT_DIR", "./exports"))

# ─── AWS S3 ─────────────────────────────────────────────────────────────────
AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID", "")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "")
AWS_SESSION_TOKEN     = os.getenv("AWS_SESSION_TOKEN", "")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")
AWS_S3_ENDPOINT_URL   = os.getenv("AWS_S3_ENDPOINT_URL", "") or None
S3_DOWNLOAD_DIR       = Path(os.getenv("S3_DOWNLOAD_DIR", "./downloads"))

# ─── Python Executor ────────────────────────────────────────────────────────
PYTHON_EXEC_TIMEOUT      = int(os.getenv("PYTHON_EXEC_TIMEOUT", "60"))
PYTHON_EXEC_MAX_LINES    = int(os.getenv("PYTHON_EXEC_MAX_OUTPUT_LINES", "500"))
PYTHON_EXEC_OUTPUT_DIR   = Path(os.getenv("PYTHON_EXEC_OUTPUT_DIR", "./py_outputs"))
PYTHON_EXEC_ALLOWED_IMPORTS = set(
    os.getenv(
        "PYTHON_EXEC_ALLOWED_IMPORTS",
        "pandas,numpy,json,csv,re,datetime,collections,math,statistics,openpyxl,io,os,pathlib"
    ).split(",")
)

# ─── General ────────────────────────────────────────────────────────────────
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE  = Path(os.getenv("LOG_FILE", "./logs/mcp_suite.log"))

# ─── SFTP (paramiko) ────────────────────────────────────────────────────────
SFTP_HOST                  = os.getenv("SFTP_HOST", "localhost")
SFTP_PORT                  = int(os.getenv("SFTP_PORT", "22"))
SFTP_USERNAME              = os.getenv("SFTP_USERNAME", "")
SFTP_PASSWORD              = os.getenv("SFTP_PASSWORD", "")
SFTP_PRIVATE_KEY_PATH      = os.getenv("SFTP_PRIVATE_KEY_PATH", "")
SFTP_PRIVATE_KEY_PASSPHRASE= os.getenv("SFTP_PRIVATE_KEY_PASSPHRASE", "")
SFTP_DEFAULT_REMOTE_DIR    = os.getenv("SFTP_DEFAULT_REMOTE_DIR", "")
SFTP_DEFAULT_LOCAL_DIR     = os.getenv("SFTP_DEFAULT_LOCAL_DIR", "./sftp_downloads")
SFTP_KNOWN_HOSTS_PATH      = os.getenv("SFTP_KNOWN_HOSTS_PATH", "~/.ssh/known_hosts")
SFTP_AUTO_ADD_HOST_KEY     = os.getenv("SFTP_AUTO_ADD_HOST_KEY", "false").lower() == "true"
SFTP_CONNECTION_TIMEOUT    = int(os.getenv("SFTP_CONNECTION_TIMEOUT", "15"))

# ─── HTTP Request MCP ───────────────────────────────────────────────────────
HTTP_DEFAULT_TIMEOUT    = int(os.getenv("HTTP_DEFAULT_TIMEOUT", "30"))
HTTP_MAX_RESPONSE_BYTES = int(os.getenv("HTTP_MAX_RESPONSE_BYTES", "102400"))
_raw_http_hosts         = os.getenv("HTTP_ALLOWED_HOSTS", "")
HTTP_ALLOWED_HOSTS: set[str] = {h.strip() for h in _raw_http_hosts.split(",") if h.strip()}
try:
    HTTP_DEFAULT_HEADERS: dict = json.loads(os.getenv("HTTP_DEFAULT_HEADERS", "{}"))
except Exception:
    HTTP_DEFAULT_HEADERS = {}

# ─── Browser (Playwright) ────────────────────────────────────────────────────
BROWSER_HEADLESS:         bool  = os.getenv("BROWSER_HEADLESS", "true").lower() == "true"
BROWSER_TIMEOUT_MS:       int   = int(os.getenv("BROWSER_TIMEOUT_MS", "10000"))
BROWSER_SCREENSHOT_DIR:   Path  = Path(os.getenv("BROWSER_SCREENSHOT_DIR", "./browser_shots"))
BROWSER_DEFAULT_TYPE:     str   = os.getenv("BROWSER_DEFAULT_TYPE", "chromium")
BROWSER_SLOW_MO_MS:       int   = int(os.getenv("BROWSER_SLOW_MO_MS", "0"))

# ─── CORS ───────────────────────────────────────────────────────────────────
# Comma-separated list of allowed origins for the FastAPI proxy.
# In production, set this to your frontend's actual domain, e.g.:
#   ALLOWED_ORIGINS=https://app.yourcompany.com
_raw_origins = os.getenv(
    "ALLOWED_ORIGINS",
    "http://localhost:3000,http://localhost:5173,http://localhost:8080"
)
ALLOWED_ORIGINS: list[str] = [o.strip() for o in _raw_origins.split(",") if o.strip()]

# Ensure output dirs exist
for _dir in [SSMS_EXPORT_DIR, S3_DOWNLOAD_DIR, PYTHON_EXEC_OUTPUT_DIR, LOG_FILE.parent, BROWSER_SCREENSHOT_DIR]:
    _dir.mkdir(parents=True, exist_ok=True)
