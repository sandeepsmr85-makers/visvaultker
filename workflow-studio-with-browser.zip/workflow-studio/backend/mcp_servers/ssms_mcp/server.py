"""
mcp_servers/ssms_mcp/server.py
────────────────────────────────
Microsoft SQL Server MCP Server (compatible with SSMS)

Tools exposed:
  Schema Discovery : list_databases, list_tables, list_views, list_columns,
                     get_table_schema, list_stored_procedures, list_indexes,
                     list_foreign_keys, get_table_ddl
  Query Execution  : run_query, run_query_paginated, run_stored_procedure,
                     run_raw_sql
  Assertions       : assert_row_count, assert_value_exists, assert_column_value,
                     assert_query_returns_rows, assert_no_rows, assert_column_not_null
  Data Ops         : get_row_count, get_table_sample, get_distinct_values,
                     search_column_for_value
  Export           : export_to_excel, export_multiple_queries_to_excel
  DML (optional)   : insert_rows, update_rows, delete_rows (disabled by default)
  Meta             : get_server_info, list_jobs, test_connection
"""

import asyncio
import json
import re
import os
import sys
from datetime import datetime, date
from pathlib import Path
from typing import Any

import pyodbc
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from config.settings import (
    SSMS_SERVER, SSMS_PORT, SSMS_USERNAME, SSMS_PASSWORD,
    SSMS_DEFAULT_DB, SSMS_DRIVER, SSMS_USE_WINDOWS_AUTH, SSMS_EXPORT_DIR
)

# ─── Connection helper ────────────────────────────────────────────────────────

def _conn_str(database: str | None = None) -> str:
    db = database or SSMS_DEFAULT_DB
    if SSMS_USE_WINDOWS_AUTH:
        return (f"DRIVER={{{SSMS_DRIVER}}};"
                f"SERVER={SSMS_SERVER},{SSMS_PORT};"
                f"DATABASE={db};"
                f"Trusted_Connection=yes;")
    return (f"DRIVER={{{SSMS_DRIVER}}};"
            f"SERVER={SSMS_SERVER},{SSMS_PORT};"
            f"DATABASE={db};"
            f"UID={SSMS_USERNAME};"
            f"PWD={SSMS_PASSWORD};")

def _get_conn(database: str | None = None):
    return pyodbc.connect(_conn_str(database), autocommit=False, timeout=30)

def _serialize(val: Any) -> Any:
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, bytes):
        return val.hex()
    return val

def _rows_to_dicts(cursor) -> list[dict]:
    if cursor.description is None:
        return []
    cols = [d[0] for d in cursor.description]
    return [{c: _serialize(v) for c, v in zip(cols, row)} for row in cursor.fetchall()]

def _fmt(obj: Any) -> str:
    return json.dumps(obj, indent=2, default=str)

def _run_select(sql: str, database: str | None = None, params: list | None = None) -> tuple[list[dict], list[str]]:
    with _get_conn(database) as conn:
        cursor = conn.cursor()
        cursor.execute(sql, params or [])
        if cursor.description is None:
            return [], []
        cols = [d[0] for d in cursor.description]
        rows = [{c: _serialize(v) for c, v in zip(cols, row)} for row in cursor.fetchall()]
        return rows, cols


# ─── Excel export helper ──────────────────────────────────────────────────────

def _export_df_to_excel(df: pd.DataFrame, sheet_name: str,
                        filepath: Path, title: str = "") -> Path:
    SSMS_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet_name[:31]

    header_fill = PatternFill("solid", fgColor="2E75B6")
    header_font = Font(bold=True, color="FFFFFF", size=11)

    if title:
        ws.append([title])
        ws["A1"].font = Font(bold=True, size=13)
        ws.append([f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
        ws.append([f"Row count: {len(df)}"])
        ws.append([])
        start_row = 5
    else:
        start_row = 1

    # Headers
    for col_idx, col_name in enumerate(df.columns, 1):
        cell = ws.cell(row=start_row, column=col_idx, value=col_name)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    # Data
    for row_idx, row in enumerate(df.itertuples(index=False), start_row + 1):
        for col_idx, val in enumerate(row, 1):
            ws.cell(row=row_idx, column=col_idx, value=val)

    # Auto-width
    for col_idx, col_name in enumerate(df.columns, 1):
        col_letter = get_column_letter(col_idx)
        max_len = max(len(str(col_name)),
                      *[len(str(v)) for v in df.iloc[:, col_idx-1].values[:100]],
                      10)
        ws.column_dimensions[col_letter].width = min(max_len + 2, 50)

    wb.save(filepath)
    return filepath


# ─── MCP Server ──────────────────────────────────────────────────────────────

server = Server("ssms-mcp")

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [

        # ── Meta ───────────────────────────────────────────────────────────
        Tool(name="test_connection",
             description="Test connectivity to SQL Server. Returns server info.",
             inputSchema={"type":"object","properties":{
                 "database":{"type":"string","description":"Database to connect to (defaults to configured default)"}
             }}),

        Tool(name="get_server_info",
             description="Get SQL Server version, edition, hostname, and uptime.",
             inputSchema={"type":"object","properties":{}}),

        # ── Schema Discovery ───────────────────────────────────────────────
        Tool(name="list_databases",
             description="List all databases on the SQL Server instance.",
             inputSchema={"type":"object","properties":{
                 "exclude_system":{"type":"boolean","default":True}
             }}),

        Tool(name="list_tables",
             description="List all tables in a database/schema.",
             inputSchema={"type":"object","properties":{
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "table_type":{"type":"string","enum":["BASE TABLE","VIEW","ALL"],"default":"BASE TABLE"},
                 "name_filter":{"type":"string","description":"Substring filter on table name"}
             }}),

        Tool(name="list_views",
             description="List all views in a database.",
             inputSchema={"type":"object","properties":{
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"}
             }}),

        Tool(name="list_columns",
             description="List all columns for a table including data type, nullability, defaults.",
             inputSchema={"type":"object","required":["table_name"],"properties":{
                 "table_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"}
             }}),

        Tool(name="get_table_schema",
             description="Full schema of a table: columns, PKs, FKs, indexes, and constraints.",
             inputSchema={"type":"object","required":["table_name"],"properties":{
                 "table_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"}
             }}),

        Tool(name="get_table_ddl",
             description="Generate approximate CREATE TABLE DDL script for a table.",
             inputSchema={"type":"object","required":["table_name"],"properties":{
                 "table_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"}
             }}),

        Tool(name="list_stored_procedures",
             description="List all stored procedures with their parameters.",
             inputSchema={"type":"object","properties":{
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "name_filter":{"type":"string"}
             }}),

        Tool(name="list_indexes",
             description="List all indexes on a table.",
             inputSchema={"type":"object","required":["table_name"],"properties":{
                 "table_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"}
             }}),

        Tool(name="list_foreign_keys",
             description="List all foreign key relationships for a table.",
             inputSchema={"type":"object","required":["table_name"],"properties":{
                 "table_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"}
             }}),

        # ── Query Execution ────────────────────────────────────────────────
        Tool(name="run_query",
             description="Execute a SELECT query and return results as JSON. "
                         "Use for data retrieval, aggregations, joins, anything read-only.",
             inputSchema={"type":"object","required":["sql"],"properties":{
                 "sql":{"type":"string","description":"SQL SELECT statement"},
                 "database":{"type":"string"},
                 "max_rows":{"type":"integer","default":1000,"description":"Cap returned rows"},
                 "include_row_count":{"type":"boolean","default":True}
             }}),

        Tool(name="run_query_paginated",
             description="Execute a query with pagination (OFFSET/FETCH). "
                         "Good for large tables without overwhelming output.",
             inputSchema={"type":"object","required":["sql"],"properties":{
                 "sql":{"type":"string","description":"Base SELECT without ORDER/OFFSET (will be added)"},
                 "database":{"type":"string"},
                 "page":{"type":"integer","default":1},
                 "page_size":{"type":"integer","default":50},
                 "order_by":{"type":"string","description":"Column to order by (required for pagination)"}
             }}),

        Tool(name="run_stored_procedure",
             description="Execute a stored procedure with named parameters.",
             inputSchema={"type":"object","required":["procedure_name"],"properties":{
                 "procedure_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "parameters":{"type":"object","description":"Key-value parameter dict","default":{}}
             }}),

        Tool(name="run_raw_sql",
             description="Execute any SQL statement (INSERT/UPDATE/DELETE/DDL). "
                         "Returns rows affected. USE WITH CAUTION.",
             inputSchema={"type":"object","required":["sql"],"properties":{
                 "sql":{"type":"string"},
                 "database":{"type":"string"},
                 "confirm":{"type":"boolean","default":False,
                            "description":"Must be true to execute non-SELECT statements"}
             }}),

        # ── Data Exploration ───────────────────────────────────────────────
        Tool(name="get_row_count",
             description="Get the total row count of a table (fast, uses sys.partitions).",
             inputSchema={"type":"object","required":["table_name"],"properties":{
                 "table_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "where_clause":{"type":"string","description":"Optional WHERE condition (without 'WHERE')"}
             }}),

        Tool(name="get_table_sample",
             description="Get a sample of rows from a table (TOP N or TABLESAMPLE).",
             inputSchema={"type":"object","required":["table_name"],"properties":{
                 "table_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "sample_size":{"type":"integer","default":10},
                 "order_by":{"type":"string","description":"Column to sort by"},
                 "where_clause":{"type":"string","description":"Optional WHERE filter"}
             }}),

        Tool(name="get_distinct_values",
             description="Get distinct values and their counts for a column.",
             inputSchema={"type":"object","required":["table_name","column_name"],"properties":{
                 "table_name":{"type":"string"},
                 "column_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "limit":{"type":"integer","default":100},
                 "where_clause":{"type":"string"}
             }}),

        Tool(name="search_column_for_value",
             description="Search for a value across all columns in a table (or a specific column). "
                         "Useful when you don't know which column holds a value.",
             inputSchema={"type":"object","required":["table_name","search_value"],"properties":{
                 "table_name":{"type":"string"},
                 "search_value":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "column_name":{"type":"string","description":"Restrict to this column"},
                 "exact_match":{"type":"boolean","default":False}
             }}),

        # ── Assertions ─────────────────────────────────────────────────────
        Tool(name="assert_row_count",
             description="Assert the row count of a query or table meets a condition. "
                         "Returns PASS/FAIL with actual count.",
             inputSchema={"type":"object","required":["sql_or_table","operator","expected_value"],"properties":{
                 "sql_or_table":{"type":"string","description":"Full SELECT COUNT SQL or just a table name"},
                 "operator":{"type":"string","enum":["==","!=",">","<",">=","<="]},
                 "expected_value":{"type":"integer"},
                 "database":{"type":"string"},
                 "where_clause":{"type":"string","description":"If sql_or_table is a table name, add filter here"}
             }}),

        Tool(name="assert_value_exists",
             description="Assert that a specific value exists somewhere in a column.",
             inputSchema={"type":"object","required":["table_name","column_name","expected_value"],"properties":{
                 "table_name":{"type":"string"},
                 "column_name":{"type":"string"},
                 "expected_value":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "where_clause":{"type":"string"}
             }}),

        Tool(name="assert_column_value",
             description="Assert that a query returns exactly one row and the specified column equals expected_value.",
             inputSchema={"type":"object","required":["sql","column_name","expected_value"],"properties":{
                 "sql":{"type":"string"},
                 "column_name":{"type":"string"},
                 "expected_value":{"type":"string"},
                 "database":{"type":"string"},
                 "comparison":{"type":"string","enum":["==","!=","contains","startswith","endswith"],"default":"=="}
             }}),

        Tool(name="assert_query_returns_rows",
             description="Assert that a query returns AT LEAST one row (existence check).",
             inputSchema={"type":"object","required":["sql"],"properties":{
                 "sql":{"type":"string"},
                 "database":{"type":"string"},
                 "description":{"type":"string","description":"Human-readable name for this assertion"}
             }}),

        Tool(name="assert_no_rows",
             description="Assert that a query returns ZERO rows (absence check / negative assertion).",
             inputSchema={"type":"object","required":["sql"],"properties":{
                 "sql":{"type":"string"},
                 "database":{"type":"string"},
                 "description":{"type":"string"}
             }}),

        Tool(name="assert_column_not_null",
             description="Assert that a column has no NULL values in a table (or filtered set).",
             inputSchema={"type":"object","required":["table_name","column_name"],"properties":{
                 "table_name":{"type":"string"},
                 "column_name":{"type":"string"},
                 "database":{"type":"string"},
                 "schema":{"type":"string","default":"dbo"},
                 "where_clause":{"type":"string"}
             }}),

        Tool(name="run_assertion_suite",
             description="Run multiple assertions at once and get a summary report. "
                         "Each assertion is: {name, sql, check_type, expected}",
             inputSchema={"type":"object","required":["assertions"],"properties":{
                 "database":{"type":"string"},
                 "assertions":{"type":"array","items":{
                     "type":"object","required":["name","sql","check_type"],"properties":{
                         "name":{"type":"string"},
                         "sql":{"type":"string"},
                         "check_type":{"type":"string","enum":["has_rows","no_rows","row_count_eq",
                                                                "row_count_gt","value_eq"]},
                         "expected":{"type":"string","description":"Required for row_count_eq/gt and value_eq"}
                     }
                 }}
             }}),

        # ── Export ─────────────────────────────────────────────────────────
        Tool(name="export_to_excel",
             description="Run a query and export results to an Excel (.xlsx) file.",
             inputSchema={"type":"object","required":["sql","filename"],"properties":{
                 "sql":{"type":"string"},
                 "filename":{"type":"string","description":"Output file name (no path, .xlsx added if missing)"},
                 "database":{"type":"string"},
                 "sheet_name":{"type":"string","default":"Query Results"},
                 "title":{"type":"string","description":"Optional title row in the Excel file"}
             }}),

        Tool(name="export_multiple_queries_to_excel",
             description="Export multiple queries to separate sheets of one Excel workbook.",
             inputSchema={"type":"object","required":["queries","filename"],"properties":{
                 "filename":{"type":"string"},
                 "database":{"type":"string"},
                 "queries":{"type":"array","items":{
                     "type":"object","required":["sql","sheet_name"],"properties":{
                         "sql":{"type":"string"},
                         "sheet_name":{"type":"string"},
                         "title":{"type":"string"}
                     }
                 }}
             }}),

        # ── Jobs (SQL Agent) ───────────────────────────────────────────────
        Tool(name="list_jobs",
             description="List all SQL Server Agent jobs and their last run status.",
             inputSchema={"type":"object","properties":{
                 "name_filter":{"type":"string"}
             }}),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await _dispatch(name, arguments)
        return [TextContent(type="text", text=result)]
    except pyodbc.Error as e:
        return [TextContent(type="text", text=f"SQL Server Error: {e}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]


async def _dispatch(name: str, a: dict) -> str:
    db = a.get("database") or None
    schema = a.get("schema", "dbo")

    # ── Meta ──────────────────────────────────────────────────────────────────
    if name == "test_connection":
        rows, _ = _run_select(
            "SELECT @@SERVERNAME AS server_name, @@VERSION AS version, DB_NAME() AS current_db",
            db
        )
        return f"✅ Connection successful!\n{_fmt(rows[0] if rows else {})}"

    if name == "get_server_info":
        rows, _ = _run_select("""
            SELECT
                @@SERVERNAME AS server_name,
                SERVERPROPERTY('Edition') AS edition,
                SERVERPROPERTY('ProductVersion') AS version,
                SERVERPROPERTY('ProductLevel') AS service_pack,
                SERVERPROPERTY('IsHadrEnabled') AS hadr_enabled,
                @@CPU_BUSY AS cpu_busy,
                (SELECT sqlserver_start_time FROM sys.dm_os_sys_info) AS start_time
        """, db)
        return f"Server Info:\n{_fmt(rows[0] if rows else {})}"

    # ── Schema Discovery ──────────────────────────────────────────────────────
    if name == "list_databases":
        sql = "SELECT name, state_desc, recovery_model_desc, create_date FROM sys.databases"
        if a.get("exclude_system", True):
            sql += " WHERE database_id > 4"
        sql += " ORDER BY name"
        rows, _ = _run_select(sql)
        return f"{len(rows)} databases:\n{_fmt(rows)}"

    if name == "list_tables":
        cond = f"TABLE_SCHEMA = '{schema}'"
        if a.get("table_type", "BASE TABLE") != "ALL":
            cond += f" AND TABLE_TYPE = '{a.get('table_type','BASE TABLE')}'"
        if a.get("name_filter"):
            cond += f" AND TABLE_NAME LIKE '%{a['name_filter']}%'"
        sql = (f"SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE "
               f"FROM INFORMATION_SCHEMA.TABLES WHERE {cond} ORDER BY TABLE_NAME")
        rows, _ = _run_select(sql, db)
        return f"{len(rows)} tables in [{db or SSMS_DEFAULT_DB}].[{schema}]:\n{_fmt(rows)}"

    if name == "list_views":
        rows, _ = _run_select(
            f"SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS "
            f"WHERE TABLE_SCHEMA='{schema}' ORDER BY TABLE_NAME", db)
        return f"{len(rows)} views:\n{_fmt(rows)}"

    if name == "list_columns":
        rows, _ = _run_select(f"""
            SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
                   NUMERIC_PRECISION, NUMERIC_SCALE,
                   IS_NULLABLE, COLUMN_DEFAULT, ORDINAL_POSITION
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME='{a['table_name']}' AND TABLE_SCHEMA='{schema}'
            ORDER BY ORDINAL_POSITION
        """, db)
        return f"{len(rows)} columns in [{schema}].[{a['table_name']}]:\n{_fmt(rows)}"

    if name == "get_table_schema":
        tbl = a["table_name"]
        cols, _ = _run_select(f"""
            SELECT c.COLUMN_NAME, c.DATA_TYPE, c.CHARACTER_MAXIMUM_LENGTH,
                   c.NUMERIC_PRECISION, c.IS_NULLABLE, c.COLUMN_DEFAULT,
                   CASE WHEN pk.COLUMN_NAME IS NOT NULL THEN 'YES' ELSE 'NO' END AS IS_PK
            FROM INFORMATION_SCHEMA.COLUMNS c
            LEFT JOIN (
                SELECT ku.COLUMN_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
                JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE ku
                  ON tc.CONSTRAINT_NAME=ku.CONSTRAINT_NAME AND tc.TABLE_NAME=ku.TABLE_NAME
                WHERE tc.CONSTRAINT_TYPE='PRIMARY KEY' AND tc.TABLE_NAME='{tbl}'
            ) pk ON c.COLUMN_NAME=pk.COLUMN_NAME
            WHERE c.TABLE_NAME='{tbl}' AND c.TABLE_SCHEMA='{schema}'
            ORDER BY c.ORDINAL_POSITION
        """, db)
        idxs, _ = _run_select(f"""
            SELECT i.name AS index_name, i.type_desc, i.is_unique, i.is_primary_key,
                   STRING_AGG(c.name, ', ') WITHIN GROUP (ORDER BY ic.key_ordinal) AS columns
            FROM sys.indexes i
            JOIN sys.index_columns ic ON i.object_id=ic.object_id AND i.index_id=ic.index_id
            JOIN sys.columns c ON ic.object_id=c.object_id AND ic.column_id=c.column_id
            WHERE OBJECT_NAME(i.object_id)='{tbl}'
            GROUP BY i.name, i.type_desc, i.is_unique, i.is_primary_key
        """, db)
        return f"Schema for [{schema}].[{tbl}]:\n\nCOLUMNS:\n{_fmt(cols)}\n\nINDEXES:\n{_fmt(idxs)}"

    if name == "get_table_ddl":
        tbl = a["table_name"]
        cols, _ = _run_select(f"""
            SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
                   NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE, COLUMN_DEFAULT
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME='{tbl}' AND TABLE_SCHEMA='{schema}'
            ORDER BY ORDINAL_POSITION
        """, db)
        lines = []
        for c in cols:
            dtype = c["DATA_TYPE"]
            if c["CHARACTER_MAXIMUM_LENGTH"]:
                size = "MAX" if c["CHARACTER_MAXIMUM_LENGTH"] == -1 else c["CHARACTER_MAXIMUM_LENGTH"]
                dtype += f"({size})"
            elif c["NUMERIC_PRECISION"] and dtype in ("decimal","numeric"):
                dtype += f"({c['NUMERIC_PRECISION']},{c['NUMERIC_SCALE']})"
            null = "NULL" if c["IS_NULLABLE"] == "YES" else "NOT NULL"
            default = f" DEFAULT {c['COLUMN_DEFAULT']}" if c["COLUMN_DEFAULT"] else ""
            lines.append(f"    [{c['COLUMN_NAME']}] {dtype.upper()} {null}{default}")
        ddl = f"CREATE TABLE [{schema}].[{tbl}] (\n" + ",\n".join(lines) + "\n);"
        return ddl

    if name == "list_stored_procedures":
        cond = f"ROUTINE_SCHEMA='{schema}' AND ROUTINE_TYPE='PROCEDURE'"
        if a.get("name_filter"):
            cond += f" AND ROUTINE_NAME LIKE '%{a['name_filter']}%'"
        rows, _ = _run_select(
            f"SELECT ROUTINE_NAME, CREATED, LAST_ALTERED FROM INFORMATION_SCHEMA.ROUTINES "
            f"WHERE {cond} ORDER BY ROUTINE_NAME", db)
        return f"{len(rows)} stored procedures:\n{_fmt(rows)}"

    if name == "list_indexes":
        tbl = a["table_name"]
        rows, _ = _run_select(f"""
            SELECT i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_disabled,
                   STRING_AGG(c.name, ', ') WITHIN GROUP (ORDER BY ic.key_ordinal) AS columns
            FROM sys.indexes i
            JOIN sys.index_columns ic ON i.object_id=ic.object_id AND i.index_id=ic.index_id
            JOIN sys.columns c ON ic.object_id=c.object_id AND ic.column_id=c.column_id
            WHERE OBJECT_NAME(i.object_id)='{tbl}'
            GROUP BY i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_disabled
        """, db)
        return f"{len(rows)} indexes on [{tbl}]:\n{_fmt(rows)}"

    if name == "list_foreign_keys":
        tbl = a["table_name"]
        rows, _ = _run_select(f"""
            SELECT fk.name AS fk_name,
                   OBJECT_NAME(fk.parent_object_id) AS parent_table,
                   c1.name AS parent_column,
                   OBJECT_NAME(fk.referenced_object_id) AS ref_table,
                   c2.name AS ref_column,
                   fk.delete_referential_action_desc,
                   fk.update_referential_action_desc
            FROM sys.foreign_keys fk
            JOIN sys.foreign_key_columns fkc ON fk.object_id=fkc.constraint_object_id
            JOIN sys.columns c1 ON fkc.parent_object_id=c1.object_id AND fkc.parent_column_id=c1.column_id
            JOIN sys.columns c2 ON fkc.referenced_object_id=c2.object_id AND fkc.referenced_column_id=c2.column_id
            WHERE OBJECT_NAME(fk.parent_object_id)='{tbl}'
              OR OBJECT_NAME(fk.referenced_object_id)='{tbl}'
        """, db)
        return f"{len(rows)} foreign key relationships:\n{_fmt(rows)}"

    # ── Query Execution ───────────────────────────────────────────────────────
    if name == "run_query":
        sql = a["sql"]
        max_rows = a.get("max_rows", 1000)
        # Inject TOP if not present and it's a SELECT
        if re.match(r"^\s*SELECT\s+(?!TOP)", sql, re.IGNORECASE):
            sql = re.sub(r"^\s*SELECT\s+", f"SELECT TOP {max_rows} ", sql, count=1, flags=re.IGNORECASE)
        rows, cols = _run_select(sql, db)
        out = f"Query returned {len(rows)} row(s), {len(cols)} column(s)\n"
        out += f"Columns: {cols}\n\n"
        out += _fmt(rows)
        return out

    if name == "run_query_paginated":
        order_col = a.get("order_by", "(SELECT NULL)")
        page = max(1, a.get("page", 1))
        page_size = a.get("page_size", 50)
        offset = (page - 1) * page_size
        base_sql = a["sql"].rstrip(";")
        paginated = f"{base_sql} ORDER BY {order_col} OFFSET {offset} ROWS FETCH NEXT {page_size} ROWS ONLY"
        rows, cols = _run_select(paginated, db)
        return f"Page {page} (rows {offset+1}–{offset+len(rows)}), {len(rows)} row(s):\n{_fmt(rows)}"

    if name == "run_stored_procedure":
        params = a.get("parameters", {})
        param_str = ", ".join([f"@{k}=?" for k in params])
        call_sql = f"EXEC [{schema}].[{a['procedure_name']}] {param_str}"
        with _get_conn(db) as conn:
            cursor = conn.cursor()
            cursor.execute(call_sql, list(params.values()))
            all_results = []
            while True:
                if cursor.description:
                    all_results.extend(_rows_to_dicts(cursor))
                if not cursor.nextset():
                    break
            conn.commit()
        return f"SP returned {len(all_results)} row(s):\n{_fmt(all_results)}"

    if name == "run_raw_sql":
        if not a.get("confirm"):
            return ("⚠️ Non-SELECT SQL requires confirm=true. "
                    "Please confirm this is intentional before executing.")
        sql = a["sql"]
        with _get_conn(db) as conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            rows_affected = cursor.rowcount
            conn.commit()
        return f"✅ Executed. Rows affected: {rows_affected}"

    # ── Data Exploration ──────────────────────────────────────────────────────
    if name == "get_row_count":
        tbl = a["sql_or_table"] if "sql_or_table" in a else a.get("table_name", "")
        if tbl.strip().upper().startswith("SELECT"):
            sql = f"SELECT COUNT(*) AS row_count FROM ({tbl}) _sub"
        else:
            where = f" WHERE {a['where_clause']}" if a.get("where_clause") else ""
            sql = f"SELECT COUNT(*) AS row_count FROM [{schema}].[{tbl}]{where}"
        rows, _ = _run_select(sql, db)
        count = rows[0]["row_count"] if rows else 0
        return f"Row count: {count:,}"

    if name == "get_table_sample":
        where = f" WHERE {a['where_clause']}" if a.get("where_clause") else ""
        order = f" ORDER BY {a['order_by']}" if a.get("order_by") else ""
        n = a.get("sample_size", 10)
        sql = f"SELECT TOP {n} * FROM [{schema}].[{a['table_name']}]{where}{order}"
        rows, cols = _run_select(sql, db)
        return f"Sample ({len(rows)} rows) from [{a['table_name']}]:\n{_fmt(rows)}"

    if name == "get_distinct_values":
        where = f" WHERE {a['where_clause']}" if a.get("where_clause") else ""
        sql = (f"SELECT TOP {a.get('limit',100)} [{a['column_name']}] AS value, "
               f"COUNT(*) AS count FROM [{schema}].[{a['table_name']}]{where} "
               f"GROUP BY [{a['column_name']}] ORDER BY count DESC")
        rows, _ = _run_select(sql, db)
        return f"Distinct values in [{a['column_name']}]:\n{_fmt(rows)}"

    if name == "search_column_for_value":
        tbl = a["table_name"]
        val = a["search_value"].replace("'", "''")
        if a.get("column_name"):
            op = "=" if a.get("exact_match") else "LIKE"
            search_val = f"'{val}'" if a.get("exact_match") else f"'%{val}%'"
            sql = f"SELECT TOP 100 * FROM [{schema}].[{tbl}] WHERE CAST([{a['column_name']}] AS NVARCHAR(MAX)) {op} {search_val}"
            rows, _ = _run_select(sql, db)
            return f"{len(rows)} match(es):\n{_fmt(rows)}"
        else:
            # Search all varchar/text columns
            col_rows, _ = _run_select(
                f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
                f"WHERE TABLE_NAME='{tbl}' AND TABLE_SCHEMA='{schema}' "
                f"AND DATA_TYPE IN ('varchar','nvarchar','text','ntext','char','nchar')", db)
            string_cols = [r["COLUMN_NAME"] for r in col_rows]
            all_matches = {}
            for col in string_cols:
                sql = (f"SELECT TOP 20 * FROM [{schema}].[{tbl}] "
                       f"WHERE CAST([{col}] AS NVARCHAR(MAX)) LIKE '%{val}%'")
                rows, _ = _run_select(sql, db)
                if rows:
                    all_matches[col] = rows
            return f"Matches for '{val}' across {len(string_cols)} string columns:\n{_fmt(all_matches)}"

    # ── Assertions ────────────────────────────────────────────────────────────
    if name == "assert_row_count":
        src = a["sql_or_table"]
        if src.strip().upper().startswith("SELECT"):
            count_sql = f"SELECT COUNT(*) AS n FROM ({src}) _sub"
        else:
            where = f" WHERE {a['where_clause']}" if a.get("where_clause") else ""
            count_sql = f"SELECT COUNT(*) AS n FROM [{schema}].[{src}]{where}"
        rows, _ = _run_select(count_sql, db)
        actual = rows[0]["n"] if rows else 0
        expected = a["expected_value"]
        op = a["operator"]
        ops = {"==": actual==expected,"!=": actual!=expected,">": actual>expected,
               "<": actual<expected,">=": actual>=expected,"<=": actual<=expected}
        passed = ops.get(op, False)
        status = "✅ PASS" if passed else "❌ FAIL"
        return (f"Assertion: row_count {op} {expected}\n"
                f"Actual   : {actual:,}\n"
                f"Result   : {status}")

    if name == "assert_value_exists":
        val = a["expected_value"].replace("'", "''")
        where = f" AND {a['where_clause']}" if a.get("where_clause") else ""
        sql = (f"SELECT COUNT(*) AS n FROM [{schema}].[{a['table_name']}] "
               f"WHERE CAST([{a['column_name']}] AS NVARCHAR(MAX)) = '{val}'{where}")
        rows, _ = _run_select(sql, db)
        found = rows[0]["n"] > 0 if rows else False
        status = "✅ PASS" if found else "❌ FAIL"
        return (f"Assertion: value '{a['expected_value']}' exists in [{a['table_name']}].[{a['column_name']}]\n"
                f"Found     : {rows[0]['n'] if rows else 0} occurrence(s)\n"
                f"Result    : {status}")

    if name == "assert_column_value":
        rows, cols = _run_select(a["sql"], db)
        if not rows:
            return "❌ FAIL — Query returned no rows"
        if len(rows) > 1:
            return f"⚠️ WARNING — Query returned {len(rows)} rows; using first row"
        actual = str(rows[0].get(a["column_name"], ""))
        expected = str(a["expected_value"])
        cmp = a.get("comparison", "==")
        passed = (
            (cmp == "==" and actual == expected) or
            (cmp == "!=" and actual != expected) or
            (cmp == "contains" and expected in actual) or
            (cmp == "startswith" and actual.startswith(expected)) or
            (cmp == "endswith" and actual.endswith(expected))
        )
        status = "✅ PASS" if passed else "❌ FAIL"
        return (f"Assertion: [{a['column_name']}] {cmp} '{expected}'\n"
                f"Actual   : '{actual}'\n"
                f"Result   : {status}")

    if name == "assert_query_returns_rows":
        rows, _ = _run_select(a["sql"], db)
        passed = len(rows) > 0
        label = a.get("description", "query has rows")
        status = "✅ PASS" if passed else "❌ FAIL"
        return f"Assertion: '{label}'\nRow count: {len(rows)}\nResult   : {status}"

    if name == "assert_no_rows":
        rows, _ = _run_select(a["sql"], db)
        passed = len(rows) == 0
        label = a.get("description", "query returns no rows")
        status = "✅ PASS" if passed else "❌ FAIL"
        return f"Assertion: '{label}'\nRow count: {len(rows)}\nResult   : {status}"

    if name == "assert_column_not_null":
        tbl = a["table_name"]
        where = f" AND {a['where_clause']}" if a.get("where_clause") else ""
        sql = (f"SELECT COUNT(*) AS null_count FROM [{schema}].[{tbl}] "
               f"WHERE [{a['column_name']}] IS NULL{where}")
        rows, _ = _run_select(sql, db)
        null_count = rows[0]["null_count"] if rows else 0
        passed = null_count == 0
        status = "✅ PASS" if passed else "❌ FAIL"
        return (f"Assertion: [{tbl}].[{a['column_name']}] has no NULLs\n"
                f"NULL count: {null_count:,}\n"
                f"Result    : {status}")

    if name == "run_assertion_suite":
        results = []
        passed = failed = 0
        for assertion in a["assertions"]:
            aname = assertion["name"]
            sql = assertion["sql"]
            check = assertion["check_type"]
            expected = assertion.get("expected", "")
            try:
                rows, _ = _run_select(sql, db)
                count = len(rows)
                if check == "has_rows":
                    ok = count > 0
                elif check == "no_rows":
                    ok = count == 0
                elif check == "row_count_eq":
                    ok = count == int(expected)
                elif check == "row_count_gt":
                    ok = count > int(expected)
                elif check == "value_eq":
                    ok = rows and str(list(rows[0].values())[0]) == str(expected)
                else:
                    ok = False
                status = "PASS" if ok else "FAIL"
                if ok: passed += 1
                else:  failed += 1
                results.append({"name": aname, "status": status,
                                 "actual_rows": count, "check": check, "expected": expected})
            except Exception as e:
                failed += 1
                results.append({"name": aname, "status": "ERROR", "error": str(e)})

        summary = f"Assertion Suite Results: {passed} PASS / {failed} FAIL / {len(a['assertions'])} total\n\n"
        for r in results:
            emoji = "✅" if r["status"] == "PASS" else "❌"
            summary += f"{emoji} {r['name']}: {r['status']}\n"
        return summary + f"\nDetails:\n{_fmt(results)}"

    # ── Export ────────────────────────────────────────────────────────────────
    if name == "export_to_excel":
        rows, cols = _run_select(a["sql"], db)
        df = pd.DataFrame(rows, columns=cols)
        fname = a["filename"]
        if not fname.endswith(".xlsx"):
            fname += ".xlsx"
        filepath = SSMS_EXPORT_DIR / fname
        _export_df_to_excel(df, a.get("sheet_name","Query Results"), filepath, a.get("title",""))
        return f"✅ Exported {len(rows)} rows to:\n  {filepath}"

    if name == "export_multiple_queries_to_excel":
        fname = a["filename"]
        if not fname.endswith(".xlsx"):
            fname += ".xlsx"
        filepath = SSMS_EXPORT_DIR / fname
        SSMS_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        wb = openpyxl.Workbook()
        wb.remove(wb.active)
        totals = []
        for q in a["queries"]:
            rows, cols = _run_select(q["sql"], db)
            df = pd.DataFrame(rows, columns=cols)
            ws = wb.create_sheet(title=q["sheet_name"][:31])
            title = q.get("title", "")
            start_row = 1
            if title:
                ws.append([title])
                ws.append([f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
                ws.append([f"Rows: {len(df)}"])
                ws.append([])
                start_row = 5
            header_fill = PatternFill("solid", fgColor="2E75B6")
            for ci, col in enumerate(df.columns, 1):
                cell = ws.cell(row=start_row, column=ci, value=col)
                cell.fill = header_fill
                cell.font = Font(bold=True, color="FFFFFF")
            for ri, row in enumerate(df.itertuples(index=False), start_row+1):
                for ci, val in enumerate(row, 1):
                    ws.cell(row=ri, column=ci, value=val)
            totals.append(f"  Sheet '{q['sheet_name']}': {len(rows)} rows")
        wb.save(filepath)
        return "✅ Multi-sheet Excel exported:\n" + "\n".join(totals) + f"\n\nFile: {filepath}"

    # ── Jobs ─────────────────────────────────────────────────────────────────
    if name == "list_jobs":
        sql = """
            SELECT j.name, j.enabled,
                   CASE jh.run_status WHEN 0 THEN 'Failed' WHEN 1 THEN 'Succeeded'
                     WHEN 2 THEN 'Retry' WHEN 3 THEN 'Cancelled' ELSE 'Unknown' END AS last_status,
                   msdb.dbo.agent_datetime(jh.run_date, jh.run_time) AS last_run_time,
                   j.description
            FROM msdb.dbo.sysjobs j
            LEFT JOIN msdb.dbo.sysjobhistory jh ON j.job_id=jh.job_id
              AND jh.instance_id=(SELECT MAX(instance_id) FROM msdb.dbo.sysjobhistory WHERE job_id=j.job_id)
            ORDER BY j.name
        """
        if a.get("name_filter"):
            sql = sql.replace("ORDER BY j.name",
                              f"AND j.name LIKE '%{a['name_filter']}%' ORDER BY j.name")
        rows, _ = _run_select(sql)
        return f"{len(rows)} SQL Agent jobs:\n{_fmt(rows)}"

    return f"Unknown tool: {name}"


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream,
                         server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
