"""
backend/mcp_servers/custom_mcp/server.py
─────────────────────────────────────────
TEMPLATE: How to add ANY new service as an MCP

Copy this file to a new folder, implement the tools, register in mcp_config.json.
Claude will automatically use it in workflows once registered.

Example services you could add using this template:
  - Slack (send messages, read channels)
  - Jira (create tickets, update status)
  - Snowflake (run queries, get schemas)
  - PostgreSQL (same pattern as SSMS)
  - MongoDB (find, insert, update documents)
  - REST API (generic HTTP GET/POST)
  - Email (send via SMTP)
  - ServiceNow (create incidents)
  - Databricks (run notebooks, jobs)
  - GitHub (create PRs, read issues)
  - PagerDuty (trigger alerts)
  - Kafka (produce/consume messages)
"""

import asyncio
import json
import os
import sys
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

server = Server("custom-mcp")          # ← Change this name


# ─── Step 1: Define your tools ────────────────────────────────────────────────

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="my_tool_name",                                    # snake_case, unique
            description="What this tool does — be specific so Claude knows when to use it.",
            inputSchema={
                "type": "object",
                "required": ["required_param"],
                "properties": {
                    "required_param": {
                        "type": "string",
                        "description": "What this parameter is"
                    },
                    "optional_param": {
                        "type": "integer",
                        "default": 10,
                        "description": "Optional parameter with default"
                    }
                }
            }
        ),
        # Add more Tool(...) entries here
    ]


# ─── Step 2: Implement your tool logic ───────────────────────────────────────

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await _dispatch(name, arguments)
        return [TextContent(type="text", text=result)]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]


async def _dispatch(name: str, a: dict) -> str:
    if name == "my_tool_name":
        # Your implementation here
        param = a["required_param"]
        # ... call your service API, SDK, etc.
        return f"Result for {param}"

    return f"Unknown tool: {name}"


# ─── Step 3: Register in mcp_config.json ─────────────────────────────────────
#
# Add this to the "mcpServers" object in backend/mcp_config.json:
#
# "my-service": {
#   "command": "python",
#   "args": ["-m", "mcp_servers.custom_mcp.server"],
#   "cwd": "/path/to/workflow-studio/backend",
#   "env": { "MY_API_KEY": "..." },
#   "description": "My custom service MCP"
# }
#
# ─── Step 4: Add tool→MCP mapping in frontend ────────────────────────────────
#
# In WorkflowAI.jsx, add to TOOL_MCP_MAP:
#   my_tool_name: "my_service"
#
# And add to MCP_META:
#   my_service: { color: "#...", bg: "#...", label: "MY SERVICE" }
#
# Claude will now automatically use this tool in any workflow that needs it.


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream,
                         server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
