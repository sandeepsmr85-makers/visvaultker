"""
mcp_servers/airflow_mcp/server.py
──────────────────────────────────
Apache Airflow MCP Server
Supports Airflow 2.7.3 REST API (api/v1)

Tools exposed:
  DAG Management   : list_dags, get_dag, pause_dag, unpause_dag, delete_dag
  DAG Runs         : trigger_dag_run, get_dag_run, list_dag_runs,
                     wait_for_dag_run, delete_dag_run, clear_dag_run
  Task Instances   : list_task_instances, get_task_instance,
                     clear_task_instance, set_task_instance_state
  Logs             : get_task_logs, get_all_task_logs
  Variables        : list_variables, get_variable, set_variable, delete_variable
  Connections      : list_connections, get_connection
  Pools            : list_pools, get_pool
  XCom             : get_xcom_value, list_xcom_entries
  Health/Meta      : get_health, get_version, get_dag_stats
"""

import asyncio
import time
import json
from datetime import datetime, timezone
from typing import Any

import requests
from requests.auth import HTTPBasicAuth
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from config.settings import (
    AIRFLOW_BASE_URL, AIRFLOW_USERNAME, AIRFLOW_PASSWORD,
    AIRFLOW_API_VERSION, AIRFLOW_AUTH_TOKEN
)

# ─── HTTP client helpers ─────────────────────────────────────────────────────

def _headers() -> dict:
    h = {"Content-Type": "application/json", "Accept": "application/json"}
    if AIRFLOW_AUTH_TOKEN:
        h["Authorization"] = f"Bearer {AIRFLOW_AUTH_TOKEN}"
    return h

def _auth():
    if AIRFLOW_AUTH_TOKEN:
        return None
    return HTTPBasicAuth(AIRFLOW_USERNAME, AIRFLOW_PASSWORD)

def _url(path: str) -> str:
    return f"{AIRFLOW_BASE_URL}/api/{AIRFLOW_API_VERSION}/{path.lstrip('/')}"

def _get(path: str, params: dict | None = None) -> dict:
    r = requests.get(_url(path), headers=_headers(), auth=_auth(),
                     params=params, timeout=30)
    r.raise_for_status()
    return r.json()

def _post(path: str, body: dict | None = None) -> dict:
    r = requests.post(_url(path), headers=_headers(), auth=_auth(),
                      json=body or {}, timeout=30)
    r.raise_for_status()
    return r.json()

def _patch(path: str, body: dict) -> dict:
    r = requests.patch(_url(path), headers=_headers(), auth=_auth(),
                       json=body, timeout=30)
    r.raise_for_status()
    return r.json()

def _delete(path: str) -> str:
    r = requests.delete(_url(path), headers=_headers(), auth=_auth(), timeout=30)
    r.raise_for_status()
    return "deleted"

def _fmt(obj: Any) -> str:
    return json.dumps(obj, indent=2, default=str)

# ─── MCP Server ──────────────────────────────────────────────────────────────

server = Server("airflow-mcp")

# ══════════════════════════════════════════════════════════════════════════════
# TOOL DEFINITIONS
# ══════════════════════════════════════════════════════════════════════════════

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [

        # ── DAG Management ─────────────────────────────────────────────────
        Tool(name="list_dags",
             description="List all DAGs. Optionally filter by tags or only active.",
             inputSchema={"type":"object","properties":{
                 "limit":{"type":"integer","default":100},
                 "offset":{"type":"integer","default":0},
                 "tags":{"type":"array","items":{"type":"string"},"description":"Filter by tag names"},
                 "only_active":{"type":"boolean","default":True},
                 "dag_id_pattern":{"type":"string","description":"Substring to filter dag_id"}
             }}),

        Tool(name="get_dag",
             description="Get full details of a specific DAG including schedule, tags, owners.",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"}
             }}),

        Tool(name="pause_dag",
             description="Pause a DAG (no new runs will be scheduled).",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"}
             }}),

        Tool(name="unpause_dag",
             description="Unpause/activate a DAG so it runs on schedule.",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"}
             }}),

        Tool(name="get_dag_source",
             description="Retrieve the Python source code of a DAG.",
             inputSchema={"type":"object","required":["file_token"],"properties":{
                 "file_token":{"type":"string","description":"Obtained from get_dag response (file_token field)"}
             }}),

        Tool(name="get_dag_stats",
             description="Get run statistics for one or more DAGs (count per state).",
             inputSchema={"type":"object","properties":{
                 "dag_ids":{"type":"array","items":{"type":"string"}}
             }}),

        # ── DAG Runs ───────────────────────────────────────────────────────
        Tool(name="trigger_dag_run",
             description="Trigger a new DAG run. Optionally pass conf dict and a custom run_id.",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "conf":{"type":"object","description":"JSON config passed to the DAG run","default":{}},
                 "run_id":{"type":"string","description":"Custom run ID (auto-generated if omitted)"},
                 "logical_date":{"type":"string","description":"ISO8601 execution date (defaults to now)"},
                 "note":{"type":"string","description":"Optional note attached to the run"}
             }}),

        Tool(name="get_dag_run",
             description="Get status and details of a specific DAG run.",
             inputSchema={"type":"object","required":["dag_id","run_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"}
             }}),

        Tool(name="list_dag_runs",
             description="List all runs for a DAG, with optional state filter.",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "state":{"type":"string","enum":["queued","running","success","failed","skipped",""]},
                 "limit":{"type":"integer","default":25},
                 "offset":{"type":"integer","default":0},
                 "order_by":{"type":"string","default":"-execution_date"}
             }}),

        Tool(name="wait_for_dag_run",
             description="Poll a DAG run until it reaches a terminal state (success/failed/etc). "
                         "Returns final state and duration. Uses configurable polling interval.",
             inputSchema={"type":"object","required":["dag_id","run_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "poll_interval_seconds":{"type":"integer","default":10,"description":"Seconds between polls"},
                 "timeout_seconds":{"type":"integer","default":3600,"description":"Give up after this many seconds"}
             }}),

        Tool(name="delete_dag_run",
             description="Delete a specific DAG run record.",
             inputSchema={"type":"object","required":["dag_id","run_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"}
             }}),

        Tool(name="clear_dag_run",
             description="Clear (re-queue) all tasks in a DAG run so they re-execute.",
             inputSchema={"type":"object","required":["dag_id","run_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "dry_run":{"type":"boolean","default":False}
             }}),

        Tool(name="get_latest_dag_run",
             description="Get the most recent run for a DAG regardless of state.",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "state":{"type":"string","enum":["queued","running","success","failed",""],"default":""}
             }}),

        # ── Task Instances ─────────────────────────────────────────────────
        Tool(name="list_task_instances",
             description="List all task instances for a DAG run with their states.",
             inputSchema={"type":"object","required":["dag_id","run_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"}
             }}),

        Tool(name="get_task_instance",
             description="Get full details for a single task instance.",
             inputSchema={"type":"object","required":["dag_id","run_id","task_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "task_id":{"type":"string"}
             }}),

        Tool(name="clear_task_instance",
             description="Clear one or more task instances so they re-run.",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string","description":"Specific run (omit for all runs)"},
                 "task_ids":{"type":"array","items":{"type":"string"},"description":"Tasks to clear"},
                 "include_downstream":{"type":"boolean","default":False},
                 "include_upstream":{"type":"boolean","default":False},
                 "dry_run":{"type":"boolean","default":False}
             }}),

        Tool(name="set_task_instance_state",
             description="Manually override the state of a task instance.",
             inputSchema={"type":"object","required":["dag_id","run_id","task_id","new_state"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "task_id":{"type":"string"},
                 "new_state":{"type":"string","enum":["success","failed","skipped","queued","up_for_retry"]}
             }}),

        Tool(name="list_tasks",
             description="List all tasks defined in a DAG (not instances — the DAG structure).",
             inputSchema={"type":"object","required":["dag_id"],"properties":{
                 "dag_id":{"type":"string"}
             }}),

        # ── Logs ───────────────────────────────────────────────────────────
        Tool(name="get_task_logs",
             description="Fetch logs for a specific task instance (optionally a specific try_number).",
             inputSchema={"type":"object","required":["dag_id","run_id","task_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "task_id":{"type":"string"},
                 "task_try_number":{"type":"integer","default":1},
                 "full_content":{"type":"boolean","default":True}
             }}),

        Tool(name="get_all_task_logs",
             description="Fetch logs for EVERY task in a DAG run. Returns a dict keyed by task_id.",
             inputSchema={"type":"object","required":["dag_id","run_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "task_try_number":{"type":"integer","default":1}
             }}),

        Tool(name="search_task_logs",
             description="Search task logs for a specific string/pattern across all tasks in a run.",
             inputSchema={"type":"object","required":["dag_id","run_id","search_term"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "search_term":{"type":"string","description":"String to search for in log lines"},
                 "case_sensitive":{"type":"boolean","default":False}
             }}),

        # ── Variables ──────────────────────────────────────────────────────
        Tool(name="list_variables",
             description="List all Airflow Variables.",
             inputSchema={"type":"object","properties":{
                 "limit":{"type":"integer","default":100}
             }}),

        Tool(name="get_variable",
             description="Get the value of a specific Airflow Variable.",
             inputSchema={"type":"object","required":["variable_key"],"properties":{
                 "variable_key":{"type":"string"}
             }}),

        Tool(name="set_variable",
             description="Create or update an Airflow Variable.",
             inputSchema={"type":"object","required":["variable_key","value"],"properties":{
                 "variable_key":{"type":"string"},
                 "value":{"type":"string"},
                 "description":{"type":"string","default":""}
             }}),

        Tool(name="delete_variable",
             description="Delete an Airflow Variable.",
             inputSchema={"type":"object","required":["variable_key"],"properties":{
                 "variable_key":{"type":"string"}
             }}),

        # ── Connections ────────────────────────────────────────────────────
        Tool(name="list_connections",
             description="List all Airflow Connections.",
             inputSchema={"type":"object","properties":{
                 "limit":{"type":"integer","default":100}
             }}),

        Tool(name="get_connection",
             description="Get details of a specific Airflow Connection.",
             inputSchema={"type":"object","required":["connection_id"],"properties":{
                 "connection_id":{"type":"string"}
             }}),

        # ── Pools ──────────────────────────────────────────────────────────
        Tool(name="list_pools",
             description="List all Airflow Pools and their slot usage.",
             inputSchema={"type":"object","properties":{
                 "limit":{"type":"integer","default":100}
             }}),

        Tool(name="get_pool",
             description="Get details of a specific Airflow Pool.",
             inputSchema={"type":"object","required":["pool_name"],"properties":{
                 "pool_name":{"type":"string"}
             }}),

        # ── XCom ───────────────────────────────────────────────────────────
        Tool(name="get_xcom_value",
             description="Retrieve an XCom value pushed by a task.",
             inputSchema={"type":"object","required":["dag_id","run_id","task_id","xcom_key"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "task_id":{"type":"string"},
                 "xcom_key":{"type":"string","default":"return_value"}
             }}),

        Tool(name="list_xcom_entries",
             description="List all XCom entries for a task instance.",
             inputSchema={"type":"object","required":["dag_id","run_id","task_id"],"properties":{
                 "dag_id":{"type":"string"},
                 "run_id":{"type":"string"},
                 "task_id":{"type":"string"},
                 "limit":{"type":"integer","default":50}
             }}),

        # ── Health / Meta ──────────────────────────────────────────────────
        Tool(name="get_health",
             description="Check Airflow health status (metadatabase, scheduler, triggerer).",
             inputSchema={"type":"object","properties":{}}),

        Tool(name="get_version",
             description="Get the Airflow version information.",
             inputSchema={"type":"object","properties":{}}),
    ]


# ══════════════════════════════════════════════════════════════════════════════
# TOOL CALL HANDLER
# ══════════════════════════════════════════════════════════════════════════════

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await _dispatch(name, arguments)
        return [TextContent(type="text", text=result)]
    except requests.HTTPError as e:
        body = ""
        try:
            body = e.response.json()
        except Exception:
            body = e.response.text
        return [TextContent(type="text", text=f"Airflow API Error {e.response.status_code}: {_fmt(body)}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]


async def _dispatch(name: str, a: dict) -> str:
    # ── DAG Management ──────────────────────────────────────────────────────
    if name == "list_dags":
        params = {"limit": a.get("limit", 100), "offset": a.get("offset", 0)}
        if a.get("only_active"):
            params["only_active"] = "true"
        if a.get("tags"):
            params["tags"] = a["tags"]
        result = _get("dags", params)
        dags = result.get("dags", [])
        if a.get("dag_id_pattern"):
            pat = a["dag_id_pattern"].lower()
            dags = [d for d in dags if pat in d["dag_id"].lower()]
        summary = [
            {"dag_id": d["dag_id"], "is_paused": d["is_paused"],
             "schedule_interval": d.get("schedule_interval",""),
             "owners": d.get("owners",[]), "tags": [t["name"] for t in d.get("tags",[])]}
            for d in dags
        ]
        return f"Found {len(dags)} DAGs:\n{_fmt(summary)}"

    if name == "get_dag":
        return _fmt(_get(f"dags/{a['dag_id']}"))

    if name == "pause_dag":
        return _fmt(_patch(f"dags/{a['dag_id']}", {"is_paused": True}))

    if name == "unpause_dag":
        return _fmt(_patch(f"dags/{a['dag_id']}", {"is_paused": False}))

    if name == "get_dag_source":
        return _fmt(_get(f"dagSources/{a['file_token']}"))

    if name == "get_dag_stats":
        params = {}
        if a.get("dag_ids"):
            params["dag_ids"] = ",".join(a["dag_ids"])
        return _fmt(_get("dags/~/dagRuns/~", params))

    # ── DAG Runs ─────────────────────────────────────────────────────────────
    if name == "trigger_dag_run":
        body: dict = {"conf": a.get("conf", {})}
        if a.get("run_id"):
            body["dag_run_id"] = a["run_id"]
        if a.get("logical_date"):
            body["logical_date"] = a["logical_date"]
        if a.get("note"):
            body["note"] = a["note"]
        result = _post(f"dags/{a['dag_id']}/dagRuns", body)
        return (f"✅ DAG run triggered!\n"
                f"  dag_id : {result['dag_id']}\n"
                f"  run_id : {result['dag_run_id']}\n"
                f"  state  : {result['state']}\n"
                f"  exec   : {result.get('logical_date','')}\n"
                f"\n{_fmt(result)}")

    if name == "get_dag_run":
        result = _get(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}")
        return (f"DAG Run Status\n"
                f"  dag_id    : {result['dag_id']}\n"
                f"  run_id    : {result['dag_run_id']}\n"
                f"  state     : {result['state']}\n"
                f"  start_date: {result.get('start_date','')}\n"
                f"  end_date  : {result.get('end_date','')}\n"
                f"\nFull details:\n{_fmt(result)}")

    if name == "list_dag_runs":
        params = {
            "limit": a.get("limit", 25),
            "offset": a.get("offset", 0),
            "order_by": a.get("order_by", "-execution_date")
        }
        if a.get("state"):
            params["state"] = [a["state"]]
        result = _get(f"dags/{a['dag_id']}/dagRuns", params)
        runs = result.get("dag_runs", [])
        summary = [{"run_id": r["dag_run_id"], "state": r["state"],
                    "start": r.get("start_date",""), "end": r.get("end_date","")} for r in runs]
        return f"{len(runs)} runs for {a['dag_id']}:\n{_fmt(summary)}"

    if name == "wait_for_dag_run":
        dag_id = a["dag_id"]
        run_id = a["run_id"]
        interval = a.get("poll_interval_seconds", 10)
        timeout = a.get("timeout_seconds", 3600)
        terminal = {"success", "failed", "error"}
        start = time.time()
        poll_count = 0
        while True:
            elapsed = time.time() - start
            if elapsed > timeout:
                return f"⏰ Timeout after {elapsed:.0f}s waiting for {dag_id}/{run_id}"
            result = _get(f"dags/{dag_id}/dagRuns/{run_id}")
            state = result.get("state", "")
            poll_count += 1
            if state in terminal:
                emoji = "✅" if state == "success" else "❌"
                return (f"{emoji} DAG run finished\n"
                        f"  state   : {state}\n"
                        f"  elapsed : {elapsed:.1f}s\n"
                        f"  polls   : {poll_count}\n"
                        f"  start   : {result.get('start_date','')}\n"
                        f"  end     : {result.get('end_date','')}\n")
            await asyncio.sleep(interval)

    if name == "delete_dag_run":
        _delete(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}")
        return f"✅ Deleted run {a['run_id']} from {a['dag_id']}"

    if name == "clear_dag_run":
        body = {"dry_run": a.get("dry_run", False)}
        result = _post(f"dags/{a['dag_id']}/clearTaskInstances", body)
        return f"Clear result:\n{_fmt(result)}"

    if name == "get_latest_dag_run":
        params = {"limit": 1, "order_by": "-execution_date"}
        if a.get("state"):
            params["state"] = [a["state"]]
        result = _get(f"dags/{a['dag_id']}/dagRuns", params)
        runs = result.get("dag_runs", [])
        if not runs:
            return f"No runs found for {a['dag_id']}"
        return _fmt(runs[0])

    # ── Task Instances ────────────────────────────────────────────────────────
    if name == "list_task_instances":
        result = _get(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances")
        tasks = result.get("task_instances", [])
        summary = [
            {"task_id": t["task_id"], "state": t.get("state",""),
             "start_date": t.get("start_date",""), "end_date": t.get("end_date",""),
             "duration": t.get("duration",""), "try_number": t.get("try_number",1)}
            for t in tasks
        ]
        return f"{len(tasks)} task instances:\n{_fmt(summary)}"

    if name == "get_task_instance":
        result = _get(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances/{a['task_id']}")
        return _fmt(result)

    if name == "clear_task_instance":
        body: dict = {
            "dry_run": a.get("dry_run", False),
            "include_downstream": a.get("include_downstream", False),
            "include_upstream": a.get("include_upstream", False),
            "reset_dag_runs": True
        }
        if a.get("task_ids"):
            body["task_ids"] = a["task_ids"]
        if a.get("run_id"):
            body["dag_run_id"] = a["run_id"]
        result = _post(f"dags/{a['dag_id']}/clearTaskInstances", body)
        return f"Clear result:\n{_fmt(result)}"

    if name == "set_task_instance_state":
        body = {
            "dry_run": False,
            "task_id": a["task_id"],
            "execution_date": a.get("execution_date", ""),
            "dag_run_id": a["run_id"],
            "new_state": a["new_state"],
            "include_upstream": False,
            "include_downstream": False,
            "include_future": False,
            "include_past": False
        }
        result = _post(f"dags/{a['dag_id']}/updateTaskInstancesState", body)
        return f"State set to {a['new_state']}:\n{_fmt(result)}"

    if name == "list_tasks":
        result = _get(f"dags/{a['dag_id']}/tasks")
        tasks = result.get("tasks", [])
        summary = [{"task_id": t["task_id"], "task_type": t.get("class_ref", {}).get("class_name",""),
                    "operator": t.get("operator_name",""), "deps": t.get("downstream_task_ids",[])}
                   for t in tasks]
        return f"{len(tasks)} tasks in {a['dag_id']}:\n{_fmt(summary)}"

    # ── Logs ──────────────────────────────────────────────────────────────────
    if name == "get_task_logs":
        try_no = a.get("task_try_number", 1)
        r = requests.get(
            _url(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances/{a['task_id']}/logs/{try_no}"),
            headers={**_headers(), "Accept": "text/plain"},
            auth=_auth(), timeout=30
        )
        r.raise_for_status()
        log_text = r.text
        lines = log_text.splitlines()
        return (f"Logs for {a['task_id']} (try #{try_no}) — {len(lines)} lines:\n"
                f"{'─'*60}\n{log_text}")

    if name == "get_all_task_logs":
        # First get all task instances
        result = _get(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances")
        tasks = result.get("task_instances", [])
        try_no = a.get("task_try_number", 1)
        all_logs = {}
        for t in tasks:
            tid = t["task_id"]
            try:
                r = requests.get(
                    _url(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances/{tid}/logs/{try_no}"),
                    headers={**_headers(), "Accept": "text/plain"},
                    auth=_auth(), timeout=30
                )
                r.raise_for_status()
                all_logs[tid] = r.text
            except Exception as e:
                all_logs[tid] = f"ERROR fetching logs: {e}"
        output = []
        for tid, log in all_logs.items():
            output.append(f"\n{'═'*60}\nTASK: {tid}\n{'═'*60}\n{log}")
        return "\n".join(output)

    if name == "search_task_logs":
        result = _get(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances")
        tasks = result.get("task_instances", [])
        term = a["search_term"]
        case = a.get("case_sensitive", False)
        matches = []
        for t in tasks:
            tid = t["task_id"]
            try:
                r = requests.get(
                    _url(f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances/{tid}/logs/1"),
                    headers={**_headers(), "Accept": "text/plain"},
                    auth=_auth(), timeout=30
                )
                r.raise_for_status()
                for i, line in enumerate(r.text.splitlines(), 1):
                    haystack = line if case else line.lower()
                    needle = term if case else term.lower()
                    if needle in haystack:
                        matches.append({"task_id": tid, "line_no": i, "line": line.strip()})
            except Exception:
                pass
        return (f"Found {len(matches)} matches for '{term}':\n{_fmt(matches)}")

    # ── Variables ─────────────────────────────────────────────────────────────
    if name == "list_variables":
        return _fmt(_get("variables", {"limit": a.get("limit", 100)}))

    if name == "get_variable":
        return _fmt(_get(f"variables/{a['variable_key']}"))

    if name == "set_variable":
        body = {"key": a["variable_key"], "value": a["value"],
                "description": a.get("description", "")}
        try:
            return _fmt(_patch(f"variables/{a['variable_key']}", body))
        except Exception:
            return _fmt(_post("variables", body))

    if name == "delete_variable":
        _delete(f"variables/{a['variable_key']}")
        return f"✅ Deleted variable '{a['variable_key']}'"

    # ── Connections ───────────────────────────────────────────────────────────
    if name == "list_connections":
        return _fmt(_get("connections", {"limit": a.get("limit", 100)}))

    if name == "get_connection":
        return _fmt(_get(f"connections/{a['connection_id']}"))

    # ── Pools ─────────────────────────────────────────────────────────────────
    if name == "list_pools":
        return _fmt(_get("pools", {"limit": a.get("limit", 100)}))

    if name == "get_pool":
        return _fmt(_get(f"pools/{a['pool_name']}"))

    # ── XCom ─────────────────────────────────────────────────────────────────
    if name == "get_xcom_value":
        result = _get(
            f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances/{a['task_id']}/xcomEntries/{a.get('xcom_key','return_value')}"
        )
        return _fmt(result)

    if name == "list_xcom_entries":
        result = _get(
            f"dags/{a['dag_id']}/dagRuns/{a['run_id']}/taskInstances/{a['task_id']}/xcomEntries",
            {"limit": a.get("limit", 50)}
        )
        return _fmt(result)

    # ── Health / Meta ─────────────────────────────────────────────────────────
    if name == "get_health":
        return _fmt(_get("health"))

    if name == "get_version":
        return _fmt(_get("version"))

    return f"Unknown tool: {name}"


# ─── Entry point ──────────────────────────────────────────────────────────────

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream,
                         server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
