"""
mcp_servers/http_mcp/server.py
────────────────────────────────
HTTP Request MCP Server

Allows Claude to make outbound HTTP calls to any REST API as part of a workflow.
Useful for webhooks, internal APIs, health checks, and integrating services that
don't have a dedicated MCP server yet.

Tools exposed:
  Core requests : http_get, http_post, http_put, http_patch, http_delete
  Convenience   : http_get_json, http_post_json
  Auth helpers  : http_get_with_auth, http_post_with_auth
  Polling       : http_poll_until
  Assertion     : http_assert_status

Environment variables (all optional):
  HTTP_DEFAULT_TIMEOUT   — request timeout in seconds (default: 30)
  HTTP_MAX_RESPONSE_BYTES — truncate large responses (default: 102400 = 100 KB)
  HTTP_ALLOWED_HOSTS     — comma-separated allowlist of hostnames Claude may call.
                           Leave empty to allow all hosts (open mode).
                           Example: api.github.com,hooks.slack.com
  HTTP_DEFAULT_HEADERS   — JSON object of headers added to every request.
                           Example: {"X-Source": "workflow-studio"}
"""

import asyncio
import json
import os
import re
import sys
import time
from typing import Any
from urllib.parse import urlparse

import requests
from requests.auth import HTTPBasicAuth
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

# ─── Config ──────────────────────────────────────────────────────────────────

DEFAULT_TIMEOUT     = int(os.getenv("HTTP_DEFAULT_TIMEOUT", "30"))
MAX_RESPONSE_BYTES  = int(os.getenv("HTTP_MAX_RESPONSE_BYTES", "102400"))
_raw_allowed        = os.getenv("HTTP_ALLOWED_HOSTS", "")
ALLOWED_HOSTS: set[str] = {h.strip() for h in _raw_allowed.split(",") if h.strip()}

_raw_default_headers = os.getenv("HTTP_DEFAULT_HEADERS", "{}")
try:
    DEFAULT_HEADERS: dict = json.loads(_raw_default_headers)
except json.JSONDecodeError:
    DEFAULT_HEADERS = {}

# ─── Helpers ─────────────────────────────────────────────────────────────────

def _check_host(url: str) -> None:
    """Raise if the URL's hostname is not in the allowlist (when allowlist is set)."""
    if not ALLOWED_HOSTS:
        return
    hostname = urlparse(url).hostname or ""
    if hostname not in ALLOWED_HOSTS:
        raise ValueError(
            f"Host '{hostname}' is not in HTTP_ALLOWED_HOSTS. "
            f"Allowed: {', '.join(sorted(ALLOWED_HOSTS))}"
        )

def _merge_headers(extra: dict | None) -> dict:
    h = {"Content-Type": "application/json", "Accept": "application/json"}
    h.update(DEFAULT_HEADERS)
    if extra:
        h.update(extra)
    return h

def _fmt_response(resp: requests.Response, elapsed: float) -> str:
    """Format a requests.Response into a readable string for Claude."""
    ct = resp.headers.get("Content-Type", "")
    body_bytes = resp.content[:MAX_RESPONSE_BYTES]
    truncated  = len(resp.content) > MAX_RESPONSE_BYTES

    # Try to pretty-print JSON bodies
    body_str: str
    if "json" in ct:
        try:
            body_str = json.dumps(resp.json(), indent=2)
        except Exception:
            body_str = body_bytes.decode("utf-8", errors="replace")
    else:
        body_str = body_bytes.decode("utf-8", errors="replace")

    lines = [
        f"Status  : {resp.status_code} {resp.reason}",
        f"Elapsed : {elapsed:.2f}s",
        f"URL     : {resp.url}",
        f"Headers : {dict(resp.headers)}",
        "─" * 50,
        body_str,
    ]
    if truncated:
        lines.append(f"\n… [truncated — response was {len(resp.content):,} bytes, showing first {MAX_RESPONSE_BYTES:,}]")
    return "\n".join(lines)

def _do_request(
    method: str,
    url: str,
    *,
    headers: dict | None = None,
    params: dict | None = None,
    body: Any = None,
    timeout: int = DEFAULT_TIMEOUT,
    auth: tuple | None = None,
) -> tuple[requests.Response, float]:
    _check_host(url)
    merged_headers = _merge_headers(headers)
    t0 = time.monotonic()
    resp = requests.request(
        method.upper(),
        url,
        headers=merged_headers,
        params=params or {},
        json=body,          # body is already a dict/list; None → no body
        timeout=timeout,
        auth=HTTPBasicAuth(*auth) if auth else None,
        allow_redirects=True,
    )
    return resp, time.monotonic() - t0

def _fmt(obj: Any) -> str:
    return json.dumps(obj, indent=2, default=str)

# ─── MCP Server ──────────────────────────────────────────────────────────────

server = Server("http-mcp")

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [

        # ── Core request tools ────────────────────────────────────────────

        Tool(
            name="http_get",
            description=(
                "Make an HTTP GET request to any URL. Returns status code, response headers, "
                "and body. Use for fetching data from REST APIs, health checks, or any GET endpoint."
            ),
            inputSchema={
                "type": "object",
                "required": ["url"],
                "properties": {
                    "url":     {"type": "string", "description": "Full URL including scheme (https://...)"},
                    "headers": {"type": "object", "description": "Extra request headers (key-value pairs)", "default": {}},
                    "params":  {"type": "object", "description": "Query string parameters", "default": {}},
                    "timeout": {"type": "integer", "description": "Timeout in seconds", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        Tool(
            name="http_post",
            description=(
                "Make an HTTP POST request with a JSON body. Returns status code and response. "
                "Use to create resources, submit forms, or trigger webhooks."
            ),
            inputSchema={
                "type": "object",
                "required": ["url"],
                "properties": {
                    "url":     {"type": "string"},
                    "body":    {"type": "object", "description": "Request body (sent as JSON)", "default": {}},
                    "headers": {"type": "object", "default": {}},
                    "params":  {"type": "object", "default": {}},
                    "timeout": {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        Tool(
            name="http_put",
            description="Make an HTTP PUT request with a JSON body. Use to replace/update a full resource.",
            inputSchema={
                "type": "object",
                "required": ["url"],
                "properties": {
                    "url":     {"type": "string"},
                    "body":    {"type": "object", "default": {}},
                    "headers": {"type": "object", "default": {}},
                    "timeout": {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        Tool(
            name="http_patch",
            description="Make an HTTP PATCH request with a JSON body. Use for partial resource updates.",
            inputSchema={
                "type": "object",
                "required": ["url"],
                "properties": {
                    "url":     {"type": "string"},
                    "body":    {"type": "object", "default": {}},
                    "headers": {"type": "object", "default": {}},
                    "timeout": {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        Tool(
            name="http_delete",
            description="Make an HTTP DELETE request. Use to remove/delete a resource via REST API.",
            inputSchema={
                "type": "object",
                "required": ["url"],
                "properties": {
                    "url":     {"type": "string"},
                    "headers": {"type": "object", "default": {}},
                    "timeout": {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        # ── Convenience tools ─────────────────────────────────────────────

        Tool(
            name="http_get_json",
            description=(
                "GET a URL and return only the parsed JSON body as a formatted object. "
                "Cleaner than http_get when you just need the data, not the headers."
            ),
            inputSchema={
                "type": "object",
                "required": ["url"],
                "properties": {
                    "url":        {"type": "string"},
                    "headers":    {"type": "object", "default": {}},
                    "params":     {"type": "object", "default": {}},
                    "json_path":  {
                        "type": "string",
                        "description": "Optional dot-notation path to extract a nested field, e.g. 'data.items'",
                        "default": ""
                    },
                    "timeout":    {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        Tool(
            name="http_post_json",
            description=(
                "POST a JSON body and return only the parsed JSON response. "
                "Cleaner for API calls where you just need the response data."
            ),
            inputSchema={
                "type": "object",
                "required": ["url"],
                "properties": {
                    "url":     {"type": "string"},
                    "body":    {"type": "object", "default": {}},
                    "headers": {"type": "object", "default": {}},
                    "timeout": {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        # ── Auth helpers ──────────────────────────────────────────────────

        Tool(
            name="http_get_with_auth",
            description=(
                "GET a URL with authentication. Supports Bearer token or Basic auth. "
                "Use for protected APIs (GitHub, Jira, internal APIs, etc.)."
            ),
            inputSchema={
                "type": "object",
                "required": ["url", "auth_type"],
                "properties": {
                    "url":          {"type": "string"},
                    "auth_type":    {"type": "string", "enum": ["bearer", "basic"], "description": "bearer = Authorization: Bearer <token>, basic = username:password"},
                    "token":        {"type": "string", "description": "Bearer token (required when auth_type=bearer)"},
                    "username":     {"type": "string", "description": "Username (required when auth_type=basic)"},
                    "password":     {"type": "string", "description": "Password (required when auth_type=basic)"},
                    "params":       {"type": "object", "default": {}},
                    "extra_headers":{"type": "object", "default": {}},
                    "timeout":      {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        Tool(
            name="http_post_with_auth",
            description=(
                "POST a JSON body with authentication (Bearer or Basic). "
                "Use for creating/triggering resources on protected APIs."
            ),
            inputSchema={
                "type": "object",
                "required": ["url", "auth_type"],
                "properties": {
                    "url":          {"type": "string"},
                    "auth_type":    {"type": "string", "enum": ["bearer", "basic"]},
                    "token":        {"type": "string"},
                    "username":     {"type": "string"},
                    "password":     {"type": "string"},
                    "body":         {"type": "object", "default": {}},
                    "extra_headers":{"type": "object", "default": {}},
                    "timeout":      {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),

        # ── Polling ───────────────────────────────────────────────────────

        Tool(
            name="http_poll_until",
            description=(
                "Repeatedly GET a URL until the response body contains an expected value "
                "or a timeout is reached. Use to wait for async jobs, pipeline completions, "
                "or status changes in external systems."
            ),
            inputSchema={
                "type": "object",
                "required": ["url", "expected_value"],
                "properties": {
                    "url":             {"type": "string"},
                    "expected_value":  {"type": "string", "description": "String to look for in the response body"},
                    "json_path":       {"type": "string", "description": "Optional dot-notation path to check, e.g. 'status'", "default": ""},
                    "headers":         {"type": "object", "default": {}},
                    "poll_interval_seconds": {"type": "integer", "default": 10},
                    "timeout_seconds": {"type": "integer", "default": 300},
                    "bearer_token":    {"type": "string", "default": ""},
                },
            },
        ),

        # ── Assertion ─────────────────────────────────────────────────────

        Tool(
            name="http_assert_status",
            description=(
                "GET a URL and assert it returns a specific HTTP status code. "
                "Returns PASS or FAIL. Use for API health checks and integration tests."
            ),
            inputSchema={
                "type": "object",
                "required": ["url", "expected_status"],
                "properties": {
                    "url":             {"type": "string"},
                    "expected_status": {"type": "integer", "description": "Expected HTTP status code, e.g. 200"},
                    "headers":         {"type": "object", "default": {}},
                    "bearer_token":    {"type": "string", "default": ""},
                    "timeout":         {"type": "integer", "default": DEFAULT_TIMEOUT},
                },
            },
        ),
    ]


# ─── Tool dispatch ────────────────────────────────────────────────────────────

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await asyncio.get_event_loop().run_in_executor(
            None, _dispatch_sync, name, arguments
        )
        return [TextContent(type="text", text=result)]
    except Exception as exc:
        return [TextContent(type="text", text=f"❌ {type(exc).__name__}: {exc}")]


def _dispatch_sync(name: str, a: dict) -> str:
    """All tools run synchronously (requests is blocking) — called from executor."""

    # ── http_get ─────────────────────────────────────────────────────────
    if name == "http_get":
        resp, elapsed = _do_request(
            "GET", a["url"],
            headers=a.get("headers"),
            params=a.get("params"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        return _fmt_response(resp, elapsed)

    # ── http_post ────────────────────────────────────────────────────────
    if name == "http_post":
        resp, elapsed = _do_request(
            "POST", a["url"],
            headers=a.get("headers"),
            params=a.get("params"),
            body=a.get("body"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        return _fmt_response(resp, elapsed)

    # ── http_put ─────────────────────────────────────────────────────────
    if name == "http_put":
        resp, elapsed = _do_request(
            "PUT", a["url"],
            headers=a.get("headers"),
            body=a.get("body"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        return _fmt_response(resp, elapsed)

    # ── http_patch ───────────────────────────────────────────────────────
    if name == "http_patch":
        resp, elapsed = _do_request(
            "PATCH", a["url"],
            headers=a.get("headers"),
            body=a.get("body"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        return _fmt_response(resp, elapsed)

    # ── http_delete ──────────────────────────────────────────────────────
    if name == "http_delete":
        resp, elapsed = _do_request(
            "DELETE", a["url"],
            headers=a.get("headers"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        return _fmt_response(resp, elapsed)

    # ── http_get_json ─────────────────────────────────────────────────────
    if name == "http_get_json":
        resp, elapsed = _do_request(
            "GET", a["url"],
            headers=a.get("headers"),
            params=a.get("params"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        resp.raise_for_status()
        data = resp.json()
        # Optional dot-notation extraction
        path = a.get("json_path", "").strip()
        if path:
            for key in path.split("."):
                if isinstance(data, dict):
                    data = data.get(key)
                elif isinstance(data, list) and key.isdigit():
                    data = data[int(key)]
                else:
                    data = None
                if data is None:
                    break
            return f"json_path '{path}' → {_fmt(data)}"
        return _fmt(data)

    # ── http_post_json ────────────────────────────────────────────────────
    if name == "http_post_json":
        resp, elapsed = _do_request(
            "POST", a["url"],
            headers=a.get("headers"),
            body=a.get("body"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        resp.raise_for_status()
        return _fmt(resp.json())

    # ── http_get_with_auth ────────────────────────────────────────────────
    if name == "http_get_with_auth":
        headers, auth = _build_auth(a)
        resp, elapsed = _do_request(
            "GET", a["url"],
            headers=headers,
            params=a.get("params"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
            auth=auth,
        )
        return _fmt_response(resp, elapsed)

    # ── http_post_with_auth ───────────────────────────────────────────────
    if name == "http_post_with_auth":
        headers, auth = _build_auth(a)
        resp, elapsed = _do_request(
            "POST", a["url"],
            headers=headers,
            body=a.get("body"),
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
            auth=auth,
        )
        return _fmt_response(resp, elapsed)

    # ── http_poll_until ───────────────────────────────────────────────────
    if name == "http_poll_until":
        url             = a["url"]
        expected        = a["expected_value"]
        json_path       = a.get("json_path", "").strip()
        interval        = a.get("poll_interval_seconds", 10)
        timeout_secs    = a.get("timeout_seconds", 300)
        token           = a.get("bearer_token", "")
        extra_headers   = {"Authorization": f"Bearer {token}"} if token else {}

        deadline = time.monotonic() + timeout_secs
        attempt  = 0

        while time.monotonic() < deadline:
            attempt += 1
            resp, elapsed = _do_request(
                "GET", url,
                headers=extra_headers,
                timeout=DEFAULT_TIMEOUT,
            )
            # Extract the value to check
            check_value: str
            if json_path and "json" in resp.headers.get("Content-Type", ""):
                try:
                    data = resp.json()
                    for key in json_path.split("."):
                        data = data.get(key) if isinstance(data, dict) else None
                    check_value = str(data)
                except Exception:
                    check_value = resp.text
            else:
                check_value = resp.text

            if expected in check_value:
                return (
                    f"✅ PASS — found '{expected}' after {attempt} attempt(s)\n"
                    f"Final value: {check_value[:500]}\n"
                    f"Status: {resp.status_code}"
                )

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(interval, remaining))

        return (
            f"❌ TIMEOUT — '{expected}' not found after {attempt} attempt(s) "
            f"({timeout_secs}s). Last response: {resp.text[:300]}"
        )

    # ── http_assert_status ────────────────────────────────────────────────
    if name == "http_assert_status":
        token   = a.get("bearer_token", "")
        headers = {**a.get("headers", {})}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        resp, elapsed = _do_request(
            "GET", a["url"],
            headers=headers,
            timeout=a.get("timeout", DEFAULT_TIMEOUT),
        )
        expected = a["expected_status"]
        actual   = resp.status_code
        passed   = actual == expected
        return (
            f"Assertion: GET {a['url']} returns {expected}\n"
            f"Actual   : {actual} {resp.reason}\n"
            f"Elapsed  : {elapsed:.2f}s\n"
            f"Result   : {'✅ PASS' if passed else '❌ FAIL'}"
        )

    return f"Unknown tool: {name}"


def _build_auth(a: dict) -> tuple[dict, tuple | None]:
    """Return (extra_headers, basic_auth_tuple) from auth arguments."""
    auth_type     = a.get("auth_type", "bearer")
    extra_headers = dict(a.get("extra_headers", {}))
    auth: tuple | None = None

    if auth_type == "bearer":
        token = a.get("token", "")
        if token:
            extra_headers["Authorization"] = f"Bearer {token}"
    elif auth_type == "basic":
        username = a.get("username", "")
        password = a.get("password", "")
        if username:
            auth = (username, password)

    return extra_headers, auth


# ─── Entry point ─────────────────────────────────────────────────────────────

async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream, write_stream,
            server.create_initialization_options()
        )

if __name__ == "__main__":
    asyncio.run(main())
