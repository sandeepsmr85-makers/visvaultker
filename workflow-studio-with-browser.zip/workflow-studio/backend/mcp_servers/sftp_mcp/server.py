"""
mcp_servers/sftp_mcp/server.py
────────────────────────────────
SFTP MCP Server (paramiko-based)

Cross-platform SFTP/SCP file transfer and remote SSH command execution.
Works on Windows, macOS, and Linux — no WinSCP installation required.

Tools exposed:
  Connection    : sftp_test_connection
  Browse        : sftp_list_dir, sftp_find_files, sftp_get_file_info
  Transfer Up   : sftp_upload_file, sftp_upload_text
  Transfer Down : sftp_download_file, sftp_read_file
  Manage        : sftp_mkdir, sftp_delete_file, sftp_rename, sftp_copy_file
  Assert        : sftp_assert_file_exists, sftp_assert_dir_has_files
  Remote exec   : sftp_run_command

Environment variables (set in backend/.env):
  SFTP_HOST                  — hostname or IP of the SFTP server
  SFTP_PORT                  — port (default: 22)
  SFTP_USERNAME              — login username
  SFTP_PASSWORD              — password (leave blank if using key auth)
  SFTP_PRIVATE_KEY_PATH      — path to private key file, e.g. ~/.ssh/id_rsa
  SFTP_PRIVATE_KEY_PASSPHRASE— passphrase for encrypted private key (optional)
  SFTP_DEFAULT_REMOTE_DIR    — default remote working directory (default: /home/<user>)
  SFTP_DEFAULT_LOCAL_DIR     — local directory for downloads (default: ./sftp_downloads)
  SFTP_KNOWN_HOSTS_PATH      — path to known_hosts file (default: ~/.ssh/known_hosts)
  SFTP_AUTO_ADD_HOST_KEY     — set to 'true' to auto-accept unknown host keys (dev only)
  SFTP_CONNECTION_TIMEOUT    — connect timeout in seconds (default: 15)
"""

import asyncio
import fnmatch
import json
import os
import re
import stat
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import paramiko
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from config.settings import (
    SFTP_HOST, SFTP_PORT, SFTP_USERNAME, SFTP_PASSWORD,
    SFTP_PRIVATE_KEY_PATH, SFTP_PRIVATE_KEY_PASSPHRASE,
    SFTP_DEFAULT_REMOTE_DIR, SFTP_DEFAULT_LOCAL_DIR,
    SFTP_KNOWN_HOSTS_PATH, SFTP_AUTO_ADD_HOST_KEY,
    SFTP_CONNECTION_TIMEOUT,
)

# ─── Connection helpers ───────────────────────────────────────────────────────

def _make_ssh() -> paramiko.SSHClient:
    """Create and return an authenticated SSHClient."""
    ssh = paramiko.SSHClient()

    if SFTP_AUTO_ADD_HOST_KEY:
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    else:
        ssh.set_missing_host_key_policy(paramiko.RejectPolicy())
        known = Path(SFTP_KNOWN_HOSTS_PATH).expanduser()
        if known.exists():
            ssh.load_host_keys(str(known))

    connect_kwargs: dict[str, Any] = {
        "hostname": SFTP_HOST,
        "port":     SFTP_PORT,
        "username": SFTP_USERNAME,
        "timeout":  SFTP_CONNECTION_TIMEOUT,
    }

    key_path = Path(SFTP_PRIVATE_KEY_PATH).expanduser() if SFTP_PRIVATE_KEY_PATH else None

    if key_path and key_path.exists():
        # Key-based auth
        pkey = paramiko.RSAKey.from_private_key_file(
            str(key_path),
            password=SFTP_PRIVATE_KEY_PASSPHRASE or None,
        )
        connect_kwargs["pkey"] = pkey
    elif SFTP_PASSWORD:
        connect_kwargs["password"] = SFTP_PASSWORD
    else:
        raise ValueError(
            "No auth method available. Set SFTP_PASSWORD or SFTP_PRIVATE_KEY_PATH in .env"
        )

    ssh.connect(**connect_kwargs)
    return ssh


def _resolve_remote(path: str | None) -> str:
    """Return path, falling back to SFTP_DEFAULT_REMOTE_DIR."""
    return path or SFTP_DEFAULT_REMOTE_DIR or f"/home/{SFTP_USERNAME}"


def _resolve_local(path: str | None, filename: str) -> str:
    """Return local file path, placing in SFTP_DEFAULT_LOCAL_DIR if only a dir is given."""
    local_dir = Path(SFTP_DEFAULT_LOCAL_DIR)
    local_dir.mkdir(parents=True, exist_ok=True)
    if path:
        p = Path(path)
        if p.suffix:          # has extension → treat as full path
            p.parent.mkdir(parents=True, exist_ok=True)
            return str(p)
        else:                 # directory-like → place file inside it
            p.mkdir(parents=True, exist_ok=True)
            return str(p / filename)
    return str(local_dir / filename)


def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _fmt_attr(attr: paramiko.SFTPAttributes, name: str) -> dict:
    mtime = datetime.fromtimestamp(attr.st_mtime or 0, tz=timezone.utc).isoformat()
    is_dir = stat.S_ISDIR(attr.st_mode or 0)
    return {
        "name":          name,
        "type":          "directory" if is_dir else "file",
        "size":          _fmt_size(attr.st_size or 0) if not is_dir else "-",
        "size_bytes":    attr.st_size or 0,
        "last_modified": mtime,
        "permissions":   oct(stat.S_IMODE(attr.st_mode or 0)),
    }


# ─── MCP server ───────────────────────────────────────────────────────────────

server = Server("sftp-mcp")


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [

        # ── Connection ────────────────────────────────────────────────────
        Tool(
            name="sftp_test_connection",
            description=(
                "Test the SFTP connection using the configured credentials. "
                "Returns server banner, home directory, and auth method used. "
                "Run this first to verify connectivity before other operations."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),

        # ── Browse ────────────────────────────────────────────────────────
        Tool(
            name="sftp_list_dir",
            description=(
                "List files and directories in a remote directory. "
                "Returns name, type, size, permissions, and last-modified for each entry."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "remote_path": {"type": "string", "description": "Remote directory path. Defaults to SFTP_DEFAULT_REMOTE_DIR."},
                    "pattern":     {"type": "string", "description": "Optional glob filter, e.g. '*.csv'", "default": ""},
                    "show_hidden": {"type": "boolean", "description": "Include dotfiles", "default": False},
                },
            },
        ),

        Tool(
            name="sftp_find_files",
            description=(
                "Recursively search a remote directory for files matching a pattern. "
                "Returns matching file paths with sizes and modification times."
            ),
            inputSchema={
                "type": "object",
                "required": ["pattern"],
                "properties": {
                    "pattern":     {"type": "string", "description": "Glob pattern, e.g. '*.log' or 'report_*.csv'"},
                    "remote_path": {"type": "string", "description": "Remote root to search from"},
                    "max_depth":   {"type": "integer", "description": "Max recursion depth", "default": 5},
                    "max_results": {"type": "integer", "description": "Max files to return", "default": 50},
                },
            },
        ),

        Tool(
            name="sftp_get_file_info",
            description="Get metadata for a specific remote file: size, permissions, last modified.",
            inputSchema={
                "type": "object",
                "required": ["remote_path"],
                "properties": {
                    "remote_path": {"type": "string", "description": "Full path to the remote file or directory"},
                },
            },
        ),

        # ── Upload ────────────────────────────────────────────────────────
        Tool(
            name="sftp_upload_file",
            description=(
                "Upload a local file to the remote SFTP server. "
                "Returns bytes transferred and elapsed time."
            ),
            inputSchema={
                "type": "object",
                "required": ["local_path", "remote_path"],
                "properties": {
                    "local_path":  {"type": "string", "description": "Full path to the local file to upload"},
                    "remote_path": {"type": "string", "description": "Full remote destination path (including filename)"},
                    "overwrite":   {"type": "boolean", "description": "Overwrite if file already exists", "default": True},
                },
            },
        ),

        Tool(
            name="sftp_upload_text",
            description=(
                "Write a text or JSON string directly to a remote file — no local file needed. "
                "Useful for uploading config files, CSVs, or JSON payloads generated by earlier workflow steps."
            ),
            inputSchema={
                "type": "object",
                "required": ["content", "remote_path"],
                "properties": {
                    "content":     {"type": "string", "description": "Text content to write"},
                    "remote_path": {"type": "string", "description": "Full remote destination path"},
                    "encoding":    {"type": "string", "default": "utf-8"},
                },
            },
        ),

        # ── Download ──────────────────────────────────────────────────────
        Tool(
            name="sftp_download_file",
            description=(
                "Download a remote file to the local machine. "
                "Returns local path, file size, and elapsed time."
            ),
            inputSchema={
                "type": "object",
                "required": ["remote_path"],
                "properties": {
                    "remote_path": {"type": "string", "description": "Full path to the remote file"},
                    "local_path":  {"type": "string", "description": "Local destination path or directory. Defaults to SFTP_DEFAULT_LOCAL_DIR/<filename>."},
                },
            },
        ),

        Tool(
            name="sftp_read_file",
            description=(
                "Read and return the text content of a remote file without saving it locally. "
                "Ideal for reading logs, CSVs, or config files in a workflow."
            ),
            inputSchema={
                "type": "object",
                "required": ["remote_path"],
                "properties": {
                    "remote_path": {"type": "string"},
                    "max_bytes":   {"type": "integer", "description": "Max bytes to read", "default": 102400},
                    "encoding":    {"type": "string", "default": "utf-8"},
                },
            },
        ),

        # ── Manage ────────────────────────────────────────────────────────
        Tool(
            name="sftp_mkdir",
            description="Create a directory (and any missing parents) on the remote server.",
            inputSchema={
                "type": "object",
                "required": ["remote_path"],
                "properties": {
                    "remote_path": {"type": "string", "description": "Remote directory path to create"},
                    "mode":        {"type": "integer", "description": "Permission mode (octal), e.g. 755", "default": 755},
                },
            },
        ),

        Tool(
            name="sftp_delete_file",
            description="Delete a file from the remote server. Does not delete directories.",
            inputSchema={
                "type": "object",
                "required": ["remote_path"],
                "properties": {
                    "remote_path": {"type": "string"},
                    "confirm":     {"type": "boolean", "description": "Must be true to proceed", "default": False},
                },
            },
        ),

        Tool(
            name="sftp_rename",
            description="Rename or move a file or directory on the remote server.",
            inputSchema={
                "type": "object",
                "required": ["remote_src", "remote_dst"],
                "properties": {
                    "remote_src": {"type": "string", "description": "Current remote path"},
                    "remote_dst": {"type": "string", "description": "New remote path"},
                },
            },
        ),

        Tool(
            name="sftp_copy_file",
            description=(
                "Copy a remote file to another remote location. "
                "Implemented as download-then-upload since SFTP has no native copy."
            ),
            inputSchema={
                "type": "object",
                "required": ["remote_src", "remote_dst"],
                "properties": {
                    "remote_src": {"type": "string"},
                    "remote_dst": {"type": "string"},
                },
            },
        ),

        # ── Assertions ────────────────────────────────────────────────────
        Tool(
            name="sftp_assert_file_exists",
            description=(
                "Assert that a specific file exists on the remote server. "
                "Returns PASS or FAIL with file details."
            ),
            inputSchema={
                "type": "object",
                "required": ["remote_path"],
                "properties": {
                    "remote_path":    {"type": "string"},
                    "min_size_bytes": {"type": "integer", "description": "Optional minimum file size check", "default": 0},
                },
            },
        ),

        Tool(
            name="sftp_assert_dir_has_files",
            description=(
                "Assert that a remote directory contains at least N files matching an optional pattern. "
                "Returns PASS or FAIL with actual file count."
            ),
            inputSchema={
                "type": "object",
                "required": ["remote_path"],
                "properties": {
                    "remote_path": {"type": "string"},
                    "min_count":   {"type": "integer", "default": 1},
                    "pattern":     {"type": "string", "description": "Optional glob filter, e.g. '*.csv'", "default": ""},
                },
            },
        ),

        # ── Remote execution ──────────────────────────────────────────────
        Tool(
            name="sftp_run_command",
            description=(
                "Execute a shell command on the remote server over SSH and return stdout/stderr. "
                "Use for triggering scripts, checking disk space, or verifying remote state."
            ),
            inputSchema={
                "type": "object",
                "required": ["command"],
                "properties": {
                    "command": {"type": "string", "description": "Shell command to execute"},
                    "timeout": {"type": "integer", "description": "Command timeout in seconds", "default": 30},
                },
            },
        ),
    ]


# ─── Tool dispatch ─────────────────────────────────────────────────────────────

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        loop   = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, _dispatch_sync, name, arguments)
        return [TextContent(type="text", text=result)]
    except Exception as exc:
        return [TextContent(type="text", text=f"❌ {type(exc).__name__}: {exc}")]


def _dispatch_sync(name: str, a: dict) -> str:

    # ── sftp_test_connection ──────────────────────────────────────────────
    if name == "sftp_test_connection":
        ssh = _make_ssh()
        try:
            transport   = ssh.get_transport()
            banner      = str(transport.remote_version) if transport else "unknown"
            auth_method = "private key" if (SFTP_PRIVATE_KEY_PATH and Path(SFTP_PRIVATE_KEY_PATH).expanduser().exists()) else "password"
            sftp        = ssh.open_sftp()
            home        = sftp.normalize(".")
            sftp.close()
            return (
                f"✅ Connection successful\n"
                f"Host        : {SFTP_HOST}:{SFTP_PORT}\n"
                f"Username    : {SFTP_USERNAME}\n"
                f"Auth method : {auth_method}\n"
                f"Server      : {banner}\n"
                f"Remote home : {home}"
            )
        finally:
            ssh.close()

    # ── sftp_list_dir ─────────────────────────────────────────────────────
    if name == "sftp_list_dir":
        remote_path  = _resolve_remote(a.get("remote_path"))
        pattern      = a.get("pattern", "")
        show_hidden  = a.get("show_hidden", False)
        ssh = _make_ssh()
        try:
            sftp    = ssh.open_sftp()
            entries = sftp.listdir_attr(remote_path)
            sftp.close()
        finally:
            ssh.close()

        results = []
        for attr in sorted(entries, key=lambda x: x.filename):
            name_ = attr.filename
            if not show_hidden and name_.startswith("."):
                continue
            if pattern and not fnmatch.fnmatch(name_, pattern):
                continue
            results.append(_fmt_attr(attr, name_))

        return (
            f"{len(results)} item(s) in {remote_path}"
            + (f" matching '{pattern}'" if pattern else "")
            + f":\n\n{json.dumps(results, indent=2)}"
        )

    # ── sftp_find_files ───────────────────────────────────────────────────
    if name == "sftp_find_files":
        pattern      = a["pattern"]
        remote_root  = _resolve_remote(a.get("remote_path"))
        max_depth    = a.get("max_depth", 5)
        max_results  = a.get("max_results", 50)
        ssh = _make_ssh()
        try:
            sftp    = ssh.open_sftp()
            matches = []

            def _walk(path: str, depth: int) -> None:
                if depth > max_depth or len(matches) >= max_results:
                    return
                try:
                    for attr in sftp.listdir_attr(path):
                        if len(matches) >= max_results:
                            return
                        full = f"{path.rstrip('/')}/{attr.filename}"
                        if stat.S_ISDIR(attr.st_mode or 0):
                            _walk(full, depth + 1)
                        elif fnmatch.fnmatch(attr.filename, pattern):
                            matches.append(_fmt_attr(attr, full))
                except PermissionError:
                    pass

            _walk(remote_root, 0)
            sftp.close()
        finally:
            ssh.close()

        return (
            f"Found {len(matches)} file(s) matching '{pattern}' under {remote_root}:\n\n"
            + json.dumps(matches, indent=2)
        )

    # ── sftp_get_file_info ────────────────────────────────────────────────
    if name == "sftp_get_file_info":
        remote_path = a["remote_path"]
        ssh = _make_ssh()
        try:
            sftp  = ssh.open_sftp()
            attr  = sftp.stat(remote_path)
            sftp.close()
        finally:
            ssh.close()
        info = _fmt_attr(attr, remote_path)
        return json.dumps(info, indent=2)

    # ── sftp_upload_file ──────────────────────────────────────────────────
    if name == "sftp_upload_file":
        local_path  = a["local_path"]
        remote_path = a["remote_path"]
        overwrite   = a.get("overwrite", True)
        local       = Path(local_path)
        if not local.exists():
            raise FileNotFoundError(f"Local file not found: {local_path}")
        ssh = _make_ssh()
        try:
            sftp = ssh.open_sftp()
            if not overwrite:
                try:
                    sftp.stat(remote_path)
                    sftp.close()
                    return f"⚠️  Skipped — {remote_path} already exists (overwrite=false)"
                except FileNotFoundError:
                    pass
            t0 = time.monotonic()
            sftp.put(str(local), remote_path)
            elapsed = time.monotonic() - t0
            size    = local.stat().st_size
            sftp.close()
        finally:
            ssh.close()
        return (
            f"✅ Uploaded {local_path} → {SFTP_HOST}:{remote_path}\n"
            f"Size    : {_fmt_size(size)}\n"
            f"Elapsed : {elapsed:.2f}s\n"
            f"Speed   : {_fmt_size(int(size/elapsed))}/s"
        )

    # ── sftp_upload_text ──────────────────────────────────────────────────
    if name == "sftp_upload_text":
        content     = a["content"]
        remote_path = a["remote_path"]
        encoding    = a.get("encoding", "utf-8")
        data        = content.encode(encoding)
        ssh = _make_ssh()
        try:
            sftp = ssh.open_sftp()
            import io
            sftp.putfo(io.BytesIO(data), remote_path)
            sftp.close()
        finally:
            ssh.close()
        return (
            f"✅ Written {len(data):,} bytes to {SFTP_HOST}:{remote_path}"
        )

    # ── sftp_download_file ────────────────────────────────────────────────
    if name == "sftp_download_file":
        remote_path = a["remote_path"]
        filename    = remote_path.split("/")[-1]
        local_path  = _resolve_local(a.get("local_path"), filename)
        ssh = _make_ssh()
        try:
            sftp = ssh.open_sftp()
            t0   = time.monotonic()
            sftp.get(remote_path, local_path)
            elapsed = time.monotonic() - t0
            size    = Path(local_path).stat().st_size
            sftp.close()
        finally:
            ssh.close()
        return (
            f"✅ Downloaded {SFTP_HOST}:{remote_path} → {local_path}\n"
            f"Size    : {_fmt_size(size)}\n"
            f"Elapsed : {elapsed:.2f}s\n"
            f"Speed   : {_fmt_size(int(size / max(elapsed, 0.001)))}/s"
        )

    # ── sftp_read_file ────────────────────────────────────────────────────
    if name == "sftp_read_file":
        remote_path = a["remote_path"]
        max_bytes   = a.get("max_bytes", 102400)
        encoding    = a.get("encoding", "utf-8")
        ssh = _make_ssh()
        try:
            sftp        = ssh.open_sftp()
            attr        = sftp.stat(remote_path)
            total_bytes = attr.st_size or 0
            with sftp.open(remote_path, "rb") as f:
                raw = f.read(max_bytes)
            sftp.close()
        finally:
            ssh.close()
        content   = raw.decode(encoding, errors="replace")
        truncated = total_bytes > max_bytes
        header    = (
            f"File    : {SFTP_HOST}:{remote_path}\n"
            f"Size    : {_fmt_size(total_bytes)}\n"
            + (f"⚠️  Showing first {max_bytes:,} of {total_bytes:,} bytes\n" if truncated else "")
            + "─" * 50 + "\n"
        )
        return header + content

    # ── sftp_mkdir ────────────────────────────────────────────────────────
    if name == "sftp_mkdir":
        remote_path = a["remote_path"]
        mode        = int(str(a.get("mode", 755)), 8)
        ssh = _make_ssh()
        try:
            sftp  = ssh.open_sftp()
            parts = remote_path.replace("\\", "/").split("/")
            current = ""
            for part in parts:
                if not part:
                    current = "/"
                    continue
                current = f"{current}/{part}" if current != "/" else f"/{part}"
                try:
                    sftp.stat(current)
                except FileNotFoundError:
                    sftp.mkdir(current, mode)
            sftp.close()
        finally:
            ssh.close()
        return f"✅ Directory created: {SFTP_HOST}:{remote_path}"

    # ── sftp_delete_file ──────────────────────────────────────────────────
    if name == "sftp_delete_file":
        remote_path = a["remote_path"]
        if not a.get("confirm", False):
            return "⚠️  Deletion requires confirm=true. Set confirm=true to proceed."
        ssh = _make_ssh()
        try:
            sftp = ssh.open_sftp()
            sftp.remove(remote_path)
            sftp.close()
        finally:
            ssh.close()
        return f"✅ Deleted: {SFTP_HOST}:{remote_path}"

    # ── sftp_rename ───────────────────────────────────────────────────────
    if name == "sftp_rename":
        src = a["remote_src"]
        dst = a["remote_dst"]
        ssh = _make_ssh()
        try:
            sftp = ssh.open_sftp()
            sftp.rename(src, dst)
            sftp.close()
        finally:
            ssh.close()
        return f"✅ Renamed:\n  FROM: {SFTP_HOST}:{src}\n  TO  : {SFTP_HOST}:{dst}"

    # ── sftp_copy_file ────────────────────────────────────────────────────
    if name == "sftp_copy_file":
        src = a["remote_src"]
        dst = a["remote_dst"]
        ssh = _make_ssh()
        try:
            sftp  = ssh.open_sftp()
            # Read source into memory then write to destination
            with sftp.open(src, "rb") as f:
                data = f.read()
            import io
            sftp.putfo(io.BytesIO(data), dst)
            sftp.close()
        finally:
            ssh.close()
        return (
            f"✅ Copied:\n"
            f"  FROM: {SFTP_HOST}:{src}\n"
            f"  TO  : {SFTP_HOST}:{dst}\n"
            f"  Size: {_fmt_size(len(data))}"
        )

    # ── sftp_assert_file_exists ───────────────────────────────────────────
    if name == "sftp_assert_file_exists":
        remote_path    = a["remote_path"]
        min_size_bytes = a.get("min_size_bytes", 0)
        ssh = _make_ssh()
        try:
            sftp = ssh.open_sftp()
            try:
                attr = sftp.stat(remote_path)
                exists = True
            except FileNotFoundError:
                exists = False
                attr   = None
            sftp.close()
        finally:
            ssh.close()

        if not exists:
            return (
                f"Assertion: {remote_path} exists\n"
                f"Result   : ❌ FAIL — file not found"
            )
        size   = attr.st_size or 0
        passed = size >= min_size_bytes
        return (
            f"Assertion: {remote_path} exists"
            + (f" and size >= {_fmt_size(min_size_bytes)}" if min_size_bytes else "")
            + f"\nSize     : {_fmt_size(size)}\n"
            f"Result   : {'✅ PASS' if passed else f'❌ FAIL — size {_fmt_size(size)} < {_fmt_size(min_size_bytes)}'}"
        )

    # ── sftp_assert_dir_has_files ─────────────────────────────────────────
    if name == "sftp_assert_dir_has_files":
        remote_path = a["remote_path"]
        min_count   = a.get("min_count", 1)
        pattern     = a.get("pattern", "")
        ssh = _make_ssh()
        try:
            sftp    = ssh.open_sftp()
            entries = sftp.listdir_attr(remote_path)
            sftp.close()
        finally:
            ssh.close()

        files = [
            e for e in entries
            if not stat.S_ISDIR(e.st_mode or 0)
            and (not pattern or fnmatch.fnmatch(e.filename, pattern))
        ]
        count  = len(files)
        passed = count >= min_count
        return (
            f"Assertion: {remote_path} has >= {min_count} file(s)"
            + (f" matching '{pattern}'" if pattern else "")
            + f"\nFound    : {count} file(s)\n"
            f"Result   : {'✅ PASS' if passed else '❌ FAIL'}"
        )

    # ── sftp_run_command ──────────────────────────────────────────────────
    if name == "sftp_run_command":
        command = a["command"]
        timeout = a.get("timeout", 30)
        ssh = _make_ssh()
        try:
            t0 = time.monotonic()
            _, stdout, stderr = ssh.exec_command(command, timeout=timeout)
            exit_code  = stdout.channel.recv_exit_status()
            out        = stdout.read().decode("utf-8", errors="replace")
            err        = stderr.read().decode("utf-8", errors="replace")
            elapsed    = time.monotonic() - t0
        finally:
            ssh.close()

        status = "✅" if exit_code == 0 else "❌"
        return (
            f"{status} Command: {command}\n"
            f"Exit code : {exit_code}\n"
            f"Elapsed   : {elapsed:.2f}s\n"
            + ("─" * 50 + "\nSTDOUT:\n" + out if out else "")
            + ("─" * 50 + "\nSTDERR:\n" + err if err else "")
        )

    return f"Unknown tool: {name}"


# ─── Entry point ──────────────────────────────────────────────────────────────

async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream, write_stream,
            server.create_initialization_options()
        )

if __name__ == "__main__":
    asyncio.run(main())
