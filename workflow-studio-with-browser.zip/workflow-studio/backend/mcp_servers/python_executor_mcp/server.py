"""
mcp_servers/python_executor_mcp/server.py
──────────────────────────────────────────
Python Executor MCP Server

Allows Claude to generate and execute Python code that works with:
  - Airflow log output (parse, extract metrics, search patterns)
  - SQL Server query results (analyze, aggregate, compare)
  - S3 file content (parse CSV/JSON/logs from S3)
  - Cross-service analysis (e.g. compare DAG log counts to DB counts)
  - General data manipulation with pandas/numpy

Tools exposed:
  Code Execution  : execute_python, execute_python_with_data
  Data Analysis   : analyze_dataframe, filter_dataframe, aggregate_dataframe,
                    pivot_dataframe, compare_dataframes, profile_dataframe
  Log Processing  : parse_airflow_logs, extract_log_metrics,
                    search_logs_for_pattern, extract_log_counts
  Result Export   : dataframe_to_excel, dataframe_to_csv, dataframe_to_json
  Code Generation : generate_analysis_code, generate_transformation_code
  Utilities       : validate_json, format_sql, parse_csv_content,
                    calculate_statistics, run_assertions_on_data
"""

import asyncio
import json
import os
import re
import sys
import io
import traceback
import time
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
import numpy as np
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from config.settings import (
    PYTHON_EXEC_TIMEOUT, PYTHON_EXEC_MAX_LINES,
    PYTHON_EXEC_OUTPUT_DIR, PYTHON_EXEC_ALLOWED_IMPORTS
)

server = Server("python-executor-mcp")

def _fmt(obj: Any) -> str:
    return json.dumps(obj, indent=2, default=str)

# ─── Safe code executor ───────────────────────────────────────────────────────

_BUILTIN_SAFE = {
    "__builtins__": {
        "print": print, "len": len, "range": range, "enumerate": enumerate,
        "zip": zip, "map": map, "filter": filter, "sorted": sorted,
        "list": list, "dict": dict, "set": set, "tuple": tuple,
        "str": str, "int": int, "float": float, "bool": bool,
        "type": type, "isinstance": isinstance, "hasattr": hasattr,
        "getattr": getattr, "abs": abs, "round": round, "min": min,
        "max": max, "sum": sum, "any": any, "all": all,
        "open": open, "isinstance": isinstance,
        "ValueError": ValueError, "TypeError": TypeError,
        "KeyError": KeyError, "IndexError": IndexError,
        "Exception": Exception, "RuntimeError": RuntimeError,
        "None": None, "True": True, "False": False,
    }
}

def _execute_code(code: str, context: dict | None = None,
                  timeout: int | None = None) -> dict:
    """Execute Python code in a controlled environment, capture stdout/stderr."""
    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()
    exec_globals = {
        "pd": pd, "pandas": pd,
        "np": np, "numpy": np,
        "json": json, "re": re, "os": os,
        "datetime": datetime, "Path": Path,
        "io": io,
    }

    # Inject provided context variables
    if context:
        exec_globals.update(context)

    # Add result capture
    exec_globals["__result__"] = None

    start = time.time()
    error = None
    result_val = None

    try:
        with redirect_stdout(stdout_buf), redirect_stderr(stderr_buf):
            exec(compile(code, "<workflow>", "exec"), exec_globals)  # noqa: S102
        result_val = exec_globals.get("result", exec_globals.get("__result__"))
        elapsed = time.time() - start
    except Exception as e:
        error = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        elapsed = time.time() - start

    stdout = stdout_buf.getvalue()
    stderr = stderr_buf.getvalue()

    # Cap output
    stdout_lines = stdout.splitlines()
    if len(stdout_lines) > PYTHON_EXEC_MAX_LINES:
        stdout = "\n".join(stdout_lines[:PYTHON_EXEC_MAX_LINES])
        stdout += f"\n... [truncated after {PYTHON_EXEC_MAX_LINES} lines]"

    return {
        "success": error is None,
        "stdout": stdout,
        "stderr": stderr,
        "error": error,
        "elapsed_ms": round(elapsed * 1000, 1),
        "result": result_val,
        "exec_globals": exec_globals,
    }


# ══════════════════════════════════════════════════════════════════════════════

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [

        # ── Code Execution ─────────────────────────────────────────────────
        Tool(name="execute_python",
             description="Execute arbitrary Python code. Has access to pandas, numpy, json, re, datetime. "
                         "Use 'result = ...' to capture a return value. print() output is captured.",
             inputSchema={"type":"object","required":["code"],"properties":{
                 "code":{"type":"string","description":"Python code to execute"},
                 "description":{"type":"string","description":"What this code does (for logging)"}
             }}),

        Tool(name="execute_python_with_data",
             description="Execute Python code with pre-loaded data. "
                         "Pass JSON data as 'data' which becomes a 'data' variable in the script. "
                         "Great for processing query results, log outputs, or S3 content.",
             inputSchema={"type":"object","required":["code","data"],"properties":{
                 "code":{"type":"string","description":"Python code. 'data' variable is pre-loaded."},
                 "data":{"type":"string","description":"JSON string of data to process (e.g. query results)"},
                 "data_format":{"type":"string","enum":["json","csv","text","lines"],"default":"json",
                               "description":"How to parse the data into Python"},
                 "description":{"type":"string"}
             }}),

        # ── Data Analysis (pandas) ─────────────────────────────────────────
        Tool(name="analyze_dataframe",
             description="Load JSON rows (e.g. from a SQL query) into a pandas DataFrame "
                         "and run descriptive analysis: dtypes, nulls, stats, duplicates.",
             inputSchema={"type":"object","required":["rows_json"],"properties":{
                 "rows_json":{"type":"string","description":"JSON array of row objects"},
                 "description":{"type":"string"}
             }}),

        Tool(name="filter_dataframe",
             description="Filter rows from a JSON dataset using a pandas query expression.",
             inputSchema={"type":"object","required":["rows_json","filter_expr"],"properties":{
                 "rows_json":{"type":"string","description":"JSON array of row objects"},
                 "filter_expr":{"type":"string","description":"Pandas query string, e.g. 'age > 30 and status == \"active\"'"},
                 "output_columns":{"type":"array","items":{"type":"string"},"description":"Columns to return (all if omitted)"}
             }}),

        Tool(name="aggregate_dataframe",
             description="Group and aggregate a JSON dataset.",
             inputSchema={"type":"object","required":["rows_json","group_by","aggregations"],"properties":{
                 "rows_json":{"type":"string"},
                 "group_by":{"type":"array","items":{"type":"string"},"description":"Columns to group by"},
                 "aggregations":{"type":"object","description":"Column → agg function(s), e.g. {\"amount\": \"sum\", \"id\": \"count\"}"}
             }}),

        Tool(name="pivot_dataframe",
             description="Create a pivot table from JSON data.",
             inputSchema={"type":"object","required":["rows_json","index","columns","values"],"properties":{
                 "rows_json":{"type":"string"},
                 "index":{"type":"string","description":"Row grouping column"},
                 "columns":{"type":"string","description":"Column grouping column"},
                 "values":{"type":"string","description":"Value column"},
                 "aggfunc":{"type":"string","default":"sum","enum":["sum","mean","count","min","max","first","last"]}
             }}),

        Tool(name="compare_dataframes",
             description="Compare two JSON datasets (e.g. DB query vs another query). "
                         "Finds added, removed, and changed rows.",
             inputSchema={"type":"object","required":["rows_a","rows_b","key_columns"],"properties":{
                 "rows_a":{"type":"string","description":"JSON array — source/expected"},
                 "rows_b":{"type":"string","description":"JSON array — target/actual"},
                 "key_columns":{"type":"array","items":{"type":"string"},"description":"Columns that uniquely identify a row"},
                 "compare_columns":{"type":"array","items":{"type":"string"},"description":"Columns to compare values (all if omitted)"}
             }}),

        Tool(name="profile_dataframe",
             description="Generate a data quality profile: per-column stats, null counts, "
                         "unique counts, min/max, sample values.",
             inputSchema={"type":"object","required":["rows_json"],"properties":{
                 "rows_json":{"type":"string"},
                 "sample_size":{"type":"integer","default":3}
             }}),

        # ── Log Processing ─────────────────────────────────────────────────
        Tool(name="parse_airflow_logs",
             description="Parse Airflow task log text. Extracts: log level counts, "
                         "start/end times, error messages, WARNING/ERROR lines, key-value pairs printed.",
             inputSchema={"type":"object","required":["log_text"],"properties":{
                 "log_text":{"type":"string","description":"Raw Airflow log text (from get_task_logs)"},
                 "task_id":{"type":"string","description":"Task ID for labeling"}
             }}),

        Tool(name="extract_log_metrics",
             description="Extract numeric metrics from Airflow log text using patterns like "
                         "'processed X records', 'count: 2000', 'rows=500'.",
             inputSchema={"type":"object","required":["log_text"],"properties":{
                 "log_text":{"type":"string"},
                 "custom_patterns":{"type":"array","items":{"type":"string"},
                                    "description":"Additional regex patterns with one capture group for number"}
             }}),

        Tool(name="search_logs_for_pattern",
             description="Search log text (Airflow logs or any log file) for lines matching a regex.",
             inputSchema={"type":"object","required":["log_text","pattern"],"properties":{
                 "log_text":{"type":"string"},
                 "pattern":{"type":"string","description":"Regex pattern to match"},
                 "context_lines":{"type":"integer","default":0,"description":"Lines before/after each match to include"},
                 "max_matches":{"type":"integer","default":50}
             }}),

        Tool(name="extract_log_counts",
             description="Extract a named metric count from Airflow log text. "
                         "e.g. find 'subscribed_count: 2000' or 'Processed 2000 subscribers'.",
             inputSchema={"type":"object","required":["log_text","metric_name"],"properties":{
                 "log_text":{"type":"string"},
                 "metric_name":{"type":"string","description":"Name/keyword to search near (e.g. 'subscribed_count')"},
                 "return_all":{"type":"boolean","default":False,"description":"Return all matches vs just first"}
             }}),

        # ── Export ─────────────────────────────────────────────────────────
        Tool(name="dataframe_to_excel",
             description="Convert JSON rows to an Excel file and save to output directory.",
             inputSchema={"type":"object","required":["rows_json","filename"],"properties":{
                 "rows_json":{"type":"string"},
                 "filename":{"type":"string"},
                 "sheet_name":{"type":"string","default":"Results"},
                 "title":{"type":"string"}
             }}),

        Tool(name="dataframe_to_csv",
             description="Convert JSON rows to a CSV file.",
             inputSchema={"type":"object","required":["rows_json","filename"],"properties":{
                 "rows_json":{"type":"string"},
                 "filename":{"type":"string"}
             }}),

        # ── Code Generation ────────────────────────────────────────────────
        Tool(name="generate_analysis_code",
             description="Generate Python analysis code for a given dataset and goal. "
                         "Returns executable Python code (don't execute — just generate).",
             inputSchema={"type":"object","required":["goal","sample_data"],"properties":{
                 "goal":{"type":"string","description":"What you want to analyze or compute"},
                 "sample_data":{"type":"string","description":"Sample rows (JSON) to understand schema"},
                 "output_format":{"type":"string","enum":["print","excel","json"],"default":"print"}
             }}),

        Tool(name="generate_transformation_code",
             description="Generate Python transformation code to reshape or clean data.",
             inputSchema={"type":"object","required":["transformation","sample_data"],"properties":{
                 "transformation":{"type":"string","description":"Describe the transformation (e.g. 'normalize date columns, fill nulls with 0, rename col A to col B')"},
                 "sample_data":{"type":"string","description":"Sample input rows (JSON)"}
             }}),

        # ── Utilities ──────────────────────────────────────────────────────
        Tool(name="validate_json",
             description="Validate and pretty-print JSON string. Returns parsed structure summary.",
             inputSchema={"type":"object","required":["json_text"],"properties":{
                 "json_text":{"type":"string"}
             }}),

        Tool(name="parse_csv_content",
             description="Parse CSV text (e.g. from S3 file) into a JSON rows array.",
             inputSchema={"type":"object","required":["csv_text"],"properties":{
                 "csv_text":{"type":"string"},
                 "delimiter":{"type":"string","default":","},
                 "has_header":{"type":"boolean","default":True},
                 "max_rows":{"type":"integer","default":1000}
             }}),

        Tool(name="calculate_statistics",
             description="Calculate statistics for a list of numbers or a column in JSON data.",
             inputSchema={"type":"object","required":["values_or_json"],"properties":{
                 "values_or_json":{"type":"string","description":"JSON array of numbers OR JSON rows"},
                 "column_name":{"type":"string","description":"If JSON rows provided, which column to analyze"}
             }}),

        Tool(name="run_assertions_on_data",
             description="Run multiple data assertions on a JSON dataset. "
                         "Returns PASS/FAIL for each with detail.",
             inputSchema={"type":"object","required":["rows_json","assertions"],"properties":{
                 "rows_json":{"type":"string"},
                 "assertions":{"type":"array","items":{
                     "type":"object","required":["name","check_type"],"properties":{
                         "name":{"type":"string"},
                         "check_type":{"type":"string","enum":[
                             "row_count_eq","row_count_gt","row_count_lt",
                             "column_value_eq","column_value_contains",
                             "no_nulls","all_unique","value_in_range",
                             "column_sum_eq","column_max_lt","column_min_gt"
                         ]},
                         "column":{"type":"string"},
                         "expected":{"type":"string"},
                         "min_val":{"type":"number"},
                         "max_val":{"type":"number"}
                     }
                 }}
             }}),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await _dispatch(name, arguments)
        return [TextContent(type="text", text=result)]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]


async def _dispatch(name: str, a: dict) -> str:

    # ── Code Execution ────────────────────────────────────────────────────────
    if name == "execute_python":
        out = _execute_code(a["code"])
        lines = [f"{'✅' if out['success'] else '❌'} Execution {'succeeded' if out['success'] else 'FAILED'} in {out['elapsed_ms']}ms"]
        if out["stdout"]:
            lines.append(f"\nOutput:\n{out['stdout']}")
        if out["error"]:
            lines.append(f"\nError:\n{out['error']}")
        if out["result"] is not None:
            lines.append(f"\nResult:\n{_fmt(out['result']) if not isinstance(out['result'], str) else out['result']}")
        return "\n".join(lines)

    if name == "execute_python_with_data":
        raw = a["data"]
        fmt = a.get("data_format", "json")
        if fmt == "json":
            try:
                parsed = json.loads(raw)
            except Exception:
                parsed = raw
            ctx = {"data": parsed}
        elif fmt == "csv":
            ctx = {"data": pd.read_csv(io.StringIO(raw)), "data_raw": raw}
        elif fmt == "lines":
            ctx = {"data": raw.splitlines(), "data_raw": raw}
        else:
            ctx = {"data": raw}
        out = _execute_code(a["code"], context=ctx)
        lines = [f"{'✅' if out['success'] else '❌'} Execution {'succeeded' if out['success'] else 'FAILED'} in {out['elapsed_ms']}ms"]
        if out["stdout"]: lines.append(f"\nOutput:\n{out['stdout']}")
        if out["error"]:  lines.append(f"\nError:\n{out['error']}")
        if out.get("result") is not None:
            r = out["result"]
            if isinstance(r, pd.DataFrame):
                lines.append(f"\nResult DataFrame ({len(r)} rows × {len(r.columns)} cols):\n{r.to_string(max_rows=20)}")
            else:
                lines.append(f"\nResult:\n{_fmt(r)}")
        return "\n".join(lines)

    # ── Data Analysis ─────────────────────────────────────────────────────────
    if name == "analyze_dataframe":
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        lines = [f"DataFrame Analysis: {len(df)} rows × {len(df.columns)} columns\n"]
        lines.append(f"Columns: {list(df.columns)}\n")
        lines.append("Data Types:")
        lines.append(df.dtypes.to_string())
        lines.append("\nNull Counts:")
        lines.append(df.isnull().sum().to_string())
        lines.append("\nDuplicate Rows: " + str(df.duplicated().sum()))
        try:
            lines.append("\nNumeric Statistics:")
            lines.append(df.describe().to_string())
        except Exception:
            pass
        try:
            for col in df.select_dtypes(include="object").columns[:5]:
                vc = df[col].value_counts()
                lines.append(f"\nTop values in '{col}':")
                lines.append(vc.head(5).to_string())
        except Exception:
            pass
        return "\n".join(lines)

    if name == "filter_dataframe":
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        before = len(df)
        df = df.query(a["filter_expr"])
        if a.get("output_columns"):
            df = df[a["output_columns"]]
        return (f"Filtered {before} → {len(df)} rows\n\n"
                f"{df.to_string(max_rows=50)}\n\n"
                f"JSON:\n{df.to_json(orient='records',indent=2)}")

    if name == "aggregate_dataframe":
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        agg_result = df.groupby(a["group_by"]).agg(a["aggregations"]).reset_index()
        return (f"Aggregation result ({len(agg_result)} groups):\n{agg_result.to_string()}\n\n"
                f"JSON:\n{agg_result.to_json(orient='records',indent=2)}")

    if name == "pivot_dataframe":
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        pt = pd.pivot_table(df, index=a["index"], columns=a["columns"],
                            values=a["values"], aggfunc=a.get("aggfunc","sum"))
        return f"Pivot Table:\n{pt.to_string()}"

    if name == "compare_dataframes":
        df_a = pd.DataFrame(json.loads(a["rows_a"]))
        df_b = pd.DataFrame(json.loads(a["rows_b"]))
        keys = a["key_columns"]
        cmp_cols = a.get("compare_columns") or [c for c in df_a.columns if c not in keys]

        df_a["__src__"] = "A"
        df_b["__src__"] = "B"

        merged = df_a.merge(df_b, on=keys, how="outer", suffixes=("_A","_B"))
        only_a = df_a[~df_a[keys[0]].isin(df_b[keys[0]])][keys + cmp_cols].to_dict("records")
        only_b = df_b[~df_b[keys[0]].isin(df_a[keys[0]])][keys + cmp_cols].to_dict("records")

        changed = []
        for _, row in merged.dropna(subset=[f"{cmp_cols[0]}_A" if cmp_cols else keys[0]]).iterrows():
            diffs = {}
            for col in cmp_cols:
                va = row.get(f"{col}_A")
                vb = row.get(f"{col}_B")
                if str(va) != str(vb):
                    diffs[col] = {"A": va, "B": vb}
            if diffs:
                changed.append({k: row.get(k) for k in keys} | {"diffs": diffs})

        return (f"Comparison Summary:\n"
                f"  Rows in A   : {len(df_a)}\n"
                f"  Rows in B   : {len(df_b)}\n"
                f"  Only in A   : {len(only_a)}\n"
                f"  Only in B   : {len(only_b)}\n"
                f"  Changed rows: {len(changed)}\n\n"
                f"Only in A: {_fmt(only_a[:10])}\n\n"
                f"Only in B: {_fmt(only_b[:10])}\n\n"
                f"Changed: {_fmt(changed[:10])}")

    if name == "profile_dataframe":
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        sample_size = a.get("sample_size", 3)
        profile = []
        for col in df.columns:
            col_profile: dict = {
                "column": col,
                "dtype": str(df[col].dtype),
                "null_count": int(df[col].isnull().sum()),
                "null_pct": f"{df[col].isnull().mean()*100:.1f}%",
                "unique_count": int(df[col].nunique()),
                "sample_values": df[col].dropna().head(sample_size).tolist()
            }
            if pd.api.types.is_numeric_dtype(df[col]):
                col_profile["min"] = float(df[col].min()) if not df[col].isnull().all() else None
                col_profile["max"] = float(df[col].max()) if not df[col].isnull().all() else None
                col_profile["mean"] = float(df[col].mean()) if not df[col].isnull().all() else None
            profile.append(col_profile)
        return f"Data Profile ({len(df)} rows, {len(df.columns)} cols):\n{_fmt(profile)}"

    # ── Log Processing ────────────────────────────────────────────────────────
    if name == "parse_airflow_logs":
        log = a["log_text"]
        lines = log.splitlines()
        level_counts: dict = {"INFO": 0, "WARNING": 0, "ERROR": 0, "CRITICAL": 0, "DEBUG": 0}
        errors = []
        warnings = []
        kv_pairs: dict = {}
        start_time = end_time = None

        ts_pattern = re.compile(r"\[(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})")
        kv_pattern = re.compile(r"(\w+)\s*[=:]\s*([\d.]+)")

        for line in lines:
            for lvl in level_counts:
                if lvl in line:
                    level_counts[lvl] += 1
                    break
            if "ERROR" in line or "CRITICAL" in line:
                errors.append(line.strip())
            if "WARNING" in line or "WARN" in line:
                warnings.append(line.strip())
            ts_match = ts_pattern.search(line)
            if ts_match:
                ts = ts_match.group(1)
                if start_time is None:
                    start_time = ts
                end_time = ts
            for m in kv_pattern.finditer(line):
                key, val = m.group(1), m.group(2)
                if key not in ("INFO","ERROR","WARNING","DEBUG"):
                    try:
                        kv_pairs[key] = float(val) if '.' in val else int(val)
                    except Exception:
                        pass

        task_id = a.get("task_id", "unknown")
        return (f"Airflow Log Analysis — Task: {task_id}\n"
                f"Total lines  : {len(lines)}\n"
                f"Time range   : {start_time} → {end_time}\n"
                f"Log levels   : {_fmt(level_counts)}\n"
                f"KV metrics   : {_fmt(kv_pairs)}\n"
                f"\nErrors ({len(errors)}):\n" + "\n".join(errors[:10]) +
                f"\n\nWarnings ({len(warnings)}):\n" + "\n".join(warnings[:5]))

    if name == "extract_log_metrics":
        log = a["log_text"]
        default_patterns = [
            r"(?:count|rows?|records?|items?)\s*[=:]\s*(\d+)",
            r"processed\s+(\d+)",
            r"total[:\s]+(\d+)",
            r"inserted[:\s]+(\d+)",
            r"updated[:\s]+(\d+)",
            r"deleted[:\s]+(\d+)",
            r"failed[:\s]+(\d+)",
            r"success[:\s]+(\d+)",
            r"duration[:\s]+([0-9.]+)",
            r"elapsed[:\s]+([0-9.]+)",
        ]
        if a.get("custom_patterns"):
            default_patterns.extend(a["custom_patterns"])
        found: dict = {}
        for pattern in default_patterns:
            matches = re.findall(pattern, log, re.IGNORECASE)
            if matches:
                key = re.sub(r"[\\()?:.*+\[\]{}|^$]","",pattern.split(r"\s")[0]).strip()
                vals = [float(m) if '.' in str(m) else int(m) for m in matches]
                found[key] = vals if len(vals) > 1 else vals[0]
        return f"Extracted Metrics:\n{_fmt(found)}"

    if name == "search_logs_for_pattern":
        log = a["log_text"]
        lines = log.splitlines()
        pattern = re.compile(a["pattern"], re.IGNORECASE)
        ctx = a.get("context_lines", 0)
        max_m = a.get("max_matches", 50)
        matches = []
        for i, line in enumerate(lines):
            if pattern.search(line):
                start = max(0, i - ctx)
                end = min(len(lines), i + ctx + 1)
                block = lines[start:end]
                matches.append({
                    "line_no": i + 1,
                    "match": line.strip(),
                    "context": block if ctx else None
                })
                if len(matches) >= max_m:
                    break
        if ctx:
            for m in matches:
                del m["context"] if not m["context"] else None
        return f"Found {len(matches)} match(es) for pattern '{a['pattern']}':\n{_fmt(matches)}"

    if name == "extract_log_counts":
        log = a["log_text"]
        metric = a["metric_name"]
        patterns = [
            rf"{re.escape(metric)}\s*[=:]\s*(\d+)",
            rf"(\d+)\s+{re.escape(metric)}",
            rf"{re.escape(metric)}[^0-9]*(\d+)",
        ]
        found = []
        for p in patterns:
            matches = re.findall(p, log, re.IGNORECASE)
            if matches:
                found.extend([int(m) for m in matches])
        if not found:
            return f"No numeric value found near '{metric}' in logs"
        if a.get("return_all"):
            return f"Values for '{metric}': {found}"
        return f"'{metric}' = {found[0]} (first occurrence)\nAll occurrences: {found}"

    # ── Export ────────────────────────────────────────────────────────────────
    if name == "dataframe_to_excel":
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        fname = a["filename"]
        if not fname.endswith(".xlsx"):
            fname += ".xlsx"
        PYTHON_EXEC_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        filepath = PYTHON_EXEC_OUTPUT_DIR / fname
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = a.get("sheet_name","Results")[:31]
        row_offset = 1
        if a.get("title"):
            ws.append([a["title"]])
            ws["A1"].font = Font(bold=True, size=13)
            ws.append([f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Rows: {len(df)}"])
            ws.append([])
            row_offset = 4
        fill = PatternFill("solid", fgColor="2E75B6")
        for ci, col in enumerate(df.columns, 1):
            cell = ws.cell(row=row_offset, column=ci, value=col)
            cell.fill = fill
            cell.font = Font(bold=True, color="FFFFFF")
        for ri, row in enumerate(df.itertuples(index=False), row_offset+1):
            for ci, val in enumerate(row, 1):
                ws.cell(row=ri, column=ci, value=val)
        wb.save(filepath)
        return f"✅ Saved {len(rows)} rows to {filepath}"

    if name == "dataframe_to_csv":
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        fname = a["filename"]
        if not fname.endswith(".csv"):
            fname += ".csv"
        PYTHON_EXEC_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        filepath = PYTHON_EXEC_OUTPUT_DIR / fname
        df.to_csv(filepath, index=False)
        return f"✅ Saved {len(rows)} rows to {filepath}"

    # ── Code Generation ───────────────────────────────────────────────────────
    if name == "generate_analysis_code":
        sample = json.loads(a["sample_data"])[:3] if a["sample_data"].strip().startswith("[") else []
        cols = list(sample[0].keys()) if sample else []
        goal = a["goal"]
        fmt = a.get("output_format","print")
        code = f"""# Goal: {goal}
# Auto-generated analysis code
# Columns available: {cols}

import pandas as pd
import numpy as np

# 'data' variable is pre-loaded as list of dicts
df = pd.DataFrame(data)
print(f"Loaded {{len(df)}} rows x {{len(df.columns)}} columns")
print(df.dtypes)
print()

# === YOUR ANALYSIS ===
# {goal}
"""
        if "count" in goal.lower() or "group" in goal.lower():
            code += f"\n# Group and count\nresult = df.groupby(['{cols[0] if cols else 'column'}'])\n"
        if fmt == "excel":
            code += "\n# Save to Excel\ndf.to_excel('output.xlsx', index=False)\nprint('Saved to output.xlsx')\n"
        code += "\nresult = df  # set 'result' to capture output"
        return f"Generated analysis code:\n\n```python\n{code}\n```"

    if name == "generate_transformation_code":
        sample = a["sample_data"]
        transformation = a["transformation"]
        code = f"""# Transformation: {transformation}
# Auto-generated

import pandas as pd
import numpy as np

df = pd.DataFrame(data)
print(f"Input: {{len(df)}} rows")

# === TRANSFORMATION ===
# {transformation}

# Common patterns — uncomment/adapt as needed:
# df = df.rename(columns={{'old_name': 'new_name'}})
# df['date_col'] = pd.to_datetime(df['date_col'])
# df = df.fillna(0)
# df = df.drop_duplicates()
# df = df[df['col'] > 0]  # filter
# df['new_col'] = df['col_a'] + df['col_b']  # derive

print(f"Output: {{len(df)}} rows")
result = df
"""
        return f"Generated transformation code:\n\n```python\n{code}\n```"

    # ── Utilities ─────────────────────────────────────────────────────────────
    if name == "validate_json":
        try:
            parsed = json.loads(a["json_text"])
            t = type(parsed).__name__
            if isinstance(parsed, list):
                return (f"✅ Valid JSON array\n"
                        f"Length: {len(parsed)}\n"
                        f"First item keys: {list(parsed[0].keys()) if parsed and isinstance(parsed[0],dict) else 'N/A'}\n"
                        f"Preview:\n{json.dumps(parsed[:2],indent=2)}")
            elif isinstance(parsed, dict):
                return (f"✅ Valid JSON object\n"
                        f"Keys: {list(parsed.keys())}\n"
                        f"Preview:\n{json.dumps(parsed,indent=2)[:500]}")
            return f"✅ Valid JSON ({t}): {parsed}"
        except json.JSONDecodeError as e:
            return f"❌ Invalid JSON: {e}"

    if name == "parse_csv_content":
        df = pd.read_csv(
            io.StringIO(a["csv_text"]),
            sep=a.get("delimiter",","),
            header=0 if a.get("has_header",True) else None,
            nrows=a.get("max_rows",1000)
        )
        rows = df.to_dict("records")
        return (f"✅ Parsed CSV: {len(rows)} rows × {len(df.columns)} columns\n"
                f"Columns: {list(df.columns)}\n\n"
                f"JSON:\n{json.dumps(rows[:5],indent=2,default=str)}\n..."
                f"\n\nFull rows as JSON:\n{json.dumps(rows,indent=2,default=str)}")

    if name == "calculate_statistics":
        raw = a["values_or_json"]
        col = a.get("column_name")
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
                df = pd.DataFrame(parsed)
                if col and col in df.columns:
                    series = pd.to_numeric(df[col], errors="coerce").dropna()
                else:
                    series = df.select_dtypes("number").iloc[:,0]
            else:
                series = pd.Series(parsed)
        except Exception:
            series = pd.Series([float(x) for x in raw.split(",")])
        stats = {
            "count": int(series.count()), "mean": float(series.mean()),
            "median": float(series.median()), "std": float(series.std()),
            "min": float(series.min()), "max": float(series.max()),
            "25th_pct": float(series.quantile(0.25)),
            "75th_pct": float(series.quantile(0.75)),
            "sum": float(series.sum())
        }
        return f"Statistics:\n{_fmt(stats)}"

    if name == "run_assertions_on_data":
        rows = json.loads(a["rows_json"])
        df = pd.DataFrame(rows)
        results = []
        passed = failed = 0
        for assertion in a["assertions"]:
            aname = assertion["name"]
            check = assertion["check_type"]
            col = assertion.get("column","")
            expected = assertion.get("expected","")
            try:
                if check == "row_count_eq":
                    ok = len(df) == int(expected)
                    detail = f"count={len(df)}, expected={expected}"
                elif check == "row_count_gt":
                    ok = len(df) > int(expected)
                    detail = f"count={len(df)}, expected>{expected}"
                elif check == "row_count_lt":
                    ok = len(df) < int(expected)
                    detail = f"count={len(df)}, expected<{expected}"
                elif check == "column_value_eq":
                    vals = df[col].dropna().unique().tolist()
                    ok = expected in [str(v) for v in vals]
                    detail = f"unique_vals={vals[:5]}"
                elif check == "column_value_contains":
                    ok = df[col].astype(str).str.contains(expected, na=False).any()
                    detail = f"searched for '{expected}' in {col}"
                elif check == "no_nulls":
                    null_count = df[col].isnull().sum() if col else df.isnull().sum().sum()
                    ok = null_count == 0
                    detail = f"null_count={null_count}"
                elif check == "all_unique":
                    dups = df[col].duplicated().sum() if col else 0
                    ok = dups == 0
                    detail = f"duplicates={dups}"
                elif check == "value_in_range":
                    mn = assertion.get("min_val", float("-inf"))
                    mx = assertion.get("max_val", float("inf"))
                    series = pd.to_numeric(df[col], errors="coerce")
                    ok = series.between(mn, mx).all()
                    detail = f"range=[{mn},{mx}], actual=[{series.min()},{series.max()}]"
                elif check == "column_sum_eq":
                    actual = pd.to_numeric(df[col], errors="coerce").sum()
                    ok = abs(actual - float(expected)) < 0.001
                    detail = f"sum={actual}, expected={expected}"
                elif check == "column_max_lt":
                    actual = pd.to_numeric(df[col], errors="coerce").max()
                    ok = actual < float(expected)
                    detail = f"max={actual}, expected<{expected}"
                elif check == "column_min_gt":
                    actual = pd.to_numeric(df[col], errors="coerce").min()
                    ok = actual > float(expected)
                    detail = f"min={actual}, expected>{expected}"
                else:
                    ok = False
                    detail = "unknown check_type"
                if ok: passed += 1
                else:  failed += 1
                results.append({"name": aname, "status": "PASS" if ok else "FAIL",
                                 "check": check, "detail": detail})
            except Exception as e:
                failed += 1
                results.append({"name": aname, "status": "ERROR", "error": str(e)})

        summary = f"Data Assertions: {passed} PASS / {failed} FAIL / {len(a['assertions'])} total\n\n"
        for r in results:
            emoji = "✅" if r["status"]=="PASS" else "❌"
            detail = r.get("detail","") or r.get("error","")
            summary += f"{emoji} {r['name']}: {r['status']} ({detail})\n"
        return summary

    return f"Unknown tool: {name}"


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream,
                         server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
