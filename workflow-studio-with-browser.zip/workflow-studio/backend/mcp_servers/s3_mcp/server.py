"""
mcp_servers/s3_mcp/server.py
─────────────────────────────
AWS S3 MCP Server

Tools exposed:
  Bucket Ops    : list_buckets, get_bucket_info, get_bucket_location,
                  get_bucket_policy_summary
  Object Browse : list_objects, list_common_prefixes (folders), search_objects,
                  get_object_metadata, check_file_exists
  Object Read   : get_object_content (text/JSON/CSV), get_object_head,
                  get_presigned_url, list_object_versions
  Object Write  : upload_text_content, upload_local_file, copy_object,
                  move_object, delete_object, delete_objects_by_prefix
  Download      : download_file, download_folder
  Analytics     : get_bucket_size, count_objects_by_prefix,
                  find_recent_objects, find_objects_by_extension,
                  compare_prefixes
  Assertions    : assert_file_exists, assert_file_not_exists,
                  assert_file_newer_than, assert_prefix_has_files
"""

import asyncio
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from config.settings import (
    AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN,
    AWS_REGION, AWS_S3_ENDPOINT_URL, S3_DOWNLOAD_DIR
)

# ─── S3 client factory ────────────────────────────────────────────────────────

def _s3():
    kwargs: dict = {
        "region_name": AWS_REGION,
    }
    if AWS_ACCESS_KEY_ID:
        kwargs["aws_access_key_id"] = AWS_ACCESS_KEY_ID
        kwargs["aws_secret_access_key"] = AWS_SECRET_ACCESS_KEY
    if AWS_SESSION_TOKEN:
        kwargs["aws_session_token"] = AWS_SESSION_TOKEN
    if AWS_S3_ENDPOINT_URL:
        kwargs["endpoint_url"] = AWS_S3_ENDPOINT_URL
    return boto3.client("s3", **kwargs)

def _fmt(obj: Any) -> str:
    return json.dumps(obj, indent=2, default=str)

def _human_size(size_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


# ─── MCP Server ──────────────────────────────────────────────────────────────

server = Server("s3-mcp")

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [

        # ── Bucket Operations ──────────────────────────────────────────────
        Tool(name="list_buckets",
             description="List all S3 buckets the credentials can access.",
             inputSchema={"type":"object","properties":{
                 "name_filter":{"type":"string","description":"Substring to filter bucket names"}
             }}),

        Tool(name="get_bucket_info",
             description="Get info about a bucket: region, versioning, tags, creation date.",
             inputSchema={"type":"object","required":["bucket"],"properties":{
                 "bucket":{"type":"string"}
             }}),

        Tool(name="get_bucket_location",
             description="Get the AWS region where a bucket is located.",
             inputSchema={"type":"object","required":["bucket"],"properties":{
                 "bucket":{"type":"string"}
             }}),

        # ── Object Browsing ────────────────────────────────────────────────
        Tool(name="list_objects",
             description="List objects in a bucket under a given prefix (like a folder path). "
                         "Returns key, size, last_modified, etag for each object.",
             inputSchema={"type":"object","required":["bucket"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string","default":"","description":"Folder path prefix (e.g. 'data/2024/')"},
                 "max_keys":{"type":"integer","default":100},
                 "delimiter":{"type":"string","default":"","description":"Use '/' to list like a filesystem"},
                 "continuation_token":{"type":"string","description":"For pagination"},
                 "sort_by":{"type":"string","enum":["key","size","last_modified"],"default":"key"}
             }}),

        Tool(name="list_common_prefixes",
             description="List 'folders' (common prefixes) at a given path in a bucket. "
                         "Like doing 'ls' on a directory in S3.",
             inputSchema={"type":"object","required":["bucket"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string","default":""},
                 "recursive":{"type":"boolean","default":False}
             }}),

        Tool(name="search_objects",
             description="Search for objects matching a filename pattern or substring across a prefix.",
             inputSchema={"type":"object","required":["bucket","search_term"],"properties":{
                 "bucket":{"type":"string"},
                 "search_term":{"type":"string","description":"Filename/key substring to match"},
                 "prefix":{"type":"string","default":""},
                 "max_results":{"type":"integer","default":50},
                 "case_sensitive":{"type":"boolean","default":False}
             }}),

        Tool(name="check_file_exists",
             description="Check whether a specific S3 object (file) exists.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string","description":"Full object key/path"}
             }}),

        Tool(name="get_object_metadata",
             description="Get full metadata of an S3 object: size, content-type, last_modified, tags, custom metadata.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"}
             }}),

        Tool(name="list_object_versions",
             description="List all versions of an object (requires versioning enabled).",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "max_versions":{"type":"integer","default":20}
             }}),

        # ── Object Read ────────────────────────────────────────────────────
        Tool(name="get_object_content",
             description="Read the text content of a small S3 object (text, JSON, CSV, log). "
                         "Do NOT use for large binary files.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "max_bytes":{"type":"integer","default":102400,
                             "description":"Max bytes to read (default 100KB)"},
                 "encoding":{"type":"string","default":"utf-8"},
                 "version_id":{"type":"string","description":"Specific version to read"}
             }}),

        Tool(name="get_presigned_url",
             description="Generate a pre-signed URL for temporary access to an S3 object.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "expiry_seconds":{"type":"integer","default":3600},
                 "operation":{"type":"string","enum":["get_object","put_object"],"default":"get_object"}
             }}),

        # ── Object Write ───────────────────────────────────────────────────
        Tool(name="upload_text_content",
             description="Upload a string/JSON/CSV content directly to S3 without a local file.",
             inputSchema={"type":"object","required":["bucket","key","content"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "content":{"type":"string","description":"Text content to upload"},
                 "content_type":{"type":"string","default":"text/plain"},
                 "metadata":{"type":"object","description":"Custom metadata key-value pairs","default":{}}
             }}),

        Tool(name="copy_object",
             description="Copy an S3 object to another location (same or different bucket).",
             inputSchema={"type":"object","required":["source_bucket","source_key","dest_bucket","dest_key"],"properties":{
                 "source_bucket":{"type":"string"},
                 "source_key":{"type":"string"},
                 "dest_bucket":{"type":"string"},
                 "dest_key":{"type":"string"},
                 "source_version_id":{"type":"string","description":"Copy specific version"}
             }}),

        Tool(name="move_object",
             description="Move (copy + delete) an S3 object to a new location.",
             inputSchema={"type":"object","required":["source_bucket","source_key","dest_bucket","dest_key"],"properties":{
                 "source_bucket":{"type":"string"},
                 "source_key":{"type":"string"},
                 "dest_bucket":{"type":"string"},
                 "dest_key":{"type":"string"}
             }}),

        Tool(name="delete_object",
             description="Delete a single S3 object.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "version_id":{"type":"string","description":"Delete specific version"}
             }}),

        Tool(name="delete_objects_by_prefix",
             description="Delete all objects matching a prefix. USE WITH CAUTION. "
                         "Requires confirm=true.",
             inputSchema={"type":"object","required":["bucket","prefix","confirm"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string"},
                 "confirm":{"type":"boolean","description":"Must be true to execute"}
             }}),

        # ── Download ───────────────────────────────────────────────────────
        Tool(name="download_file",
             description="Download an S3 object to the local download directory.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "local_filename":{"type":"string","description":"Local name (defaults to S3 key basename)"}
             }}),

        Tool(name="download_folder",
             description="Download all objects under a prefix to a local directory.",
             inputSchema={"type":"object","required":["bucket","prefix"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string"},
                 "local_dir":{"type":"string","description":"Local subdirectory name"},
                 "max_files":{"type":"integer","default":50}
             }}),

        # ── Analytics ─────────────────────────────────────────────────────
        Tool(name="get_bucket_size",
             description="Calculate total size and object count under a prefix.",
             inputSchema={"type":"object","required":["bucket"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string","default":""},
                 "max_objects_to_scan":{"type":"integer","default":10000}
             }}),

        Tool(name="count_objects_by_prefix",
             description="Count objects grouped by top-level folder under a given prefix.",
             inputSchema={"type":"object","required":["bucket"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string","default":""},
                 "delimiter":{"type":"string","default":"/"}
             }}),

        Tool(name="find_recent_objects",
             description="Find the N most recently modified objects under a prefix.",
             inputSchema={"type":"object","required":["bucket"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string","default":""},
                 "top_n":{"type":"integer","default":10},
                 "since_hours":{"type":"integer","description":"Only objects modified within last N hours"}
             }}),

        Tool(name="find_objects_by_extension",
             description="Find all objects with a specific file extension (e.g. .csv, .parquet, .log).",
             inputSchema={"type":"object","required":["bucket","extension"],"properties":{
                 "bucket":{"type":"string"},
                 "extension":{"type":"string","description":"e.g. '.csv' or 'csv'"},
                 "prefix":{"type":"string","default":""},
                 "max_results":{"type":"integer","default":100}
             }}),

        Tool(name="compare_prefixes",
             description="Compare object lists between two prefixes (same or different buckets). "
                         "Useful for verifying data copy/migration.",
             inputSchema={"type":"object","required":["bucket_a","prefix_a","bucket_b","prefix_b"],"properties":{
                 "bucket_a":{"type":"string"},
                 "prefix_a":{"type":"string"},
                 "bucket_b":{"type":"string"},
                 "prefix_b":{"type":"string"},
                 "compare_by":{"type":"string","enum":["key","size","etag"],"default":"key"}
             }}),

        # ── Assertions ─────────────────────────────────────────────────────
        Tool(name="assert_file_exists",
             description="Assert a specific file exists in S3. Returns PASS/FAIL.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "description":{"type":"string"}
             }}),

        Tool(name="assert_file_not_exists",
             description="Assert a specific file does NOT exist in S3.",
             inputSchema={"type":"object","required":["bucket","key"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "description":{"type":"string"}
             }}),

        Tool(name="assert_file_newer_than",
             description="Assert that a file was modified after a given datetime.",
             inputSchema={"type":"object","required":["bucket","key","since_iso"],"properties":{
                 "bucket":{"type":"string"},
                 "key":{"type":"string"},
                 "since_iso":{"type":"string","description":"ISO8601 datetime, e.g. '2024-01-01T00:00:00Z'"},
                 "description":{"type":"string"}
             }}),

        Tool(name="assert_prefix_has_files",
             description="Assert that at least N files exist under a prefix.",
             inputSchema={"type":"object","required":["bucket","prefix"],"properties":{
                 "bucket":{"type":"string"},
                 "prefix":{"type":"string"},
                 "min_count":{"type":"integer","default":1},
                 "extension":{"type":"string","description":"Only count files with this extension"},
                 "description":{"type":"string"}
             }}),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await _dispatch(name, arguments)
        return [TextContent(type="text", text=result)]
    except ClientError as e:
        code = e.response["Error"]["Code"]
        msg = e.response["Error"]["Message"]
        return [TextContent(type="text", text=f"S3 Error [{code}]: {msg}")]
    except NoCredentialsError:
        return [TextContent(type="text", text="AWS credentials not configured. Check .env file.")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]


def _paginate_all(s3_client, bucket: str, prefix: str = "", max_keys: int = 5000) -> list[dict]:
    """Paginate through all objects under prefix."""
    objects = []
    kwargs: dict = {"Bucket": bucket, "MaxKeys": min(max_keys, 1000)}
    if prefix:
        kwargs["Prefix"] = prefix
    while True:
        resp = s3_client.list_objects_v2(**kwargs)
        objects.extend(resp.get("Contents", []))
        if len(objects) >= max_keys:
            break
        if not resp.get("IsTruncated"):
            break
        kwargs["ContinuationToken"] = resp["NextContinuationToken"]
    return objects[:max_keys]


async def _dispatch(name: str, a: dict) -> str:
    s3 = _s3()

    # ── Bucket Operations ─────────────────────────────────────────────────────
    if name == "list_buckets":
        resp = s3.list_buckets()
        buckets = [{"name": b["Name"], "created": b["CreationDate"]}
                   for b in resp.get("Buckets", [])]
        if a.get("name_filter"):
            f = a["name_filter"].lower()
            buckets = [b for b in buckets if f in b["name"].lower()]
        return f"{len(buckets)} bucket(s):\n{_fmt(buckets)}"

    if name == "get_bucket_info":
        bucket = a["bucket"]
        info: dict = {"bucket": bucket}
        try:
            loc = s3.get_bucket_location(Bucket=bucket)
            info["region"] = loc.get("LocationConstraint") or "us-east-1"
        except Exception:
            info["region"] = "unknown"
        try:
            ver = s3.get_bucket_versioning(Bucket=bucket)
            info["versioning"] = ver.get("Status", "Disabled")
        except Exception:
            pass
        try:
            tags = s3.get_bucket_tagging(Bucket=bucket)
            info["tags"] = {t["Key"]: t["Value"] for t in tags.get("TagSet", [])}
        except Exception:
            info["tags"] = {}
        return _fmt(info)

    if name == "get_bucket_location":
        resp = s3.get_bucket_location(Bucket=a["bucket"])
        region = resp.get("LocationConstraint") or "us-east-1"
        return f"Bucket '{a['bucket']}' is in region: {region}"

    # ── Object Browsing ───────────────────────────────────────────────────────
    if name == "list_objects":
        kwargs: dict = {
            "Bucket": a["bucket"],
            "MaxKeys": a.get("max_keys", 100)
        }
        if a.get("prefix"):
            kwargs["Prefix"] = a["prefix"]
        if a.get("delimiter"):
            kwargs["Delimiter"] = a["delimiter"]
        if a.get("continuation_token"):
            kwargs["ContinuationToken"] = a["continuation_token"]
        resp = s3.list_objects_v2(**kwargs)
        objects = [
            {"key": o["Key"], "size": _human_size(o["Size"]),
             "size_bytes": o["Size"], "last_modified": o["LastModified"],
             "etag": o["ETag"].strip('"')}
            for o in resp.get("Contents", [])
        ]
        sort_by = a.get("sort_by", "key")
        if sort_by == "size":
            objects.sort(key=lambda x: x["size_bytes"], reverse=True)
        elif sort_by == "last_modified":
            objects.sort(key=lambda x: str(x["last_modified"]), reverse=True)
        summary = (f"{len(objects)} object(s) in s3://{a['bucket']}/{a.get('prefix','')}\n"
                   f"IsTruncated: {resp.get('IsTruncated', False)}\n")
        if resp.get("NextContinuationToken"):
            summary += f"NextContinuationToken: {resp['NextContinuationToken']}\n"
        return summary + "\n" + _fmt(objects)

    if name == "list_common_prefixes":
        bucket = a["bucket"]
        prefix = a.get("prefix", "")
        resp = s3.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
        prefixes = [p["Prefix"] for p in resp.get("CommonPrefixes", [])]
        if a.get("recursive") and prefixes:
            all_prefixes = list(prefixes)
            for p in prefixes:
                sub = s3.list_objects_v2(Bucket=bucket, Prefix=p, Delimiter="/")
                all_prefixes.extend([sp["Prefix"] for sp in sub.get("CommonPrefixes", [])])
            prefixes = all_prefixes
        return f"{len(prefixes)} folder(s) under s3://{bucket}/{prefix}:\n{_fmt(prefixes)}"

    if name == "search_objects":
        objects = _paginate_all(s3, a["bucket"], a.get("prefix",""), max_keys=5000)
        term = a["search_term"]
        case = a.get("case_sensitive", False)
        matches = []
        for o in objects:
            key = o["Key"]
            haystack = key if case else key.lower()
            needle = term if case else term.lower()
            if needle in haystack:
                matches.append({
                    "key": key, "size": _human_size(o["Size"]),
                    "last_modified": o["LastModified"]
                })
            if len(matches) >= a.get("max_results", 50):
                break
        return f"Found {len(matches)} match(es) for '{term}':\n{_fmt(matches)}"

    if name == "check_file_exists":
        try:
            s3.head_object(Bucket=a["bucket"], Key=a["key"])
            return f"✅ EXISTS: s3://{a['bucket']}/{a['key']}"
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                return f"❌ NOT FOUND: s3://{a['bucket']}/{a['key']}"
            raise

    if name == "get_object_metadata":
        resp = s3.head_object(Bucket=a["bucket"], Key=a["key"])
        meta = {
            "key": a["key"], "bucket": a["bucket"],
            "size": _human_size(resp["ContentLength"]),
            "size_bytes": resp["ContentLength"],
            "content_type": resp.get("ContentType",""),
            "last_modified": resp["LastModified"],
            "etag": resp["ETag"].strip('"'),
            "version_id": resp.get("VersionId",""),
            "custom_metadata": resp.get("Metadata",{})
        }
        try:
            tags = s3.get_object_tagging(Bucket=a["bucket"], Key=a["key"])
            meta["tags"] = {t["Key"]: t["Value"] for t in tags.get("TagSet",[])}
        except Exception:
            pass
        return _fmt(meta)

    if name == "list_object_versions":
        resp = s3.list_object_versions(
            Bucket=a["bucket"], Prefix=a["key"],
            MaxKeys=a.get("max_versions", 20)
        )
        versions = [
            {"version_id": v["VersionId"], "last_modified": v["LastModified"],
             "size": _human_size(v["Size"]), "is_latest": v["IsLatest"],
             "etag": v["ETag"].strip('"')}
            for v in resp.get("Versions", [])
        ]
        return f"{len(versions)} version(s) of {a['key']}:\n{_fmt(versions)}"

    # ── Object Read ───────────────────────────────────────────────────────────
    if name == "get_object_content":
        kwargs: dict = {"Bucket": a["bucket"], "Key": a["key"]}
        if a.get("version_id"):
            kwargs["VersionId"] = a["version_id"]
        resp = s3.get_object(**kwargs)
        max_bytes = a.get("max_bytes", 102400)
        body = resp["Body"].read(max_bytes)
        content = body.decode(a.get("encoding", "utf-8"), errors="replace")
        size = resp["ContentLength"]
        truncated = size > max_bytes
        header = (f"s3://{a['bucket']}/{a['key']}\n"
                  f"Size: {_human_size(size)} | Type: {resp.get('ContentType','')}\n"
                  f"{'[TRUNCATED to first ' + str(max_bytes) + ' bytes]' if truncated else ''}\n"
                  f"{'─'*60}\n")
        return header + content

    if name == "get_presigned_url":
        url = s3.generate_presigned_url(
            ClientMethod=a.get("operation","get_object"),
            Params={"Bucket": a["bucket"], "Key": a["key"]},
            ExpiresIn=a.get("expiry_seconds", 3600)
        )
        return (f"Pre-signed URL (expires in {a.get('expiry_seconds',3600)}s):\n{url}")

    # ── Object Write ──────────────────────────────────────────────────────────
    if name == "upload_text_content":
        s3.put_object(
            Bucket=a["bucket"], Key=a["key"],
            Body=a["content"].encode("utf-8"),
            ContentType=a.get("content_type","text/plain"),
            Metadata={str(k): str(v) for k,v in a.get("metadata",{}).items()}
        )
        return f"✅ Uploaded {len(a['content'])} chars to s3://{a['bucket']}/{a['key']}"

    if name == "copy_object":
        source = {"Bucket": a["source_bucket"], "Key": a["source_key"]}
        if a.get("source_version_id"):
            source["VersionId"] = a["source_version_id"]
        s3.copy_object(CopySource=source, Bucket=a["dest_bucket"], Key=a["dest_key"])
        return (f"✅ Copied:\n"
                f"  FROM: s3://{a['source_bucket']}/{a['source_key']}\n"
                f"  TO  : s3://{a['dest_bucket']}/{a['dest_key']}")

    if name == "move_object":
        source = {"Bucket": a["source_bucket"], "Key": a["source_key"]}
        s3.copy_object(CopySource=source, Bucket=a["dest_bucket"], Key=a["dest_key"])
        s3.delete_object(Bucket=a["source_bucket"], Key=a["source_key"])
        return (f"✅ Moved:\n"
                f"  FROM: s3://{a['source_bucket']}/{a['source_key']}\n"
                f"  TO  : s3://{a['dest_bucket']}/{a['dest_key']}")

    if name == "delete_object":
        kwargs: dict = {"Bucket": a["bucket"], "Key": a["key"]}
        if a.get("version_id"):
            kwargs["VersionId"] = a["version_id"]
        s3.delete_object(**kwargs)
        return f"✅ Deleted: s3://{a['bucket']}/{a['key']}"

    if name == "delete_objects_by_prefix":
        if not a.get("confirm"):
            return "⚠️ confirm=true required to delete objects."
        objects = _paginate_all(s3, a["bucket"], a["prefix"])
        if not objects:
            return f"No objects found under s3://{a['bucket']}/{a['prefix']}"
        delete_list = [{"Key": o["Key"]} for o in objects]
        resp = s3.delete_objects(Bucket=a["bucket"], Delete={"Objects": delete_list})
        deleted = len(resp.get("Deleted", []))
        return f"✅ Deleted {deleted} objects from s3://{a['bucket']}/{a['prefix']}"

    # ── Download ──────────────────────────────────────────────────────────────
    if name == "download_file":
        key = a["key"]
        local_name = a.get("local_filename") or Path(key).name
        local_path = S3_DOWNLOAD_DIR / local_name
        S3_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
        s3.download_file(a["bucket"], key, str(local_path))
        size = local_path.stat().st_size
        return f"✅ Downloaded to {local_path} ({_human_size(size)})"

    if name == "download_folder":
        objects = _paginate_all(s3, a["bucket"], a["prefix"],
                                max_keys=a.get("max_files", 50))
        local_base = S3_DOWNLOAD_DIR / (a.get("local_dir") or Path(a["prefix"]).name or "s3_download")
        local_base.mkdir(parents=True, exist_ok=True)
        downloaded = []
        for o in objects[:a.get("max_files", 50)]:
            rel_key = o["Key"][len(a["prefix"]):].lstrip("/")
            local_path = local_base / rel_key
            local_path.parent.mkdir(parents=True, exist_ok=True)
            s3.download_file(a["bucket"], o["Key"], str(local_path))
            downloaded.append(str(local_path))
        return f"✅ Downloaded {len(downloaded)} files to {local_base}:\n" + "\n".join(downloaded)

    # ── Analytics ─────────────────────────────────────────────────────────────
    if name == "get_bucket_size":
        objects = _paginate_all(s3, a["bucket"], a.get("prefix",""),
                                max_keys=a.get("max_objects_to_scan", 10000))
        total = sum(o["Size"] for o in objects)
        return (f"s3://{a['bucket']}/{a.get('prefix','')}\n"
                f"Total objects : {len(objects):,}\n"
                f"Total size    : {_human_size(total)} ({total:,} bytes)")

    if name == "count_objects_by_prefix":
        resp = s3.list_objects_v2(
            Bucket=a["bucket"],
            Prefix=a.get("prefix",""),
            Delimiter=a.get("delimiter","/"
        ))
        folder_counts = {}
        for cp in resp.get("CommonPrefixes",[]):
            sub_objs = _paginate_all(s3, a["bucket"], cp["Prefix"], max_keys=1000)
            folder_counts[cp["Prefix"]] = {"count": len(sub_objs),
                                           "size": _human_size(sum(o["Size"] for o in sub_objs))}
        return _fmt(folder_counts)

    if name == "find_recent_objects":
        objects = _paginate_all(s3, a["bucket"], a.get("prefix",""), max_keys=5000)
        if a.get("since_hours"):
            cutoff = datetime.now(timezone.utc)
            from datetime import timedelta
            cutoff = cutoff - timedelta(hours=a["since_hours"])
            objects = [o for o in objects if o["LastModified"].replace(tzinfo=timezone.utc) > cutoff
                       if hasattr(o["LastModified"], "replace")]
        sorted_objs = sorted(objects, key=lambda x: x["LastModified"], reverse=True)[:a.get("top_n",10)]
        result = [{"key": o["Key"], "last_modified": o["LastModified"],
                   "size": _human_size(o["Size"])} for o in sorted_objs]
        return f"Top {len(result)} most recent objects:\n{_fmt(result)}"

    if name == "find_objects_by_extension":
        ext = a["extension"].lower().lstrip(".")
        objects = _paginate_all(s3, a["bucket"], a.get("prefix",""), max_keys=10000)
        matches = [
            {"key": o["Key"], "size": _human_size(o["Size"]), "last_modified": o["LastModified"]}
            for o in objects if o["Key"].lower().endswith(f".{ext}")
        ][:a.get("max_results",100)]
        return f"Found {len(matches)} .{ext} files:\n{_fmt(matches)}"

    if name == "compare_prefixes":
        def _get_keys(bkt, prefix):
            objs = _paginate_all(s3, bkt, prefix, max_keys=10000)
            by = a.get("compare_by","key")
            if by == "key":
                base = len(prefix)
                return {o["Key"][base:].lstrip("/"): o for o in objs}
            return {o["Key"]: o for o in objs}

        a_map = _get_keys(a["bucket_a"], a["prefix_a"])
        b_map = _get_keys(a["bucket_b"], a["prefix_b"])
        only_a = sorted(set(a_map) - set(b_map))
        only_b = sorted(set(b_map) - set(a_map))
        in_both = sorted(set(a_map) & set(b_map))
        return (f"Comparison:\n"
                f"  A: s3://{a['bucket_a']}/{a['prefix_a']} ({len(a_map)} objects)\n"
                f"  B: s3://{a['bucket_b']}/{a['prefix_b']} ({len(b_map)} objects)\n\n"
                f"Only in A ({len(only_a)}): {only_a[:20]}\n"
                f"Only in B ({len(only_b)}): {only_b[:20]}\n"
                f"In both   ({len(in_both)}): {in_both[:20]}")

    # ── Assertions ────────────────────────────────────────────────────────────
    if name == "assert_file_exists":
        label = a.get("description", f"s3://{a['bucket']}/{a['key']} exists")
        try:
            s3.head_object(Bucket=a["bucket"], Key=a["key"])
            return f"✅ PASS — {label}"
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                return f"❌ FAIL — {label}\n  File not found: s3://{a['bucket']}/{a['key']}"
            raise

    if name == "assert_file_not_exists":
        label = a.get("description", f"s3://{a['bucket']}/{a['key']} does not exist")
        try:
            s3.head_object(Bucket=a["bucket"], Key=a["key"])
            return f"❌ FAIL — {label}\n  File EXISTS but was expected to be absent"
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                return f"✅ PASS — {label}"
            raise

    if name == "assert_file_newer_than":
        label = a.get("description", f"{a['key']} newer than {a['since_iso']}")
        resp = s3.head_object(Bucket=a["bucket"], Key=a["key"])
        last_mod = resp["LastModified"]
        from datetime import datetime as dt
        cutoff = dt.fromisoformat(a["since_iso"].replace("Z","+00:00"))
        passed = last_mod > cutoff
        status = "✅ PASS" if passed else "❌ FAIL"
        return (f"{status} — {label}\n"
                f"  File last modified: {last_mod}\n"
                f"  Cutoff            : {cutoff}")

    if name == "assert_prefix_has_files":
        ext = a.get("extension","").lower().lstrip(".")
        objects = _paginate_all(s3, a["bucket"], a["prefix"], max_keys=1000)
        if ext:
            objects = [o for o in objects if o["Key"].lower().endswith(f".{ext}")]
        count = len(objects)
        min_count = a.get("min_count", 1)
        passed = count >= min_count
        status = "✅ PASS" if passed else "❌ FAIL"
        label = a.get("description", f"s3://{a['bucket']}/{a['prefix']} has >= {min_count} file(s)")
        return (f"{status} — {label}\n"
                f"  Found: {count} file(s)\n"
                f"  Min  : {min_count}")

    return f"Unknown tool: {name}"


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream,
                         server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
