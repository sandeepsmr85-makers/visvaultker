"""
mcp_servers/browser_mcp/server.py
──────────────────────────────────
Browser Automation MCP Server (Playwright-based)

Full browser control: navigate, click, type, extract, screenshot, assert.
Claude can drive real browsers as part of any workflow — scrape data,
fill forms, test UI flows, take evidence screenshots, and more.

Tools exposed (22 total):
  Session       : browser_new_session, browser_close_session, browser_list_sessions
  Navigate      : browser_navigate, browser_go_back, browser_go_forward, browser_refresh
  Read          : browser_get_text, browser_get_page_source, browser_get_current_url
                  browser_find_elements, browser_extract_table, browser_screenshot
  Interact      : browser_click, browser_type, browser_fill_form
                  browser_select_option, browser_scroll
  Wait          : browser_wait_for_element, browser_wait_for_navigation
  Scripts       : browser_execute_script
  Assert        : browser_assert_text_present, browser_assert_url

Environment variables (set in backend/.env):
  BROWSER_HEADLESS          — 'true' (default) or 'false' for visible window
  BROWSER_TIMEOUT_MS        — default action timeout in ms (default: 10000)
  BROWSER_SCREENSHOT_DIR    — folder for saved screenshots (default: ./browser_shots)
  BROWSER_DEFAULT_TYPE      — 'chromium' | 'firefox' | 'webkit' (default: chromium)
  BROWSER_SLOW_MO_MS        — slow down actions by N ms, useful for debugging (default: 0)
"""

import asyncio
import base64
import json
import os
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from config.settings import (
    BROWSER_HEADLESS,
    BROWSER_TIMEOUT_MS,
    BROWSER_SCREENSHOT_DIR,
    BROWSER_DEFAULT_TYPE,
    BROWSER_SLOW_MO_MS,
)

# ─── Session registry ─────────────────────────────────────────────────────────
# Each session keeps a live Playwright browser + page.
# Sessions persist until browser_close_session is called (or the server stops).
#
# Structure:
#   SESSIONS[session_id] = {
#       "playwright": <Playwright instance>,
#       "browser":    <Browser>,
#       "context":    <BrowserContext>,
#       "page":       <Page>,
#       "created_at": ISO timestamp,
#       "browser_type": "chromium" | "firefox" | "webkit",
#   }

SESSIONS: dict[str, dict] = {}
_SESSION_LOCK = asyncio.Lock()

server = Server("browser-mcp")


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _session(session_id: str) -> dict:
    s = SESSIONS.get(session_id)
    if not s:
        raise ValueError(
            f"Session '{session_id}' not found. "
            f"Active sessions: {list(SESSIONS.keys()) or 'none'}. "
            f"Call browser_new_session first."
        )
    return s


def _screenshot_path(session_id: str, label: str = "") -> str:
    d = Path(BROWSER_SCREENSHOT_DIR)
    d.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = label.replace(" ", "_").replace("/", "-")[:30] if label else session_id[:8]
    return str(d / f"{ts}_{slug}.png")


def _fmt_elements(elements: list[dict]) -> str:
    if not elements:
        return "No elements found."
    lines = []
    for i, el in enumerate(elements, 1):
        parts = [f"[{i}] tag={el.get('tag','')}"]
        if el.get("text"):
            parts.append(f"text=\"{el['text'][:80]}\"")
        if el.get("id"):
            parts.append(f"id={el['id']}")
        if el.get("class"):
            parts.append(f"class={el['class'][:40]}")
        if el.get("href"):
            parts.append(f"href={el['href'][:60]}")
        if el.get("value"):
            parts.append(f"value={el['value'][:40]}")
        lines.append("  " + "  ".join(parts))
    return "\n".join(lines)


# ─── Tool definitions ─────────────────────────────────────────────────────────

@server.list_tools()
async def list_tools() -> list[Tool]:
    S = {"type": "string"}
    I = {"type": "integer"}
    B = {"type": "boolean"}

    def obj(required: list, **props):
        return {"type": "object", "required": required, "properties": props}

    return [

        # ── Session ──────────────────────────────────────────────────────────
        Tool(
            name="browser_new_session",
            description=(
                "Open a new browser session. Returns a session_id used by all other tools. "
                "Pass browser_type to choose chromium (default), firefox, or webkit. "
                "headless=false opens a visible window (useful for debugging). "
                "Call this before any other browser tool."
            ),
            inputSchema=obj(
                [],
                session_id={**S, "description": "Optional custom session ID. Auto-generated if omitted."},
                browser_type={**S, "enum": ["chromium", "firefox", "webkit"],
                              "description": "Browser engine (default: chromium)"},
                headless={**B, "description": "Run headless (default: true). Set false to see the window."},
            ),
        ),

        Tool(
            name="browser_close_session",
            description="Close a browser session and free all resources. Always call this when done.",
            inputSchema=obj(["session_id"], session_id={**S, "description": "Session ID to close."}),
        ),

        Tool(
            name="browser_list_sessions",
            description="List all active browser sessions with their current URLs and creation times.",
            inputSchema=obj([]),
        ),

        # ── Navigate ─────────────────────────────────────────────────────────
        Tool(
            name="browser_navigate",
            description=(
                "Navigate to a URL. Waits for the page to load before returning. "
                "Returns page title and final URL (useful to detect redirects)."
            ),
            inputSchema=obj(
                ["session_id", "url"],
                session_id={**S, "description": "Active session ID."},
                url={**S, "description": "Full URL to navigate to (include https://)."},
                wait_until={**S, "enum": ["load", "domcontentloaded", "networkidle"],
                            "description": "When to consider navigation complete (default: load)."},
                timeout_ms={**I, "description": "Override default timeout in ms."},
            ),
        ),

        Tool(
            name="browser_go_back",
            description="Navigate back in the browser history.",
            inputSchema=obj(["session_id"], session_id={**S}),
        ),

        Tool(
            name="browser_go_forward",
            description="Navigate forward in the browser history.",
            inputSchema=obj(["session_id"], session_id={**S}),
        ),

        Tool(
            name="browser_refresh",
            description="Reload the current page.",
            inputSchema=obj(["session_id"], session_id={**S}),
        ),

        # ── Read ─────────────────────────────────────────────────────────────
        Tool(
            name="browser_get_text",
            description=(
                "Get all visible text content from the current page. "
                "Strips scripts and styles. Use this to read page content before deciding what to click."
            ),
            inputSchema=obj(
                ["session_id"],
                session_id={**S},
                selector={**S, "description": "CSS selector to limit extraction to a subtree (optional)."},
                max_chars={**I, "description": "Truncate output to this many chars (default: 5000)."},
            ),
        ),

        Tool(
            name="browser_get_page_source",
            description="Get the full HTML source of the current page. Use sparingly — prefer browser_get_text.",
            inputSchema=obj(
                ["session_id"],
                session_id={**S},
                max_chars={**I, "description": "Truncate HTML to this many chars (default: 10000)."},
            ),
        ),

        Tool(
            name="browser_get_current_url",
            description="Get the current URL and page title of the session.",
            inputSchema=obj(["session_id"], session_id={**S}),
        ),

        Tool(
            name="browser_find_elements",
            description=(
                "Find elements matching a CSS selector. Returns tag, text, id, class, href, value. "
                "Use to discover interactive elements before clicking."
            ),
            inputSchema=obj(
                ["session_id", "selector"],
                session_id={**S},
                selector={**S, "description": "CSS selector (e.g. 'a', 'button', 'input[type=text]', '#submit')."},
                limit={**I, "description": "Max elements to return (default: 20)."},
            ),
        ),

        Tool(
            name="browser_extract_table",
            description=(
                "Extract a table from the page as structured JSON. "
                "Returns headers and rows. If multiple tables exist, picks the Nth one (0-indexed)."
            ),
            inputSchema=obj(
                ["session_id"],
                session_id={**S},
                selector={**S, "description": "CSS selector for the table (default: 'table')."},
                table_index={**I, "description": "Which table to extract if selector matches multiple (default: 0)."},
            ),
        ),

        Tool(
            name="browser_screenshot",
            description=(
                "Take a screenshot of the current page and save it to disk. "
                "Returns the file path. Use to capture evidence or visually verify a workflow step."
            ),
            inputSchema=obj(
                ["session_id"],
                session_id={**S},
                label={**S, "description": "Label used in the filename (e.g. 'after_login', 'results_page')."},
                full_page={**B, "description": "Capture full scrollable page (default: false = viewport only)."},
            ),
        ),

        # ── Interact ─────────────────────────────────────────────────────────
        Tool(
            name="browser_click",
            description=(
                "Click an element identified by CSS selector or visible text. "
                "Prefer selector for precision; use text for buttons/links when selector is unknown."
            ),
            inputSchema=obj(
                ["session_id"],
                session_id={**S},
                selector={**S, "description": "CSS selector to click (e.g. '#submit', 'button.primary')."},
                text={**S, "description": "Visible text of the element to click (used if selector not given)."},
                timeout_ms={**I, "description": "Override default timeout in ms."},
            ),
        ),

        Tool(
            name="browser_type",
            description=(
                "Type text into an input field. Clears existing content first by default. "
                "Use selector to identify the field."
            ),
            inputSchema=obj(
                ["session_id", "selector", "text"],
                session_id={**S},
                selector={**S, "description": "CSS selector for the input field."},
                text={**S, "description": "Text to type."},
                clear_first={**B, "description": "Clear existing content before typing (default: true)."},
                press_enter={**B, "description": "Press Enter after typing (default: false)."},
            ),
        ),

        Tool(
            name="browser_fill_form",
            description=(
                "Fill multiple form fields at once. Provide a list of {selector, value} pairs. "
                "More efficient than calling browser_type repeatedly."
            ),
            inputSchema=obj(
                ["session_id", "fields"],
                session_id={**S},
                fields={
                    "type": "array",
                    "description": "List of {selector, value} objects to fill.",
                    "items": {
                        "type": "object",
                        "required": ["selector", "value"],
                        "properties": {
                            "selector": {**S, "description": "CSS selector for the field."},
                            "value":    {**S, "description": "Value to enter."},
                        },
                    },
                },
                submit_selector={**S, "description": "CSS selector of submit button to click after filling (optional)."},
            ),
        ),

        Tool(
            name="browser_select_option",
            description="Select an option from a <select> dropdown by value or visible label.",
            inputSchema=obj(
                ["session_id", "selector"],
                session_id={**S},
                selector={**S, "description": "CSS selector for the <select> element."},
                value={**S, "description": "Option value attribute to select."},
                label={**S, "description": "Visible label text of the option to select (used if value not given)."},
            ),
        ),

        Tool(
            name="browser_scroll",
            description="Scroll the page or a specific element. Use to load lazy content or reach off-screen elements.",
            inputSchema=obj(
                ["session_id"],
                session_id={**S},
                direction={**S, "enum": ["down", "up", "bottom", "top"],
                           "description": "Scroll direction. 'bottom'/'top' jump to page extremes."},
                pixels={**I, "description": "Pixels to scroll for 'up'/'down' (default: 500)."},
                selector={**S, "description": "Scroll within this element instead of the window (optional)."},
            ),
        ),

        # ── Wait ─────────────────────────────────────────────────────────────
        Tool(
            name="browser_wait_for_element",
            description=(
                "Wait until an element matching a CSS selector appears (or disappears) on the page. "
                "Returns when condition is met. Useful after triggering async actions."
            ),
            inputSchema=obj(
                ["session_id", "selector"],
                session_id={**S},
                selector={**S, "description": "CSS selector to wait for."},
                state={**S, "enum": ["visible", "hidden", "attached", "detached"],
                       "description": "Element state to wait for (default: visible)."},
                timeout_ms={**I, "description": "Max ms to wait (default: 10000)."},
            ),
        ),

        Tool(
            name="browser_wait_for_navigation",
            description="Wait for the page to finish navigating (e.g. after a form submit that triggers a redirect).",
            inputSchema=obj(
                ["session_id"],
                session_id={**S},
                wait_until={**S, "enum": ["load", "domcontentloaded", "networkidle"],
                            "description": "Navigation complete condition (default: load)."},
                timeout_ms={**I, "description": "Max ms to wait (default: 10000)."},
            ),
        ),

        # ── Scripts ───────────────────────────────────────────────────────────
        Tool(
            name="browser_execute_script",
            description=(
                "Execute JavaScript in the page context and return the result. "
                "Use for complex DOM queries, triggering custom events, or reading JS variables."
            ),
            inputSchema=obj(
                ["session_id", "script"],
                session_id={**S},
                script={**S, "description": "JavaScript to execute. Use 'return' to get a value back."},
            ),
        ),

        # ── Assert ────────────────────────────────────────────────────────────
        Tool(
            name="browser_assert_text_present",
            description=(
                "Assert that specific text appears on the current page. "
                "Returns PASS with context snippet or FAIL with page summary."
            ),
            inputSchema=obj(
                ["session_id", "text"],
                session_id={**S},
                text={**S, "description": "Text to search for on the page."},
                case_sensitive={**B, "description": "Case-sensitive match (default: false)."},
            ),
        ),

        Tool(
            name="browser_assert_url",
            description=(
                "Assert the current URL matches an expected value or pattern. "
                "Returns PASS or FAIL with actual URL."
            ),
            inputSchema=obj(
                ["session_id", "expected_url"],
                session_id={**S},
                expected_url={**S, "description": "Expected URL string or substring to match."},
                match_type={**S, "enum": ["exact", "contains", "startswith"],
                            "description": "How to compare (default: contains)."},
            ),
        ),
    ]


# ─── Tool implementations ─────────────────────────────────────────────────────

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await _dispatch(name, arguments)
        return [TextContent(type="text", text=result)]
    except Exception as e:
        return [TextContent(type="text", text=f"❌ Error ({type(e).__name__}): {e}")]


async def _dispatch(name: str, a: dict) -> str:  # noqa: C901

    # ── Session management ────────────────────────────────────────────────────

    if name == "browser_new_session":
        from playwright.async_api import async_playwright
        sid = a.get("session_id") or str(uuid.uuid4())[:8]
        if sid in SESSIONS:
            return f"⚠️ Session '{sid}' already exists. Close it first or use a different ID."
        btype = a.get("browser_type", BROWSER_DEFAULT_TYPE)
        headless = a.get("headless", BROWSER_HEADLESS)
        pw = await async_playwright().start()
        launcher = getattr(pw, btype)
        browser = await launcher.launch(
            headless=headless,
            slow_mo=BROWSER_SLOW_MO_MS,
        )
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
        )
        page = await context.new_page()
        page.set_default_timeout(BROWSER_TIMEOUT_MS)
        async with _SESSION_LOCK:
            SESSIONS[sid] = {
                "playwright": pw,
                "browser": browser,
                "context": context,
                "page": page,
                "created_at": datetime.now().isoformat(),
                "browser_type": btype,
            }
        return (
            f"✅ Browser session opened\n"
            f"Session ID  : {sid}\n"
            f"Browser     : {btype}\n"
            f"Headless    : {headless}\n"
            f"Viewport    : 1280×800\n\n"
            f"Use session_id='{sid}' in all subsequent browser tools."
        )

    if name == "browser_close_session":
        sid = a["session_id"]
        s = _session(sid)
        await s["browser"].close()
        await s["playwright"].stop()
        async with _SESSION_LOCK:
            del SESSIONS[sid]
        return f"✅ Session '{sid}' closed. Browser and all resources released."

    if name == "browser_list_sessions":
        if not SESSIONS:
            return "No active browser sessions."
        lines = ["Active browser sessions:"]
        for sid, s in SESSIONS.items():
            try:
                url = s["page"].url
            except Exception:
                url = "unknown"
            lines.append(
                f"  • {sid} | {s['browser_type']} | created {s['created_at']} | url={url}"
            )
        return "\n".join(lines)

    # ── Navigate ──────────────────────────────────────────────────────────────

    if name == "browser_navigate":
        page = _session(a["session_id"])["page"]
        url = a["url"]
        wait_until = a.get("wait_until", "load")
        timeout = a.get("timeout_ms", BROWSER_TIMEOUT_MS)
        t0 = time.time()
        response = await page.goto(url, wait_until=wait_until, timeout=timeout)
        elapsed = time.time() - t0
        title = await page.title()
        status = response.status if response else "unknown"
        return (
            f"✅ Navigated\n"
            f"URL       : {page.url}\n"
            f"Title     : {title}\n"
            f"Status    : {status}\n"
            f"Elapsed   : {elapsed:.2f}s"
        )

    if name == "browser_go_back":
        page = _session(a["session_id"])["page"]
        await page.go_back()
        return f"✅ Navigated back → {page.url}"

    if name == "browser_go_forward":
        page = _session(a["session_id"])["page"]
        await page.go_forward()
        return f"✅ Navigated forward → {page.url}"

    if name == "browser_refresh":
        page = _session(a["session_id"])["page"]
        await page.reload()
        title = await page.title()
        return f"✅ Page refreshed | {page.url} | \"{title}\""

    # ── Read ──────────────────────────────────────────────────────────────────

    if name == "browser_get_text":
        page = _session(a["session_id"])["page"]
        selector = a.get("selector", "body")
        max_chars = a.get("max_chars", 5000)
        el = await page.query_selector(selector)
        if not el:
            return f"❌ No element found for selector '{selector}'"
        text = await el.inner_text()
        truncated = len(text) > max_chars
        out = text[:max_chars]
        suffix = f"\n\n[... truncated — {len(text)} total chars, showing first {max_chars}]" if truncated else ""
        return f"Page text ({page.url}):\n{'─'*50}\n{out}{suffix}"

    if name == "browser_get_page_source":
        page = _session(a["session_id"])["page"]
        max_chars = a.get("max_chars", 10000)
        html = await page.content()
        truncated = len(html) > max_chars
        out = html[:max_chars]
        suffix = f"\n<!-- truncated: {len(html)} total chars, showing {max_chars} -->" if truncated else ""
        return out + suffix

    if name == "browser_get_current_url":
        page = _session(a["session_id"])["page"]
        title = await page.title()
        return f"URL   : {page.url}\nTitle : {title}"

    if name == "browser_find_elements":
        page = _session(a["session_id"])["page"]
        selector = a["selector"]
        limit = a.get("limit", 20)
        els = await page.query_selector_all(selector)
        results = []
        for el in els[:limit]:
            tag = await el.evaluate("e => e.tagName.toLowerCase()")
            text = (await el.inner_text()).strip()[:100]
            eid = await el.get_attribute("id") or ""
            cls = await el.get_attribute("class") or ""
            href = await el.get_attribute("href") or ""
            val = await el.get_attribute("value") or ""
            results.append({"tag": tag, "text": text, "id": eid, "class": cls, "href": href, "value": val})
        header = f"Found {len(els)} element(s) for '{selector}' (showing {min(len(els), limit)}):\n"
        return header + _fmt_elements(results)

    if name == "browser_extract_table":
        page = _session(a["session_id"])["page"]
        selector = a.get("selector", "table")
        idx = a.get("table_index", 0)
        tables = await page.query_selector_all(selector)
        if not tables:
            return f"❌ No table found matching '{selector}'"
        if idx >= len(tables):
            return f"❌ Table index {idx} out of range (found {len(tables)} tables)"
        table = tables[idx]
        data = await table.evaluate("""el => {
            const rows = Array.from(el.querySelectorAll('tr'));
            const headers = Array.from(rows[0]?.querySelectorAll('th,td') || []).map(c => c.innerText.trim());
            const body = rows.slice(1).map(r =>
                Array.from(r.querySelectorAll('td,th')).map(c => c.innerText.trim())
            );
            return { headers, rows: body };
        }""")
        total = len(data["rows"])
        out = {
            "table_index": idx,
            "headers": data["headers"],
            "row_count": total,
            "rows": data["rows"][:50],  # cap at 50 rows in output
        }
        if total > 50:
            out["note"] = f"Showing 50 of {total} rows"
        return json.dumps(out, indent=2)

    if name == "browser_screenshot":
        s = _session(a["session_id"])
        page = s["page"]
        label = a.get("label", "")
        full_page = a.get("full_page", False)
        path = _screenshot_path(a["session_id"], label)
        await page.screenshot(path=path, full_page=full_page)
        size = Path(path).stat().st_size
        return (
            f"📸 Screenshot saved\n"
            f"Path       : {path}\n"
            f"URL        : {page.url}\n"
            f"Full page  : {full_page}\n"
            f"Size       : {size // 1024} KB"
        )

    # ── Interact ──────────────────────────────────────────────────────────────

    if name == "browser_click":
        page = _session(a["session_id"])["page"]
        timeout = a.get("timeout_ms", BROWSER_TIMEOUT_MS)
        if a.get("selector"):
            await page.click(a["selector"], timeout=timeout)
            return f"✅ Clicked '{a['selector']}'"
        elif a.get("text"):
            await page.get_by_text(a["text"]).first.click(timeout=timeout)
            return f"✅ Clicked element with text \"{a['text']}\""
        else:
            return "❌ Provide either 'selector' or 'text'."

    if name == "browser_type":
        page = _session(a["session_id"])["page"]
        selector = a["selector"]
        text = a["text"]
        clear_first = a.get("clear_first", True)
        press_enter = a.get("press_enter", False)
        if clear_first:
            await page.fill(selector, "")
        await page.type(selector, text)
        if press_enter:
            await page.press(selector, "Enter")
        return f"✅ Typed into '{selector}': \"{text[:60]}{'...' if len(text)>60 else ''}\""

    if name == "browser_fill_form":
        page = _session(a["session_id"])["page"]
        fields = a["fields"]
        filled = []
        for f in fields:
            await page.fill(f["selector"], f["value"])
            filled.append(f"  ✓ {f['selector']} = \"{f['value'][:40]}\"")
        if a.get("submit_selector"):
            await page.click(a["submit_selector"])
            filled.append(f"  ✓ Submitted via '{a['submit_selector']}'")
        return f"✅ Form filled ({len(fields)} field(s)):\n" + "\n".join(filled)

    if name == "browser_select_option":
        page = _session(a["session_id"])["page"]
        selector = a["selector"]
        if a.get("value"):
            await page.select_option(selector, value=a["value"])
            return f"✅ Selected value='{a['value']}' in '{selector}'"
        elif a.get("label"):
            await page.select_option(selector, label=a["label"])
            return f"✅ Selected label='{a['label']}' in '{selector}'"
        else:
            return "❌ Provide either 'value' or 'label'."

    if name == "browser_scroll":
        page = _session(a["session_id"])["page"]
        direction = a.get("direction", "down")
        pixels = a.get("pixels", 500)
        if a.get("selector"):
            el = await page.query_selector(a["selector"])
            if not el:
                return f"❌ Element '{a['selector']}' not found"
            await el.scroll_into_view_if_needed()
            return f"✅ Scrolled '{a['selector']}' into view"
        if direction == "bottom":
            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        elif direction == "top":
            await page.evaluate("window.scrollTo(0, 0)")
        elif direction == "down":
            await page.evaluate(f"window.scrollBy(0, {pixels})")
        elif direction == "up":
            await page.evaluate(f"window.scrollBy(0, -{pixels})")
        return f"✅ Scrolled {direction}" + (f" by {pixels}px" if direction in ("up", "down") else "")

    # ── Wait ──────────────────────────────────────────────────────────────────

    if name == "browser_wait_for_element":
        page = _session(a["session_id"])["page"]
        selector = a["selector"]
        state = a.get("state", "visible")
        timeout = a.get("timeout_ms", BROWSER_TIMEOUT_MS)
        t0 = time.time()
        await page.wait_for_selector(selector, state=state, timeout=timeout)
        elapsed = time.time() - t0
        return f"✅ Element '{selector}' is now {state} (waited {elapsed:.2f}s)"

    if name == "browser_wait_for_navigation":
        page = _session(a["session_id"])["page"]
        wait_until = a.get("wait_until", "load")
        timeout = a.get("timeout_ms", BROWSER_TIMEOUT_MS)
        async with page.expect_navigation(wait_until=wait_until, timeout=timeout):
            pass
        return f"✅ Navigation complete | {page.url}"

    # ── Scripts ───────────────────────────────────────────────────────────────

    if name == "browser_execute_script":
        page = _session(a["session_id"])["page"]
        script = a["script"]
        result = await page.evaluate(script)
        out = json.dumps(result, indent=2) if result is not None else "(no return value)"
        return f"Script result:\n{out}"

    # ── Assert ────────────────────────────────────────────────────────────────

    if name == "browser_assert_text_present":
        page = _session(a["session_id"])["page"]
        target = a["text"]
        case_sensitive = a.get("case_sensitive", False)
        body_el = await page.query_selector("body")
        page_text = await body_el.inner_text() if body_el else ""
        haystack = page_text if case_sensitive else page_text.lower()
        needle = target if case_sensitive else target.lower()
        found = needle in haystack
        if found:
            # Find a context snippet
            idx = haystack.find(needle)
            start = max(0, idx - 80)
            end = min(len(haystack), idx + len(needle) + 80)
            snippet = page_text[start:end].replace("\n", " ").strip()
            return (
                f"✅ PASS — Text found on {page.url}\n"
                f"Search    : \"{target}\"\n"
                f"Context   : \"...{snippet}...\""
            )
        else:
            preview = page_text[:300].replace("\n", " ")
            return (
                f"❌ FAIL — Text not found on {page.url}\n"
                f"Search    : \"{target}\"\n"
                f"Page preview: \"{preview}...\""
            )

    if name == "browser_assert_url":
        page = _session(a["session_id"])["page"]
        expected = a["expected_url"]
        match_type = a.get("match_type", "contains")
        actual = page.url
        if match_type == "exact":
            passed = actual == expected
        elif match_type == "startswith":
            passed = actual.startswith(expected)
        else:  # contains
            passed = expected in actual
        status = "✅ PASS" if passed else "❌ FAIL"
        return (
            f"{status} — URL assertion\n"
            f"Match type : {match_type}\n"
            f"Expected   : {expected}\n"
            f"Actual     : {actual}"
        )

    return f"Unknown tool: {name}"


# ─── Entry point ──────────────────────────────────────────────────────────────

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream,
                         server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
