# Adding a New MCP Service

This guide shows you how to add any new service (Slack, Jira, Snowflake, etc.)
so Claude automatically uses it in workflows.

## The 4-Step Pattern

### Step 1 — Create the MCP server

Copy `backend/mcp_servers/custom_mcp/server.py` to a new folder:

```bash
cp -r backend/mcp_servers/custom_mcp backend/mcp_servers/slack_mcp
```

Edit `backend/mcp_servers/slack_mcp/server.py`:

```python
server = Server("slack-mcp")

@server.list_tools()
async def list_tools():
    return [
        Tool(name="send_slack_message",
             description="Send a message to a Slack channel.",
             inputSchema={"type":"object","required":["channel","message"],
                          "properties":{"channel":{"type":"string"},"message":{"type":"string"}}}),
        Tool(name="get_slack_channel_history",
             description="Get recent messages from a Slack channel.",
             inputSchema={"type":"object","required":["channel"],
                          "properties":{"channel":{"type":"string"},"limit":{"type":"integer","default":20}}}),
    ]

@server.call_tool()
async def call_tool(name, arguments):
    if name == "send_slack_message":
        # Use slack_sdk or requests to call Slack API
        response = requests.post("https://slack.com/api/chat.postMessage",
            headers={"Authorization": f"Bearer {os.getenv('SLACK_BOT_TOKEN')}"},
            json={"channel": arguments["channel"], "text": arguments["message"]})
        return [TextContent(type="text", text=f"Message sent to {arguments['channel']}")]
```

### Step 2 — Add to .env

```
SLACK_BOT_TOKEN=xoxb-your-token-here
```

### Step 3 — Register in mcp_config.json

```json
"slack": {
  "command": "python",
  "args": ["-m", "mcp_servers.slack_mcp.server"],
  "cwd": "/path/to/workflow-studio/backend",
  "env": { "SLACK_BOT_TOKEN": "xoxb-..." }
}
```

### Step 4 — Add to frontend WorkflowAI.jsx

In the `TOOL_MCP_MAP` object:
```js
send_slack_message: "slack",
get_slack_channel_history: "slack",
```

In the `MCP_META` object:
```js
slack: { color: "#4A154B", bg: "#1a0820", label: "SLACK" },
```

In the `ALL_TOOLS` array, add the tool schema (same as your Python definition but in JS object format).

In `executeTool()`, add a realistic mock response:
```js
send_slack_message: () => `✅ Message sent to #${toolInput.channel}`,
```

---

## Common Service Examples

### Slack
- `send_slack_message` — post to channel
- `get_channel_history` — read messages
- `create_slack_alert` — send formatted alert

### Jira
- `create_jira_ticket` — create issue
- `update_jira_ticket` — change status/fields
- `search_jira_issues` — JQL search
- `get_jira_ticket` — get issue details

### Snowflake
- `run_snowflake_query` — execute SQL
- `get_snowflake_schema` — describe table
- `export_snowflake_to_s3` — COPY INTO S3

### PostgreSQL
- Same pattern as SSMS MCP, use `psycopg2` instead of `pyodbc`

### Email (SMTP)
- `send_email` — send with attachments
- `send_html_email` — rich HTML email

### GitHub
- `create_pull_request`
- `get_repo_issues`
- `trigger_github_action`

### Generic REST API
```python
Tool(name="call_rest_api",
     description="Make an HTTP request to any REST endpoint.",
     inputSchema={"type":"object","required":["url","method"],
                  "properties":{"url":{"type":"string"},"method":{"type":"string","enum":["GET","POST","PUT","DELETE"]},
                                 "headers":{"type":"object"},"body":{"type":"object"}}})
```

This single tool lets Claude call any API you expose, making the system infinitely extensible.
