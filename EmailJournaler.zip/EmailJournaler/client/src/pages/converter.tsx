import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { FileUp, FileText, Download, RefreshCw, CheckCircle2, AlertCircle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ConversionResult } from "@shared/schema";

export default function Converter() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [conversionResult, setConversionResult] = useState<ConversionResult | null>(null);
  const { toast } = useToast();

  const convertMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("msgFile", file);
      
      const response = await fetch("/api/convert", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Conversion failed");
      }
      
      return response.json() as Promise<ConversionResult>;
    },
    onSuccess: (data) => {
      setConversionResult(data);
      toast({
        title: "Conversion successful",
        description: `Extracted ${data.emailCount} email(s) from ${data.filename}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Conversion failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const msgFile = files.find(f => f.name.toLowerCase().endsWith(".msg"));
    
    if (msgFile) {
      setSelectedFile(msgFile);
      setConversionResult(null);
    } else {
      toast({
        title: "Invalid file type",
        description: "Please upload a .msg file",
        variant: "destructive",
      });
    }
  }, [toast]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setSelectedFile(files[0]);
      setConversionResult(null);
    }
  }, []);

  const handleConvert = useCallback(() => {
    if (selectedFile) {
      convertMutation.mutate(selectedFile);
    }
  }, [selectedFile, convertMutation]);

  const handleDownload = useCallback(() => {
    if (conversionResult) {
      const blob = new Blob([conversionResult.textContent], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = conversionResult.filename.replace(/\.msg$/i, ".txt");
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  }, [conversionResult]);

  const handleReset = useCallback(() => {
    setSelectedFile(null);
    setConversionResult(null);
    convertMutation.reset();
  }, [convertMutation]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          {/* Header */}
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-medium text-foreground" data-testid="text-title">
              MSG to TXT Converter
            </h1>
            <p className="text-base text-muted-foreground" data-testid="text-subtitle">
              Convert Outlook MSG files to text format, including journaled emails with MIME headers
            </p>
          </div>

          {/* Status Messages */}
          {convertMutation.isError && (
            <Alert variant="destructive" data-testid="alert-error">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {convertMutation.error instanceof Error ? convertMutation.error.message : "An error occurred"}
              </AlertDescription>
            </Alert>
          )}

          {conversionResult && (
            <Alert className="border-primary bg-primary/5" data-testid="alert-success">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              <AlertDescription className="text-foreground">
                Successfully converted {conversionResult.emailCount} email(s) from {conversionResult.filename}
              </AlertDescription>
            </Alert>
          )}

          {/* Upload Zone */}
          {!selectedFile && !conversionResult && (
            <Card className="border-2 border-dashed transition-colors" data-testid="card-upload-zone">
              <CardContent className="p-0">
                <div
                  className={`h-64 flex flex-col items-center justify-center space-y-4 p-6 transition-colors cursor-pointer hover-elevate ${
                    isDragging ? "bg-accent" : ""
                  }`}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => document.getElementById("file-input")?.click()}
                  data-testid="dropzone-upload"
                >
                  <FileUp className="h-16 w-16 text-muted-foreground" />
                  <div className="text-center space-y-2">
                    <p className="text-lg font-medium text-foreground" data-testid="text-upload-instruction">
                      Drag and drop your MSG file here
                    </p>
                    <p className="text-sm text-muted-foreground" data-testid="text-upload-hint">
                      or click to browse
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground" data-testid="text-file-format">
                    Accepts: .msg files only
                  </p>
                  <input
                    id="file-input"
                    type="file"
                    accept=".msg"
                    className="hidden"
                    onChange={handleFileSelect}
                    data-testid="input-file"
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* File Info Card */}
          {selectedFile && !conversionResult && (
            <Card data-testid="card-file-info">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <FileText className="h-10 w-10 text-primary" />
                    <div className="space-y-1">
                      <p className="font-medium text-foreground" data-testid="text-filename">
                        {selectedFile.name}
                      </p>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <span data-testid="text-filesize">
                          {(selectedFile.size / 1024).toFixed(2)} KB
                        </span>
                        <span data-testid="text-timestamp">
                          {new Date().toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleReset}
                    data-testid="button-remove-file"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Conversion Progress */}
          {convertMutation.isPending && (
            <Card data-testid="card-progress">
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-foreground" data-testid="text-progress-status">
                      Processing...
                    </p>
                    <p className="text-sm text-muted-foreground">Extracting journaled emails</p>
                  </div>
                  <Progress value={undefined} className="h-2" data-testid="progress-conversion" />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Content Preview */}
          {conversionResult && (
            <Card data-testid="card-preview">
              <CardHeader className="space-y-1 pb-4">
                <CardTitle className="text-xl font-medium">Content Preview</CardTitle>
                <CardDescription>
                  {conversionResult.convertedSize.toLocaleString()} characters · {conversionResult.emailCount} email(s)
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 pt-0">
                <div className="relative">
                  <pre
                    className="h-96 overflow-auto bg-muted rounded-md p-4 text-sm font-mono border border-border"
                    data-testid="preview-content"
                  >
                    {conversionResult.textContent}
                  </pre>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            {!conversionResult && selectedFile && (
              <Button
                onClick={handleConvert}
                disabled={convertMutation.isPending}
                className="flex-1 min-h-10"
                data-testid="button-convert"
              >
                <FileText className="mr-2 h-4 w-4" />
                {convertMutation.isPending ? "Converting..." : "Convert to TXT"}
              </Button>
            )}

            {conversionResult && (
              <>
                <Button
                  onClick={handleDownload}
                  className="flex-1 min-h-10"
                  data-testid="button-download"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download TXT File
                </Button>
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="flex-1 min-h-10"
                  data-testid="button-convert-another"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Convert Another File
                </Button>
              </>
            )}
          </div>

          {/* Footer */}
          <div className="text-center pt-8">
            <p className="text-sm text-muted-foreground" data-testid="text-footer">
              Supports Microsoft Outlook MSG files with embedded and journaled emails
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
