import { z } from "zod";

export interface ConversionResult {
  filename: string;
  textContent: string;
  originalSize: number;
  convertedSize: number;
  timestamp: string;
  emailCount: number;
}

export const conversionResultSchema = z.object({
  filename: z.string(),
  textContent: z.string(),
  originalSize: z.number(),
  convertedSize: z.number(),
  timestamp: z.string(),
  emailCount: z.number(),
});

export type ConversionResultType = z.infer<typeof conversionResultSchema>;
