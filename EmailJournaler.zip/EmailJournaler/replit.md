# MSG to TXT Converter

## Overview

This is a web application that converts Microsoft Outlook MSG files to RFC 822 compliant text format. The tool is designed to extract email content from MSG files, including journaled/embedded emails, while preserving MIME headers and email metadata in standard RFC 822 format. It provides a simple drag-and-drop interface for uploading MSG files and downloading the converted text content.

The application is built as a full-stack TypeScript solution with a React frontend and Express backend, focusing on utility and ease of use for converting proprietary Outlook message formats into standard RFC 822 email format that can be imported back into email clients.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript using Vite as the build tool

**UI Component Library**: Shadcn/ui components built on Radix UI primitives, configured with the "new-york" style variant. The design system follows Material Design principles with Roboto typography and focuses on clarity and efficiency for file handling workflows.

**Styling**: Tailwind CSS with custom theme configuration supporting both light and dark modes. Uses HSL color system with CSS variables for theming flexibility.

**State Management**: TanStack Query (React Query) for server state management with a custom query client configured for API requests. No complex global state needed due to simple file conversion workflow.

**Routing**: Wouter for lightweight client-side routing (single-page converter application)

**Key Design Decisions**:
- Material Design approach chosen for utility-focused file conversion tool prioritizing usability
- Component-based architecture with reusable Shadcn/ui components
- Drag-and-drop file upload zone with visual feedback states
- Progress indicator during conversion process
- Text preview panel with monospace font for email content display

### Backend Architecture

**Runtime**: Node.js with Express server

**Language**: TypeScript with ES modules

**File Processing**: Uses `msgreader` library to parse Microsoft Outlook MSG binary format and extract email data including headers, body, attachments, and embedded messages

**API Design**: Simple REST endpoint (`POST /api/convert`) that accepts multipart form data with MSG file upload

**File Upload Handling**: Multer middleware configured with:
- In-memory storage (no disk persistence)
- 50MB file size limit
- MSG file type validation

**Development/Production Split**:
- Development mode: Vite dev server integration with HMR
- Production mode: Serves static built assets from Express

**Key Architectural Decisions**:
- Stateless conversion process - no file persistence or user sessions required
- In-memory processing chosen for security and simplicity (files not stored on server)
- Single-purpose API focused solely on MSG to TXT conversion
- Server-side parsing chosen because browser cannot natively handle MSG binary format

### Data Layer

**Database**: PostgreSQL configured via Drizzle ORM, though currently minimal/no database usage for core conversion functionality

**ORM**: Drizzle ORM with schema defined in `shared/schema.ts`

**Schema**: Defines `ConversionResult` interface for type-safe conversion responses including filename, text content, file sizes, timestamp, and email count

**Database Decision Rationale**: Infrastructure is in place for potential future features (conversion history, user accounts) but current implementation is stateless and doesn't require persistent storage for core functionality

### Shared Code

**Type Definitions**: Shared TypeScript types and Zod schemas in `shared/schema.ts` ensure type safety between frontend and backend

**Schema Validation**: Zod schemas for runtime validation of conversion results

## External Dependencies

### Core Libraries

- **msgreader**: Third-party library for parsing Microsoft Outlook MSG file format and extracting email data
- **@neondatabase/serverless**: Neon serverless PostgreSQL driver for database connectivity
- **drizzle-orm**: TypeScript ORM for database operations with PostgreSQL

### File Upload

- **multer**: Express middleware for handling multipart/form-data file uploads with memory storage

### Frontend UI Framework

- **@radix-ui/***: Comprehensive collection of unstyled, accessible UI primitives (dialogs, dropdowns, progress, tabs, etc.)
- **shadcn/ui**: Pre-built component patterns using Radix UI and Tailwind CSS
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **clsx** & **tailwind-merge**: Conditional className utilities

### State & Data Fetching

- **@tanstack/react-query**: Server state management and data synchronization
- **wouter**: Lightweight routing library for React

### Development Tools

- **vite**: Frontend build tool and dev server
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript/TypeScript bundler for production builds
- **@replit/vite-plugin-***: Replit-specific development tooling (runtime error modal, cartographer, dev banner)

### Validation & Forms

- **zod**: Schema validation library
- **drizzle-zod**: Integration between Drizzle ORM and Zod schemas
- **react-hook-form**: Form state management
- **@hookform/resolvers**: Validation resolver integrations

### Typography

- **Google Fonts**: Roboto (primary), DM Sans, Fira Code, Geist Mono, Architects Daughter

### Design System Considerations

Material Design chosen as the design approach because this is a utility-focused tool where efficiency and clarity are paramount. The component library provides excellent patterns for file handling interfaces with appropriate visual feedback states.