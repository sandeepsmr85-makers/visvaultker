# MSG to TXT Converter - Design Guidelines

## Design Approach
**Selected Approach:** Design System - Material Design  
**Justification:** This is a utility-focused file conversion tool where clarity, efficiency, and usability are paramount. Material Design provides excellent patterns for file handling, progress indicators, and user feedback.

## Core Design Elements

### Typography
- **Primary Font:** Roboto (Google Fonts)
- **Headings:** Roboto Medium, size progression: 2xl → xl → lg
- **Body Text:** Roboto Regular, base size with good line-height (1.6)
- **Labels/Metadata:** Roboto Regular, sm size for file details and status messages

### Layout System
**Spacing Primitives:** Tailwind units of 4, 6, 8, and 12  
- Consistent padding: p-6 for cards, p-4 for internal sections
- Vertical spacing: space-y-6 for major sections, space-y-4 for related elements
- Container: max-w-4xl centered for optimal workflow focus

### Component Library

**A. File Upload Zone**
- Large dropzone area (h-64) with dashed border
- Centered icon (document/upload indicator) with supporting text
- "Click to browse" secondary action below drag instructions
- Visual feedback on drag-over state
- Accepted file format indicator (.msg files only)

**B. File Information Card**
- Displays uploaded filename, size, and timestamp
- Close/remove icon for clearing selection
- Compact design with metadata in muted text

**C. Conversion Progress**
- Linear progress bar with percentage indicator
- Status text below ("Processing...", "Extracting journaled emails...", "Complete")
- Smooth transitions between states

**D. Content Preview Panel**
- Scrollable text area showing extracted content preview
- Monospace font for MIME headers and email content
- Max height with scroll (h-96) to prevent excessive page length
- Character/line count display at bottom

**E. Action Buttons**
- Primary: "Convert to TXT" (disabled until file selected)
- Secondary: "Download TXT File" (appears after conversion)
- Tertiary: "Convert Another File" (resets interface)
- Full-width on mobile, inline on desktop

**F. Status Messages**
- Success/error alerts with appropriate icons
- Positioned above main content area
- Dismissible with clear messaging

### Application Layout Structure
1. **Header:** Simple title "MSG to TXT Converter" with subtitle explaining functionality
2. **Main Workflow Area:** Single-column centered layout containing upload → process → preview → download flow
3. **Footer:** Minimal - supported formats note and basic info

### Interaction States
- Upload zone: Default → Hover → Drag-over → File-selected
- Buttons: Enabled/Disabled states with clear visual differentiation
- Progress indicator: Smooth animation, determinate when possible
- Preview panel: Lazy load content, show loading skeleton initially

### Responsive Behavior
- Desktop (lg+): All elements at full width within max-w-4xl container
- Mobile: Stack all elements vertically, full-width buttons, reduced padding (p-4)
- Touch-friendly hit areas (min h-12 for all interactive elements)

### Accessibility
- Clear focus indicators on all interactive elements
- Descriptive aria-labels for upload zone and progress
- Keyboard navigation support (Tab through workflow)
- Screen reader announcements for conversion status changes