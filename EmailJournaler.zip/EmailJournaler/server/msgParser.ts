import MsgReader from "msgreader";
import type { ConversionResult } from "@shared/schema";

interface EmailData {
  subject: string;
  from: string;
  to: string;
  cc: string;
  date: string;
  body: string;
  headers: string;
}

export async function parseMsgFile(buffer: Buffer, filename: string): Promise<ConversionResult> {
  const msgReader = new MsgReader(buffer);
  const fileData = msgReader.getFileData();
  
  let textContent = "";
  let emailCount = 0;
  
  // Extract main email
  const mainEmail = extractEmailData(fileData);
  textContent += formatEmailAsText(mainEmail, emailCount + 1);
  emailCount++;
  
  // Extract attachments (journaled/embedded emails)
  if (fileData.attachments && fileData.attachments.length > 0) {
    for (const attachment of fileData.attachments) {
      // Check if attachment is an embedded email (MSG, EML, or RFC822)
      const isEmbeddedEmail = 
        attachment.extension === ".msg" ||
        attachment.extension === ".eml" ||
        attachment.mimeType === "application/vnd.ms-outlook" ||
        attachment.mimeType === "message/rfc822" ||
        attachment.mimeType === "text/rfc822-headers" ||
        (attachment.fileName && /\.(msg|eml)$/i.test(attachment.fileName));
      
      if (isEmbeddedEmail && attachment.content) {
        try {
          // RFC 822 compatible separator between messages
          textContent += "\n" + "=".repeat(80) + "\n";
          textContent += `X-Embedded-Email-Number: ${emailCount + 1}\n`;
          textContent += "=".repeat(80) + "\n\n";
          
          // Handle .msg embedded files
          if (attachment.extension === ".msg" || attachment.mimeType === "application/vnd.ms-outlook") {
            const embeddedBuffer = attachment.content as Buffer;
            const embeddedReader = new MsgReader(embeddedBuffer);
            const embeddedData = embeddedReader.getFileData();
            const embeddedEmail = extractEmailData(embeddedData);
            textContent += formatEmailAsText(embeddedEmail, emailCount + 1);
          } 
          // Handle .eml and message/rfc822 embedded files (raw MIME format)
          else {
            const emlContent = (attachment.content as Buffer).toString("utf-8");
            textContent += formatRawMimeEmail(emlContent, emailCount + 1);
          }
          
          emailCount++;
        } catch (error) {
          console.error("Error parsing embedded email:", error);
          // Still include error info in output
          textContent += `X-Conversion-Error: Could not parse embedded email: ${error instanceof Error ? error.message : "Unknown error"}\n\n`;
          emailCount++;
        }
      }
    }
  }
  
  return {
    filename,
    textContent,
    originalSize: buffer.length,
    convertedSize: textContent.length,
    timestamp: new Date().toISOString(),
    emailCount,
  };
}

function extractEmailData(fileData: any): EmailData {
  const headers = buildMimeHeaders(fileData);
  
  return {
    subject: fileData.subject || "(No Subject)",
    from: fileData.senderName || fileData.senderEmail || "(Unknown Sender)",
    to: fileData.recipients?.map((r: any) => r.name || r.email).join(", ") || "(Unknown Recipient)",
    cc: fileData.cc || "",
    date: fileData.creationTime || fileData.lastModificationTime || new Date().toISOString(),
    body: fileData.body || fileData.bodyHTML || "(No Body)",
    headers,
  };
}

function buildMimeHeaders(fileData: any): string {
  const headers: string[] = [];
  
  // Try to use raw transport headers if available from MSG file
  if (fileData.transportMessageHeaders) {
    // If we have raw MIME headers from the MSG file, use them directly
    return fileData.transportMessageHeaders;
  }
  
  // Build RFC 822 compliant headers from parsed MSG data
  headers.push(`MIME-Version: 1.0`);
  headers.push(`Date: ${fileData.creationTime || new Date().toISOString()}`);
  headers.push(`From: ${fileData.senderName || ""} <${fileData.senderEmail || ""}>`);
  
  if (fileData.recipients && fileData.recipients.length > 0) {
    const to = fileData.recipients
      .filter((r: any) => r.recipientType === "to" || !r.recipientType)
      .map((r: any) => `${r.name || ""} <${r.email || ""}>`)
      .join(", ");
    if (to) headers.push(`To: ${to}`);
    
    const cc = fileData.recipients
      .filter((r: any) => r.recipientType === "cc")
      .map((r: any) => `${r.name || ""} <${r.email || ""}>`)
      .join(", ");
    if (cc) headers.push(`Cc: ${cc}`);
  }
  
  headers.push(`Subject: ${fileData.subject || "(No Subject)"}`);
  headers.push(`Message-ID: ${fileData.messageId || generateMessageId()}`);
  
  if (fileData.importance) {
    headers.push(`Importance: ${fileData.importance}`);
  }
  
  if (fileData.contentType) {
    headers.push(`Content-Type: ${fileData.contentType}`);
  } else if (fileData.bodyHTML) {
    headers.push(`Content-Type: text/html; charset="utf-8"`);
  } else {
    headers.push(`Content-Type: text/plain; charset="utf-8"`);
  }
  
  // Add custom headers if available
  if (fileData.headers && typeof fileData.headers === "object") {
    for (const [key, value] of Object.entries(fileData.headers)) {
      if (typeof value === "string") {
        headers.push(`${key}: ${value}`);
      }
    }
  }
  
  return headers.join("\n");
}

function formatEmailAsText(email: EmailData, emailNumber: number): string {
  // RFC 822 compliant format: headers followed by blank line, then body
  let text = "";
  
  // Add all MIME headers
  text += email.headers + "\n";
  
  // Blank line separator between headers and body (RFC 822 requirement)
  text += "\n";
  
  // Message body
  text += email.body + "\n";
  
  return text;
}

function formatRawMimeEmail(emlContent: string, emailNumber: number): string {
  // .eml files are already in RFC 822 format, return as-is
  return emlContent + "\n";
}

function generateMessageId(): string {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 15);
  return `<${timestamp}.${random}@msgconverter.local>`;
}
