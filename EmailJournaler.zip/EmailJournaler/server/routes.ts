import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { parseMsgFile } from "./msgParser";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.originalname.toLowerCase().endsWith(".msg")) {
      cb(null, true);
    } else {
      cb(new Error("Only .msg files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/convert", upload.single("msgFile"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const result = await parseMsgFile(req.file.buffer, req.file.originalname);
      
      res.json(result);
    } catch (error) {
      console.error("Conversion error:", error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to convert MSG file",
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
