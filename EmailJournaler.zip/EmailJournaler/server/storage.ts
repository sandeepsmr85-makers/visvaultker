// Storage interface for MSG converter
// Currently using in-memory storage for conversion history (future enhancement)

export interface IStorage {
  // Future: Add methods for storing conversion history if needed
}

export class MemStorage implements IStorage {
  constructor() {
    // Currently no persistent storage needed for simple file conversion
  }
}

export const storage = new MemStorage();
