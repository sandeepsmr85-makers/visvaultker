declare module "msgreader" {
  interface Recipient {
    name?: string;
    email?: string;
    recipientType?: string;
  }

  interface Attachment {
    fileName?: string;
    extension?: string;
    mimeType?: string;
    content?: Buffer;
  }

  interface FileData {
    subject?: string;
    senderName?: string;
    senderEmail?: string;
    recipients?: Recipient[];
    cc?: string;
    body?: string;
    bodyHTML?: string;
    creationTime?: string;
    lastModificationTime?: string;
    messageId?: string;
    importance?: string;
    contentType?: string;
    headers?: Record<string, any>;
    attachments?: Attachment[];
    transportMessageHeaders?: string;
  }

  class MsgReader {
    constructor(buffer: Buffer);
    getFileData(): FileData;
  }

  export = MsgReader;
}
