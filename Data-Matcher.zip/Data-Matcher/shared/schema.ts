import { pgTable, text, serial, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We'll use a local DB just for session store or caching if needed, 
// but the main data is in S3.
// We can define the shape of our S3 data here for shared type safety.

export const recordSchema = z.object({
  key: z.string(),
  value: z.string().optional(),
  properties: z.record(z.string(), z.any()).optional(),
});

export const dataFileSchema = z.array(recordSchema);

export type RecordItem = z.infer<typeof recordSchema>;

// API Schemas
export const searchParamsSchema = z.object({
  query: z.string().optional(),
});

export const updateRecordSchema = recordSchema;
