# Data Manager

## Overview

A full-stack data management application that provides a web interface for viewing and editing records stored in Amazon S3. The application uses a React frontend with a Node.js/Express backend, allowing users to search, view, and update JSON data stored in S3 buckets.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme configuration
- **Animations**: Framer Motion for smooth transitions
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **API Design**: REST endpoints defined in `shared/routes.ts` with Zod schemas for request/response validation
- **Development**: Vite middleware integration for HMR during development
- **Production**: Static file serving from built assets

### Data Storage
- **Primary Storage**: Amazon S3 for JSON data files
- **Data Format**: Array of record objects with key, value, and dynamic properties
- **Database**: PostgreSQL configured via Drizzle ORM (currently used for session storage, schema in `shared/schema.ts`)
- **ORM**: Drizzle ORM with drizzle-zod for schema-to-validation integration

### Code Organization
```
client/           # React frontend
  src/
    components/   # UI components including shadcn/ui
    hooks/        # Custom React hooks (use-records, use-toast)
    lib/          # Utilities and query client setup
    pages/        # Route components
server/           # Express backend
  index.ts        # Server entry point
  routes.ts       # API route handlers
  storage.ts      # S3 storage abstraction
  db.ts           # Database connection
shared/           # Shared types and schemas
  schema.ts       # Zod schemas and Drizzle table definitions
  routes.ts       # API route definitions with type-safe contracts
```

### Key Design Patterns
- **Type-Safe API Contracts**: Routes defined in `shared/routes.ts` with Zod schemas ensure frontend and backend stay in sync
- **Storage Abstraction**: `IStorage` interface in `server/storage.ts` allows swapping S3 for other backends
- **Component Library**: shadcn/ui provides consistent, accessible UI primitives

## External Dependencies

### Cloud Services
- **Amazon S3**: Primary data storage for JSON records
  - Required environment variables: `AWS_REGION`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `S3_BUCKET_NAME`, `S3_FILE_KEY`

### Database
- **PostgreSQL**: Database connection via `DATABASE_URL` environment variable
  - Used with Drizzle ORM for migrations and schema management
  - Session storage via connect-pg-simple

### Key NPM Packages
- `@aws-sdk/client-s3`: AWS S3 operations
- `drizzle-orm` / `drizzle-kit`: Database ORM and migrations
- `@tanstack/react-query`: Data fetching and caching
- `zod`: Runtime type validation
- `express`: HTTP server framework
- Full shadcn/ui component suite via Radix UI primitives