import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
import { Readable } from "stream";
import { RecordItem } from "@shared/schema";

// S3 Configuration
const s3 = new S3Client({
  region: process.env.AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
  },
});

const BUCKET = process.env.S3_BUCKET_NAME || "";
const KEY = process.env.S3_FILE_KEY || "";

export interface IStorage {
  getRecords(query?: string): Promise<RecordItem[]>;
  updateRecord(key: string, record: RecordItem): Promise<RecordItem>;
}

export class S3Storage implements IStorage {
  // Helper to read JSON from S3
  private async readS3Data(): Promise<RecordItem[]> {
    if (!BUCKET || !KEY) {
      console.warn("S3 bucket or key not set");
      return [];
    }
    
    try {
      const command = new GetObjectCommand({
        Bucket: BUCKET,
        Key: KEY,
      });

      const response = await s3.send(command);
      if (!response.Body) return [];

      const str = await response.Body.transformToString();
      return JSON.parse(str);
    } catch (error) {
      console.error("Error reading from S3:", error);
      // Return empty array if file doesn't exist or error
      return [];
    }
  }

  // Helper to write JSON to S3
  private async writeS3Data(data: RecordItem[]): Promise<void> {
    if (!BUCKET || !KEY) return;

    try {
      const command = new PutObjectCommand({
        Bucket: BUCKET,
        Key: KEY,
        Body: JSON.stringify(data, null, 2),
        ContentType: "application/json",
      });

      await s3.send(command);
    } catch (error) {
      console.error("Error writing to S3:", error);
      throw new Error("Failed to save to S3");
    }
  }

  async getRecords(query?: string): Promise<RecordItem[]> {
    const allRecords = await this.readS3Data();
    
    if (!query) return allRecords;
    
    const q = query.toLowerCase();
    return allRecords.filter(record => {
      // Check value
      if (record.value?.toLowerCase().includes(q)) return true;
      if (record.key?.toLowerCase().includes(q)) return true;

      // Check properties
      if (record.properties) {
        for (const val of Object.values(record.properties)) {
          if (typeof val === 'string' && val.toLowerCase().includes(q)) return true;
          if (Array.isArray(val) && val.some(v => typeof v === 'string' && v.toLowerCase().includes(q))) return true;
        }
      }
      return false;
    });
  }

  async updateRecord(key: string, updatedRecord: RecordItem): Promise<RecordItem> {
    const allRecords = await this.readS3Data();
    const index = allRecords.findIndex(r => r.key === key);
    
    if (index === -1) {
      throw new Error("Record not found");
    }

    // Update in memory
    allRecords[index] = { ...allRecords[index], ...updatedRecord };

    // Write back to S3
    await this.writeS3Data(allRecords);

    return allRecords[index];
  }
}

export const storage = new S3Storage();
