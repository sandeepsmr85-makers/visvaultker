import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.records.list.path, async (req, res) => {
    try {
      // Validate query params if they exist, or just pass undefined
      const query = req.query.query as string | undefined;
      const records = await storage.getRecords(query);
      res.json(records);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put(api.records.update.path, async (req, res) => {
    try {
      const key = req.params.key;
      const input = api.records.update.input.parse(req.body);
      
      // Ensure the key in URL matches body if strict, or ignore body key?
      // Usually good practice to consistency check
      if (input.key !== key) {
        return res.status(400).json({ message: "Key mismatch" });
      }

      const updated = await storage.updateRecord(key, input);
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: error.errors[0].message,
          field: error.errors[0].path.join('.'),
        });
      }
      // Check if it's "not found" from storage
      if (error instanceof Error && error.message === "Record not found") {
        return res.status(404).json({ message: "Record not found" });
      }
      
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
