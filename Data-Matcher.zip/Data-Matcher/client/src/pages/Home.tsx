import { useState } from "react";
import { useRecords } from "@/hooks/use-records";
import { RecordEditor } from "@/components/RecordEditor";
import { type RecordItem } from "@shared/routes";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Search, Database, AlertCircle, RefreshCw, SlidersHorizontal, ChevronRight, Edit3 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState(""); // The query actually sent to API
  const [selectedRecord, setSelectedRecord] = useState<RecordItem | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);

  const { data: records, isLoading, error, refetch, isRefetching } = useRecords(activeQuery);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveQuery(searchQuery);
  };

  const handleEdit = (record: RecordItem) => {
    setSelectedRecord(record);
    setEditorOpen(true);
  };

  // Helper to count properties
  const getPropCount = (r: RecordItem) => r.properties ? Object.keys(r.properties).length : 0;

  return (
    <div className="min-h-screen w-full bg-background text-foreground flex flex-col font-sans">
      {/* Header Section */}
      <header className="sticky top-0 z-30 w-full border-b border-white/5 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-lg shadow-primary/20">
              <Database className="h-5 w-5 text-white" />
            </div>
            <h1 className="font-bold text-lg tracking-tight hidden md:block">
              Data Manager
              <span className="ml-2 text-xs font-normal text-muted-foreground bg-muted/50 px-2 py-0.5 rounded-full">S3 Connected</span>
            </h1>
          </div>
          
          <div className="flex items-center gap-2">
             <Button 
              variant="outline" 
              size="sm" 
              onClick={() => refetch()} 
              disabled={isRefetching}
              className="border-white/10 bg-white/5 hover:bg-white/10"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefetching ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        
        {/* Search Hero */}
        <section className="max-w-3xl mx-auto mb-12 text-center space-y-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-2"
          >
            <h2 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white via-white/90 to-white/50 pb-2">
              Explore your Dataset
            </h2>
            <p className="text-muted-foreground text-lg max-w-lg mx-auto">
              Search by entity ID to instantly filter through thousands of records stored securely in S3.
            </p>
          </motion.div>

          <motion.form 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            onSubmit={handleSearch}
            className="relative max-w-lg mx-auto"
          >
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/50 to-purple-500/50 rounded-xl blur opacity-30 group-hover:opacity-60 transition duration-500"></div>
              <div className="relative flex items-center bg-card rounded-xl shadow-2xl border border-white/10 overflow-hidden">
                <Search className="ml-4 h-5 w-5 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by ID (e.g. 814842159)..."
                  className="border-0 h-14 bg-transparent text-lg focus-visible:ring-0 placeholder:text-muted-foreground/50"
                />
                <div className="pr-2">
                  <Button type="submit" size="sm" className="h-9 px-4 rounded-lg bg-primary hover:bg-primary/90 transition-all">
                    Search
                  </Button>
                </div>
              </div>
            </div>
            {activeQuery && (
               <div className="mt-3 flex justify-center">
                <Badge variant="secondary" className="px-3 py-1 bg-muted/50 hover:bg-muted cursor-pointer" onClick={() => { setSearchQuery(""); setActiveQuery(""); }}>
                  Filtering: "{activeQuery}"
                  <span className="ml-2 opacity-50">×</span>
                </Badge>
              </div>
            )}
          </motion.form>
        </section>

        {/* Results Area */}
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
              {isLoading ? "Loading records..." : `Records Found (${records?.length || 0})`}
            </h3>
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Display Options
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6 bg-destructive/10 border-destructive/20 text-destructive-foreground">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error loading data</AlertTitle>
              <AlertDescription>{error.message}</AlertDescription>
            </Alert>
          )}

          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-24 rounded-xl bg-card/50 border border-white/5 animate-pulse" />
              ))}
            </div>
          ) : records?.length === 0 ? (
            <div className="text-center py-20 rounded-2xl border border-dashed border-white/10 bg-white/5">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-muted mb-4">
                <Search className="h-6 w-6 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium">No records found</h3>
              <p className="text-muted-foreground max-w-sm mx-auto mt-2">
                We couldn't find any records matching your search criteria. Try a different ID or clear the filter.
              </p>
            </div>
          ) : (
            <div className="space-y-3 pb-20">
              <AnimatePresence>
                {records?.map((record, idx) => (
                  <motion.div
                    key={record.key}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                  >
                    <Card 
                      onClick={() => handleEdit(record)}
                      className="group relative overflow-hidden bg-card hover:bg-muted/30 border-white/5 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 hover:border-primary/20 cursor-pointer"
                    >
                      <div className="flex flex-col md:flex-row items-start md:items-center p-5 gap-4">
                        <div className="flex-shrink-0">
                          <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold text-sm border border-primary/20 group-hover:scale-110 transition-transform">
                            {idx + 1}
                          </div>
                        </div>

                        <div className="flex-1 min-w-0 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <div className="text-xs text-muted-foreground font-medium mb-1">Entity Key</div>
                            <div className="font-mono text-sm font-semibold truncate text-foreground/90 group-hover:text-primary transition-colors">
                              {record.key}
                            </div>
                          </div>
                          
                          <div>
                            <div className="text-xs text-muted-foreground font-medium mb-1">Primary Value</div>
                            <div className="text-sm truncate text-foreground/80">
                              {record.value || <span className="text-muted-foreground italic">Empty</span>}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 mt-4 md:mt-0 w-full md:w-auto justify-between md:justify-end">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="bg-muted/20 border-white/10 text-muted-foreground">
                              {getPropCount(record)} Props
                            </Badge>
                          </div>
                          <Button size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100 transition-opacity -mr-2 text-primary">
                            Edit <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </div>
                      </div>
                      
                      {/* Active indicator bar on left */}
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary scale-y-0 group-hover:scale-y-100 transition-transform origin-center" />
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </main>

      <RecordEditor 
        record={selectedRecord} 
        open={editorOpen} 
        onOpenChange={setEditorOpen} 
      />
    </div>
  );
}
