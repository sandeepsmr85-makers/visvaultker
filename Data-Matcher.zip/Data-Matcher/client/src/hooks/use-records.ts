import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type RecordItem } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

// Fetch records with optional search query
export function useRecords(searchQuery?: string) {
  return useQuery({
    queryKey: [api.records.list.path, searchQuery],
    queryFn: async () => {
      const url = searchQuery 
        ? `${api.records.list.path}?query=${encodeURIComponent(searchQuery)}`
        : api.records.list.path;
        
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch records");
      return api.records.list.responses[200].parse(await res.json());
    },
    // Keep data fresh but don't refetch aggressively on typing
    staleTime: 1000 * 30, 
  });
}

// Update a single record
export function useUpdateRecord() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: RecordItem) => {
      // Use the key from the data to build the URL
      const url = buildUrl(api.records.update.path, { key: data.key });
      
      const res = await fetch(url, {
        method: api.records.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.message || "Failed to update record");
      }
      
      return api.records.update.responses[200].parse(await res.json());
    },
    onSuccess: (updatedRecord) => {
      toast({
        title: "Success",
        description: `Record ${updatedRecord.key} updated successfully.`,
      });
      
      // Invalidate list to show fresh data
      queryClient.invalidateQueries({ queryKey: [api.records.list.path] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    },
  });
}
