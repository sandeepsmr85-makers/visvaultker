import { useState, useEffect } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { type RecordItem } from "@shared/routes";
import { useUpdateRecord } from "@/hooks/use-records";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetFooter } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Plus, Trash2, Save, Loader2 } from "lucide-react";

interface RecordEditorProps {
  record: RecordItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Helper type for form structure where properties are an array of key-value pairs
type RecordFormValues = {
  key: string;
  value: string;
  properties: { key: string; value: string }[];
};

export function RecordEditor({ record, open, onOpenChange }: RecordEditorProps) {
  const updateMutation = useUpdateRecord();
  
  const { register, control, handleSubmit, reset, formState: { isDirty } } = useForm<RecordFormValues>({
    defaultValues: {
      key: "",
      value: "",
      properties: [],
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "properties"
  });

  // Reset form when record changes
  useEffect(() => {
    if (record) {
      // Convert properties object to array for form handling
      const propsArray = record.properties 
        ? Object.entries(record.properties).map(([k, v]) => ({ 
            key: k, 
            // Handle array values or object values by stringifying them for simple editing
            value: typeof v === 'object' ? JSON.stringify(v) : String(v) 
          }))
        : [];

      reset({
        key: record.key,
        value: record.value || "",
        properties: propsArray,
      });
    }
  }, [record, reset]);

  const onSubmit = (data: RecordFormValues) => {
    // Reconstruct the properties object
    const propertiesObj: Record<string, any> = {};
    data.properties.forEach(p => {
      if (p.key) {
        // Try to parse back to JSON/Array if it looks like one, otherwise string
        try {
          if (p.value.startsWith('[') || p.value.startsWith('{')) {
            propertiesObj[p.key] = JSON.parse(p.value);
          } else {
            propertiesObj[p.key] = p.value;
          }
        } catch {
          propertiesObj[p.key] = p.value;
        }
      }
    });

    updateMutation.mutate({
      key: data.key,
      value: data.value,
      properties: propertiesObj,
    }, {
      onSuccess: () => onOpenChange(false)
    });
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-xl flex flex-col h-full bg-card border-l border-white/10 p-0 gap-0">
        <SheetHeader className="p-6 pb-2">
          <SheetTitle className="text-xl font-bold flex items-center gap-2">
            Edit Record 
            <span className="px-2 py-0.5 rounded-md bg-primary/20 text-primary text-xs font-mono">
              {record?.key}
            </span>
          </SheetTitle>
          <SheetDescription>
            Modify the value and properties for this entity.
          </SheetDescription>
        </SheetHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="flex-1 flex flex-col min-h-0">
          <ScrollArea className="flex-1 px-6">
            <div className="space-y-6 py-6">
              
              {/* Primary Fields */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="key" className="text-muted-foreground">Entity Key</Label>
                  <Input 
                    {...register("key")} 
                    disabled 
                    className="font-mono bg-muted/50 border-white/5 opacity-70 cursor-not-allowed" 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="value" className="text-foreground font-medium">Primary Value</Label>
                  <Input 
                    {...register("value")} 
                    className="bg-background border-white/10 focus:border-primary/50 transition-colors"
                    placeholder="Enter value..."
                  />
                </div>
              </div>

              <Separator className="bg-white/5" />

              {/* Dynamic Properties */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-foreground font-medium">Properties</Label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    onClick={() => append({ key: "", value: "" })}
                    className="h-8 border-dashed border-white/20 hover:border-primary/50 hover:bg-primary/5 text-xs"
                  >
                    <Plus className="w-3 h-3 mr-1" /> Add Property
                  </Button>
                </div>

                <div className="space-y-3">
                  {fields.map((field, index) => (
                    <div key={field.id} className="group flex items-start gap-2 animate-in fade-in slide-in-from-left-2 duration-200">
                      <div className="flex-1 space-y-1">
                        <Input
                          {...register(`properties.${index}.key` as const)}
                          placeholder="Key"
                          className="h-9 font-mono text-xs bg-muted/30 border-white/5 focus:bg-background transition-colors"
                        />
                      </div>
                      <div className="flex-[2] space-y-1">
                        <Input
                          {...register(`properties.${index}.value` as const)}
                          placeholder="Value"
                          className="h-9 text-sm bg-background border-white/10 focus:border-primary/30 transition-colors"
                        />
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => remove(index)}
                        className="h-9 w-9 text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  
                  {fields.length === 0 && (
                    <div className="text-center py-8 border-2 border-dashed border-white/5 rounded-lg text-muted-foreground text-sm">
                      No additional properties defined.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </ScrollArea>

          <SheetFooter className="p-6 pt-4 border-t border-white/5 bg-muted/10">
            <Button 
              type="button" 
              variant="ghost" 
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!isDirty || updateMutation.isPending}
              className="bg-primary hover:bg-primary/90 text-primary-foreground min-w-[100px]"
            >
              {updateMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving</>
              ) : (
                <><Save className="w-4 h-4 mr-2" /> Save Changes</>
              )}
            </Button>
          </SheetFooter>
        </form>
      </SheetContent>
    </Sheet>
  );
}
