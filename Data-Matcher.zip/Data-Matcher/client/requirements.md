## Packages
framer-motion | Smooth layout transitions and entry animations
react-hook-form | Robust form handling for complex record editing
@hookform/resolvers | Zod integration for form validation
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Integration with S3 is handled via backend routes.
Data structure allows dynamic properties; form needs to handle key-value pairs.
